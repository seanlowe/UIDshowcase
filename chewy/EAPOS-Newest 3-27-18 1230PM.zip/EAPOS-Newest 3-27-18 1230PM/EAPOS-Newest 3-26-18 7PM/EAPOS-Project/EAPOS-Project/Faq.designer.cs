﻿namespace WindowsFormsApplication1
{
    partial class frmQandA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmQandA));
            this.flpQuestion = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlQ1 = new System.Windows.Forms.Panel();
            this.lblQ1 = new System.Windows.Forms.Label();
            this.pnlA1 = new System.Windows.Forms.Panel();
            this.lblA1 = new System.Windows.Forms.Label();
            this.pnlQ2 = new System.Windows.Forms.Panel();
            this.lblQ2 = new System.Windows.Forms.Label();
            this.pnlA2 = new System.Windows.Forms.Panel();
            this.lblA2 = new System.Windows.Forms.Label();
            this.pnlQ3 = new System.Windows.Forms.Panel();
            this.lblQ3 = new System.Windows.Forms.Label();
            this.pnlA3 = new System.Windows.Forms.Panel();
            this.lblA3 = new System.Windows.Forms.Label();
            this.pnlQ4 = new System.Windows.Forms.Panel();
            this.lblQ4 = new System.Windows.Forms.Label();
            this.pnlA4 = new System.Windows.Forms.Panel();
            this.lblA4 = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.flpAddingQuestions = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlAskingQuestionsTitle = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlRecordData = new System.Windows.Forms.Panel();
            this.btnClearData = new System.Windows.Forms.Button();
            this.btnSubmitData = new System.Windows.Forms.Button();
            this.lsbAddKey = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rtbAddAnswer = new System.Windows.Forms.RichTextBox();
            this.rtbAddQuestion = new System.Windows.Forms.RichTextBox();
            this.btnFaqHome = new System.Windows.Forms.Button();
            this.btnExitFAQ = new System.Windows.Forms.Button();
            this.flpQuestion.SuspendLayout();
            this.pnlQ1.SuspendLayout();
            this.pnlA1.SuspendLayout();
            this.pnlQ2.SuspendLayout();
            this.pnlA2.SuspendLayout();
            this.pnlQ3.SuspendLayout();
            this.pnlA3.SuspendLayout();
            this.pnlQ4.SuspendLayout();
            this.pnlA4.SuspendLayout();
            this.flpAddingQuestions.SuspendLayout();
            this.pnlAskingQuestionsTitle.SuspendLayout();
            this.pnlRecordData.SuspendLayout();
            this.SuspendLayout();
            // 
            // flpQuestion
            // 
            this.flpQuestion.AutoScroll = true;
            this.flpQuestion.BackColor = System.Drawing.Color.Transparent;
            this.flpQuestion.Controls.Add(this.pnlQ1);
            this.flpQuestion.Controls.Add(this.pnlA1);
            this.flpQuestion.Controls.Add(this.pnlQ2);
            this.flpQuestion.Controls.Add(this.pnlA2);
            this.flpQuestion.Controls.Add(this.pnlQ3);
            this.flpQuestion.Controls.Add(this.pnlA3);
            this.flpQuestion.Controls.Add(this.pnlQ4);
            this.flpQuestion.Controls.Add(this.pnlA4);
            this.flpQuestion.Location = new System.Drawing.Point(1, 104);
            this.flpQuestion.Margin = new System.Windows.Forms.Padding(2);
            this.flpQuestion.Name = "flpQuestion";
            this.flpQuestion.Padding = new System.Windows.Forms.Padding(8);
            this.flpQuestion.Size = new System.Drawing.Size(722, 439);
            this.flpQuestion.TabIndex = 0;
            this.flpQuestion.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel1_Paint);
            // 
            // pnlQ1
            // 
            this.pnlQ1.AutoSize = true;
            this.pnlQ1.Controls.Add(this.lblQ1);
            this.pnlQ1.Location = new System.Drawing.Point(10, 10);
            this.pnlQ1.Margin = new System.Windows.Forms.Padding(2);
            this.pnlQ1.Name = "pnlQ1";
            this.pnlQ1.Size = new System.Drawing.Size(345, 24);
            this.pnlQ1.TabIndex = 0;
            // 
            // lblQ1
            // 
            this.lblQ1.AutoSize = true;
            this.lblQ1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ1.Location = new System.Drawing.Point(2, 0);
            this.lblQ1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblQ1.Name = "lblQ1";
            this.lblQ1.Size = new System.Drawing.Size(341, 24);
            this.lblQ1.TabIndex = 0;
            this.lblQ1.Text = "How do I delete an Item from the order?";
            this.lblQ1.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // pnlA1
            // 
            this.pnlA1.AutoSize = true;
            this.pnlA1.Controls.Add(this.lblA1);
            this.pnlA1.Location = new System.Drawing.Point(359, 10);
            this.pnlA1.Margin = new System.Windows.Forms.Padding(2);
            this.pnlA1.Name = "pnlA1";
            this.pnlA1.Size = new System.Drawing.Size(1405, 29);
            this.pnlA1.TabIndex = 1;
            // 
            // lblA1
            // 
            this.lblA1.AutoSize = true;
            this.lblA1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblA1.Location = new System.Drawing.Point(2, 9);
            this.lblA1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblA1.Name = "lblA1";
            this.lblA1.Size = new System.Drawing.Size(1401, 20);
            this.lblA1.TabIndex = 1;
            this.lblA1.Text = resources.GetString("lblA1.Text");
            this.lblA1.Visible = false;
            this.lblA1.Click += new System.EventHandler(this.label3_Click);
            // 
            // pnlQ2
            // 
            this.pnlQ2.AutoSize = true;
            this.pnlQ2.Controls.Add(this.lblQ2);
            this.pnlQ2.Location = new System.Drawing.Point(1768, 10);
            this.pnlQ2.Margin = new System.Windows.Forms.Padding(2);
            this.pnlQ2.Name = "pnlQ2";
            this.pnlQ2.Size = new System.Drawing.Size(485, 24);
            this.pnlQ2.TabIndex = 2;
            // 
            // lblQ2
            // 
            this.lblQ2.AutoSize = true;
            this.lblQ2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ2.Location = new System.Drawing.Point(2, 0);
            this.lblQ2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblQ2.Name = "lblQ2";
            this.lblQ2.Size = new System.Drawing.Size(481, 24);
            this.lblQ2.TabIndex = 0;
            this.lblQ2.Text = "How do I add toppings and extras to certain order items?";
            this.lblQ2.Click += new System.EventHandler(this.label4_Click_1);
            // 
            // pnlA2
            // 
            this.pnlA2.AutoSize = true;
            this.pnlA2.Controls.Add(this.lblA2);
            this.pnlA2.Location = new System.Drawing.Point(10, 43);
            this.pnlA2.Margin = new System.Windows.Forms.Padding(2);
            this.pnlA2.Name = "pnlA2";
            this.pnlA2.Size = new System.Drawing.Size(2424, 29);
            this.pnlA2.TabIndex = 3;
            // 
            // lblA2
            // 
            this.lblA2.AutoSize = true;
            this.lblA2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblA2.Location = new System.Drawing.Point(2, 9);
            this.lblA2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblA2.Name = "lblA2";
            this.lblA2.Size = new System.Drawing.Size(2420, 20);
            this.lblA2.TabIndex = 1;
            this.lblA2.Text = resources.GetString("lblA2.Text");
            this.lblA2.Visible = false;
            this.lblA2.Click += new System.EventHandler(this.label5_Click);
            // 
            // pnlQ3
            // 
            this.pnlQ3.AutoSize = true;
            this.pnlQ3.Controls.Add(this.lblQ3);
            this.pnlQ3.Location = new System.Drawing.Point(10, 76);
            this.pnlQ3.Margin = new System.Windows.Forms.Padding(2);
            this.pnlQ3.Name = "pnlQ3";
            this.pnlQ3.Size = new System.Drawing.Size(344, 24);
            this.pnlQ3.TabIndex = 4;
            // 
            // lblQ3
            // 
            this.lblQ3.AutoSize = true;
            this.lblQ3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ3.Location = new System.Drawing.Point(2, 0);
            this.lblQ3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblQ3.Name = "lblQ3";
            this.lblQ3.Size = new System.Drawing.Size(340, 24);
            this.lblQ3.TabIndex = 0;
            this.lblQ3.Text = "I need to refund an order, what do I do?";
            this.lblQ3.Click += new System.EventHandler(this.label6_Click);
            // 
            // pnlA3
            // 
            this.pnlA3.AutoSize = true;
            this.pnlA3.Controls.Add(this.lblA3);
            this.pnlA3.Location = new System.Drawing.Point(10, 104);
            this.pnlA3.Margin = new System.Windows.Forms.Padding(2);
            this.pnlA3.Name = "pnlA3";
            this.pnlA3.Size = new System.Drawing.Size(2340, 29);
            this.pnlA3.TabIndex = 5;
            // 
            // lblA3
            // 
            this.lblA3.AutoSize = true;
            this.lblA3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblA3.Location = new System.Drawing.Point(2, 9);
            this.lblA3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblA3.Name = "lblA3";
            this.lblA3.Size = new System.Drawing.Size(2336, 20);
            this.lblA3.TabIndex = 1;
            this.lblA3.Text = resources.GetString("lblA3.Text");
            this.lblA3.Visible = false;
            this.lblA3.Click += new System.EventHandler(this.label7_Click);
            // 
            // pnlQ4
            // 
            this.pnlQ4.AutoSize = true;
            this.pnlQ4.Controls.Add(this.lblQ4);
            this.pnlQ4.Location = new System.Drawing.Point(10, 137);
            this.pnlQ4.Margin = new System.Windows.Forms.Padding(2);
            this.pnlQ4.Name = "pnlQ4";
            this.pnlQ4.Size = new System.Drawing.Size(433, 26);
            this.pnlQ4.TabIndex = 6;
            // 
            // lblQ4
            // 
            this.lblQ4.AutoSize = true;
            this.lblQ4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQ4.Location = new System.Drawing.Point(2, 2);
            this.lblQ4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblQ4.Name = "lblQ4";
            this.lblQ4.Size = new System.Drawing.Size(429, 24);
            this.lblQ4.TabIndex = 0;
            this.lblQ4.Text = "How do I add employees to the register database?";
            this.lblQ4.Click += new System.EventHandler(this.label8_Click);
            // 
            // pnlA4
            // 
            this.pnlA4.AutoSize = true;
            this.pnlA4.Controls.Add(this.lblA4);
            this.pnlA4.Location = new System.Drawing.Point(10, 167);
            this.pnlA4.Margin = new System.Windows.Forms.Padding(2);
            this.pnlA4.Name = "pnlA4";
            this.pnlA4.Size = new System.Drawing.Size(2412, 29);
            this.pnlA4.TabIndex = 7;
            // 
            // lblA4
            // 
            this.lblA4.AutoSize = true;
            this.lblA4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblA4.Location = new System.Drawing.Point(2, 9);
            this.lblA4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblA4.Name = "lblA4";
            this.lblA4.Size = new System.Drawing.Size(2408, 20);
            this.lblA4.TabIndex = 1;
            this.lblA4.Text = resources.GetString("lblA4.Text");
            this.lblA4.Visible = false;
            this.lblA4.Click += new System.EventHandler(this.label9_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(324, 7);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(50, 24);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "FAQ";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(615, 75);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(98, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "Add Question";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // flpAddingQuestions
            // 
            this.flpAddingQuestions.Controls.Add(this.pnlAskingQuestionsTitle);
            this.flpAddingQuestions.Controls.Add(this.pnlRecordData);
            this.flpAddingQuestions.Location = new System.Drawing.Point(1, 104);
            this.flpAddingQuestions.Name = "flpAddingQuestions";
            this.flpAddingQuestions.Size = new System.Drawing.Size(722, 439);
            this.flpAddingQuestions.TabIndex = 8;
            this.flpAddingQuestions.Visible = false;
            // 
            // pnlAskingQuestionsTitle
            // 
            this.pnlAskingQuestionsTitle.Controls.Add(this.label1);
            this.pnlAskingQuestionsTitle.Location = new System.Drawing.Point(3, 3);
            this.pnlAskingQuestionsTitle.Name = "pnlAskingQuestionsTitle";
            this.pnlAskingQuestionsTitle.Size = new System.Drawing.Size(719, 41);
            this.pnlAskingQuestionsTitle.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 7);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(651, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "Fill in the fields indicated below and then press submit to update the FAQ List";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // pnlRecordData
            // 
            this.pnlRecordData.Controls.Add(this.btnClearData);
            this.pnlRecordData.Controls.Add(this.btnSubmitData);
            this.pnlRecordData.Controls.Add(this.lsbAddKey);
            this.pnlRecordData.Controls.Add(this.label4);
            this.pnlRecordData.Controls.Add(this.label3);
            this.pnlRecordData.Controls.Add(this.label2);
            this.pnlRecordData.Controls.Add(this.rtbAddAnswer);
            this.pnlRecordData.Controls.Add(this.rtbAddQuestion);
            this.pnlRecordData.Location = new System.Drawing.Point(3, 50);
            this.pnlRecordData.Name = "pnlRecordData";
            this.pnlRecordData.Size = new System.Drawing.Size(719, 389);
            this.pnlRecordData.TabIndex = 1;
            // 
            // btnClearData
            // 
            this.btnClearData.Location = new System.Drawing.Point(213, 258);
            this.btnClearData.Name = "btnClearData";
            this.btnClearData.Size = new System.Drawing.Size(98, 23);
            this.btnClearData.TabIndex = 11;
            this.btnClearData.Text = "Clear";
            this.btnClearData.UseVisualStyleBackColor = true;
            this.btnClearData.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnSubmitData
            // 
            this.btnSubmitData.Location = new System.Drawing.Point(340, 258);
            this.btnSubmitData.Name = "btnSubmitData";
            this.btnSubmitData.Size = new System.Drawing.Size(98, 23);
            this.btnSubmitData.TabIndex = 10;
            this.btnSubmitData.Text = "Submit";
            this.btnSubmitData.UseVisualStyleBackColor = true;
            this.btnSubmitData.Click += new System.EventHandler(this.btnSubmitData_Click);
            // 
            // lsbAddKey
            // 
            this.lsbAddKey.FormattingEnabled = true;
            this.lsbAddKey.Items.AddRange(new object[] {
            "Void",
            "Refund",
            "Manager",
            "Cancel",
            "Transaction Order"});
            this.lsbAddKey.Location = new System.Drawing.Point(213, 209);
            this.lsbAddKey.Name = "lsbAddKey";
            this.lsbAddKey.Size = new System.Drawing.Size(225, 30);
            this.lsbAddKey.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(29, 182);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(624, 24);
            this.label4.TabIndex = 4;
            this.label4.Text = "Choose a keyword to attatch to your question that will make it easier to find";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(378, 17);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(332, 24);
            this.label3.TabIndex = 3;
            this.label3.Text = "Write the answer to your prior question";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(20, 17);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(297, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Write the question you wish to add";
            // 
            // rtbAddAnswer
            // 
            this.rtbAddAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbAddAnswer.Location = new System.Drawing.Point(371, 52);
            this.rtbAddAnswer.Name = "rtbAddAnswer";
            this.rtbAddAnswer.Size = new System.Drawing.Size(348, 96);
            this.rtbAddAnswer.TabIndex = 1;
            this.rtbAddAnswer.Text = "";
            // 
            // rtbAddQuestion
            // 
            this.rtbAddQuestion.Location = new System.Drawing.Point(2, 52);
            this.rtbAddQuestion.Name = "rtbAddQuestion";
            this.rtbAddQuestion.Size = new System.Drawing.Size(348, 96);
            this.rtbAddQuestion.TabIndex = 0;
            this.rtbAddQuestion.Text = "";
            // 
            // btnFaqHome
            // 
            this.btnFaqHome.Location = new System.Drawing.Point(4, 78);
            this.btnFaqHome.Name = "btnFaqHome";
            this.btnFaqHome.Size = new System.Drawing.Size(98, 23);
            this.btnFaqHome.TabIndex = 9;
            this.btnFaqHome.Text = "Home";
            this.btnFaqHome.UseVisualStyleBackColor = true;
            this.btnFaqHome.Click += new System.EventHandler(this.btnFaqHome_Click);
            // 
            // btnExitFAQ
            // 
            this.btnExitFAQ.Location = new System.Drawing.Point(616, 549);
            this.btnExitFAQ.Name = "btnExitFAQ";
            this.btnExitFAQ.Size = new System.Drawing.Size(98, 23);
            this.btnExitFAQ.TabIndex = 12;
            this.btnExitFAQ.Text = "EXIT FAQ";
            this.btnExitFAQ.UseVisualStyleBackColor = true;
            this.btnExitFAQ.Click += new System.EventHandler(this.btnExitFAQ_Click);
            // 
            // frmQandA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(725, 576);
            this.Controls.Add(this.btnFaqHome);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnExitFAQ);
            this.Controls.Add(this.flpQuestion);
            this.Controls.Add(this.flpAddingQuestions);
            this.Controls.Add(this.button1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmQandA";
            this.Text = "Frequently Asked Questions";
            this.flpQuestion.ResumeLayout(false);
            this.flpQuestion.PerformLayout();
            this.pnlQ1.ResumeLayout(false);
            this.pnlQ1.PerformLayout();
            this.pnlA1.ResumeLayout(false);
            this.pnlA1.PerformLayout();
            this.pnlQ2.ResumeLayout(false);
            this.pnlQ2.PerformLayout();
            this.pnlA2.ResumeLayout(false);
            this.pnlA2.PerformLayout();
            this.pnlQ3.ResumeLayout(false);
            this.pnlQ3.PerformLayout();
            this.pnlA3.ResumeLayout(false);
            this.pnlA3.PerformLayout();
            this.pnlQ4.ResumeLayout(false);
            this.pnlQ4.PerformLayout();
            this.pnlA4.ResumeLayout(false);
            this.pnlA4.PerformLayout();
            this.flpAddingQuestions.ResumeLayout(false);
            this.pnlAskingQuestionsTitle.ResumeLayout(false);
            this.pnlAskingQuestionsTitle.PerformLayout();
            this.pnlRecordData.ResumeLayout(false);
            this.pnlRecordData.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flpQuestion;
        private System.Windows.Forms.Panel pnlQ1;
        private System.Windows.Forms.Panel pnlA1;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblQ1;
        private System.Windows.Forms.Label lblA1;
        private System.Windows.Forms.Panel pnlQ2;
        private System.Windows.Forms.Label lblQ2;
        private System.Windows.Forms.Panel pnlA2;
        private System.Windows.Forms.Panel pnlQ3;
        private System.Windows.Forms.Label lblQ3;
        private System.Windows.Forms.Panel pnlA3;
        private System.Windows.Forms.Label lblA3;
        private System.Windows.Forms.Panel pnlQ4;
        private System.Windows.Forms.Label lblQ4;
        private System.Windows.Forms.Panel pnlA4;
        private System.Windows.Forms.Label lblA4;
        private System.Windows.Forms.Label lblA2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.FlowLayoutPanel flpAddingQuestions;
        private System.Windows.Forms.Panel pnlAskingQuestionsTitle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlRecordData;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox rtbAddAnswer;
        private System.Windows.Forms.RichTextBox rtbAddQuestion;
        private System.Windows.Forms.ListBox lsbAddKey;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnFaqHome;
        private System.Windows.Forms.Button btnSubmitData;
        private System.Windows.Forms.Button btnClearData;
        private System.Windows.Forms.Button btnExitFAQ;
    }
}

