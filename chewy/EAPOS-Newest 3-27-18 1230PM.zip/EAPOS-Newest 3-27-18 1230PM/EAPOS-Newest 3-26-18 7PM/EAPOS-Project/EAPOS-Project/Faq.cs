﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class frmQandA : Form
    {
        public class Questions
        {
            public string question;
            public string answer;
            public string keySearch;

            public Questions()
            {
                question = " ";
                answer = " ";
                keySearch = " ";
            }
            static public void addQuestion(string addQuestion, string addAnswer, string addKey, ref List<Questions> faq)
            {
                Questions temp = new Questions();
                temp.answer = addAnswer;
                temp.question = addQuestion;
                temp.keySearch = addKey;
                string faqOutput;
                if(faq.Contains(temp))
                {
                    Console.WriteLine("The question is already in the faq");
                }
                else
                {
                    faq.Add(temp);
                    for (int i = 0; i < faq.Count; i++)
                    {
                        faqOutput = faq[i].question + ",";
                        faqOutput = faqOutput + faq[i].answer + "," + faq[i].keySearch;


                    }

                }

            }

            static public void readQuestions(ref List<Questions> faq)
            {
                //Replace file with the path of the "FaqQuestions.txt" Reads in questions and adds them into the FAQ
                using (System.IO.StreamReader sr = new System.IO.StreamReader(@"C:\Users\chewy913\Downloads\EAPOS-Newest 3-25-18 @ 1130AM\EAPOS-Newest 3-21-18 @ 1055PM\EAPOS-Project\EAPOS-Project\FaqQuestions.txt"))
                {
                    while (sr.Peek() >= 0)
                    {
                        string str;
                        string[] strArray;
                        str = sr.ReadLine();
                        strArray = str.Split(',');
                        addQuestion(strArray[0], strArray[1], strArray[2], ref faq);

                    }
                }

            }

        }
        string mydocpath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);




        public frmQandA()
        {
            //Formatting to make questions scale
            InitializeComponent();
            lblQ1.MaximumSize = new Size(700, 0);
            lblQ1.AutoSize = true;
            lblA1.MaximumSize = new Size(700, 0);
            lblA1.AutoSize = true;
            lblQ2.MaximumSize = new Size(700, 0);
            lblQ2.AutoSize = true;
            lblA2.MaximumSize = new Size(700, 0);
            lblA2.AutoSize = true;
            lblQ3.MaximumSize = new Size(700, 0);
            lblQ3.AutoSize = true;
            lblA3.MaximumSize = new Size(700, 0);
            lblA3.AutoSize = true;
            lblQ4.MaximumSize = new Size(700, 0);
            lblQ4.AutoSize = true;
            lblA4.MaximumSize = new Size(700, 0);
            lblA4.AutoSize = true;
            //Verifying read and adding works
            List<Questions> faq = new List<Questions>();
            Questions.readQuestions(ref faq);
            for (int i = 0; i < faq.Count; i++)
            {
                Console.WriteLine($"{i} = {faq[i].question}");
            }






        }

        //Next label clicks show the reactions of when you click on a question and answer
        private void label2_Click_1(object sender, EventArgs e)
        {
            lblA1.Visible = true;
        }

        private void label3_Click(object sender, EventArgs e)
        {
            lblA1.Visible = false;
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
            flpQuestion.HorizontalScroll.Visible = false;
        }
        private void label4_Click_1(object sender, EventArgs e)
        {
            lblA2.Visible = true;
        }

        private void label5_Click(object sender, EventArgs e)
        {
            lblA2.Visible = false;
        }

        private void label6_Click(object sender, EventArgs e)
        {
            lblA3.Visible = true;
        }

        private void label7_Click(object sender, EventArgs e)
        {
            lblA3.Visible = false;
        }

        private void label8_Click(object sender, EventArgs e)
        {
            lblA4.Visible = true;
        }

        private void label9_Click(object sender, EventArgs e)
        {
            lblA4.Visible = false;
            flpQuestion.HorizontalScroll.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Switches Panels to show The adding questions menu
            flpQuestion.Visible=false;
            flpAddingQuestions.Visible = true;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void btnFaqHome_Click(object sender, EventArgs e)
        {
            // Returns to Faq Questions List
            flpAddingQuestions.Visible = false;
            flpQuestion.Visible = true;
        }

        private void btnSubmitData_Click(object sender, EventArgs e)
        {
            // Submits all the data which is then added to the FAQ list
            string tempQuestion, tempAnswer, tempKey;
            tempQuestion = rtbAddQuestion.Text;
            tempAnswer = rtbAddAnswer.Text;
            tempKey = lsbAddKey.Text;
           // Questions.addQuestion(tempQuestion, tempAnswer, tempKey, ref faq);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //set all the data to clear
            rtbAddAnswer.Text = " ";
            rtbAddQuestion.Text = " ";
            lsbAddKey.ClearSelected();
        }

        private void btnExitFAQ_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
