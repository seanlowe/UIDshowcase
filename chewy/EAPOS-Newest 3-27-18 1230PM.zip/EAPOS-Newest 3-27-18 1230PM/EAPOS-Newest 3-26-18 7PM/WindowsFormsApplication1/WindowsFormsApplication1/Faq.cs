﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class frmQandA : Form
    {
        public class Questions
        {
            public string question;
            public string answer;
            public string keySearch;

            public Questions()
            {
                question = " ";
                answer = " ";
                keySearch = " ";
            }
            static public void addQuestion(string addQuestion, string addAnswer, string addKey, ref List<Questions> faq)
            {
                Questions temp = new Questions();
                temp.answer = addAnswer;
                temp.question = addQuestion;
                temp.keySearch = addKey;
                string faqOutput;
                if(faq.Contains(temp))
                {
                    Console.WriteLine("The question is already in the faq");
                }
                else
                {
                    faq.Add(temp);
                    for (int i = 0; i < faq.Count; i++)
                    {
                        faqOutput = faq[i].question + ",";
                        faqOutput = faqOutput + faq[i].answer + "," + faq[i].keySearch;


                    }

                }

            }

            static public void readQuestions(ref List<Questions> faq)
            {
                using (System.IO.StreamReader sr = new System.IO.StreamReader(@"C:\Users\chewy913\Desktop\EAPOS-Newest\WindowsFormsApplication1\WindowsFormsApplication1\FaqQuestions.txt"))
                {
                    while (sr.Peek() >= 0)
                    {
                        string str;
                        string[] strArray;
                        str = sr.ReadLine();
                        strArray = str.Split(',');
                        addQuestion(strArray[0], strArray[1], strArray[2], ref faq);

                    }
                }

            }

        }
        string mydocpath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);




        public frmQandA()
        {
            InitializeComponent();
            lblQ1.MaximumSize = new Size(700, 0);
            lblQ1.AutoSize = true;
            lblA1.MaximumSize = new Size(700, 0);
            lblA1.AutoSize = true;
            lblQ2.MaximumSize = new Size(700, 0);
            lblQ2.AutoSize = true;
            lblA2.MaximumSize = new Size(700, 0);
            lblA2.AutoSize = true;
            lblQ3.MaximumSize = new Size(700, 0);
            lblQ3.AutoSize = true;
            lblA3.MaximumSize = new Size(700, 0);
            lblA3.AutoSize = true;
            lblQ4.MaximumSize = new Size(700, 0);
            lblQ4.AutoSize = true;
            lblA4.MaximumSize = new Size(700, 0);
            lblA4.AutoSize = true;
            List<Questions> faq = new List<Questions>();
            Questions.readQuestions(ref faq);
            for (int i = 0; i < faq.Count; i++)
            {
                Console.WriteLine($"{i} = {faq[i].question}");
            }






        }


        private void label2_Click_1(object sender, EventArgs e)
        {
            lblA1.Visible = true;
        }

        private void label3_Click(object sender, EventArgs e)
        {
            lblA1.Visible = false;
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
            flpQuestion.HorizontalScroll.Visible = false;
        }
        private void label4_Click_1(object sender, EventArgs e)
        {
            lblA2.Visible = true;
        }

        private void label5_Click(object sender, EventArgs e)
        {
            lblA2.Visible = false;
        }

        private void label6_Click(object sender, EventArgs e)
        {
            lblA3.Visible = true;
        }

        private void label7_Click(object sender, EventArgs e)
        {
            lblA3.Visible = false;
        }

        private void label8_Click(object sender, EventArgs e)
        {
            lblA4.Visible = true;
        }

        private void label9_Click(object sender, EventArgs e)
        {
            lblA4.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            flpQuestion.Visible=false;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
