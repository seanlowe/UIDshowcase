﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using SignIn;
using Ordering;

namespace EAPOS_Project
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmSignIn());
            frmMain Ordering = new frmMain();
            Ordering.Hide();
            frmManagerMode Manager = new frmManagerMode();
            Manager.Hide();
        }
    }
}
