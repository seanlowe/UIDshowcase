﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using SignIn;
using WindowsFormsApplication1;
using EAPOS_Project;

namespace Ordering
{
    public partial class frmMain : Form
    {
        public int nextopenindex = 0;

        // Global double for cashing out
        public double runningtotal = 0.00;

        //Class for the order Items
        public class orderItem
        {
            public int quantity;
            public frmSignIn.FoodItem foodItem;
            public string[] strmessage = new string[5];
            public int nummessages;
            public bool message;
            public int myindex;

            //Constructor
            public orderItem(frmSignIn.FoodItem inputFoodItem, int inindex)
            {
                foodItem = inputFoodItem;
                quantity = 1;
                message = false;
                for (int i = 0; i < 5; i++)
                {
                    strmessage[i] = "";
                }
                nummessages = 0;
                myindex = inindex;
            }

            public void incrementmessage()
            {
                nummessages++;
            }

            //Increments the quantity of oderItem
            public void incrementQuantity()
            {
                quantity++;
            }

            //Food Item accessor
            public string getFoodItemName()
            {
                return foodItem.name;
            }

            //Quantity accessor
            public int getQunatity()
            {
                return quantity;
            }

        }

        //Dynamic linked list of orderItems
        List<orderItem> Orders = new List<orderItem>();



        public frmMain()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Orders.Count != 0)
            {
                button1.Enabled = false;
                MessageBox.Show("Must Complete or Cancel order before signing out!");
            }
            else
            {
                FormProvider.signInForm.Show();
                btnGoToManagerMode.Visible = false;
                this.Hide();
                FormProvider.signInForm.logOutTime(FormProvider.signInForm.activeUserID);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string width;
            string height;

            width = this.Width.ToString();
            height = this.Height.ToString();

            lblResolution.Text = "Height: " + height + " Width: " + width;

        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            calculateOrderTotal();
            OrderingTimer.Enabled = true;
            this.Location = new Point(0, 0);
            this.Size = Screen.PrimaryScreen.WorkingArea.Size;
            lstbOrders.Text = "";
            lblLabelReceipt.Text = "Qty".PadRight(5) + "Description".PadRight(21) + "Amount($)";
        }

        private void OrderingTimer_Tick(object sender, EventArgs e)
        {
            lblCurrentDate.Text = DateTime.Now.ToString();
        }

        //This function adds items to the current order
        private void addToOder(string buttonName)
        {
            bool found = false;
            int i = 0;
            frmSignIn.FoodItem foodItem;
            Debug.Print("You clicked on:" + buttonName);


            //Finds the associated food item
            while (found == false && i < FormProvider.signInForm.pushedInItems.Count)
            {
                if (FormProvider.signInForm.pushedInItems[i].btnName.Name == buttonName)
                {
                    found = true;
                    Debug.Print("Found the assigned button!");
                    bool doesItExistAlready = false;
                    foodItem = FormProvider.signInForm.pushedInItems[i];
                    Debug.Print("It is: " + FormProvider.signInForm.pushedInItems[i].name.ToString());

                    //Need to check if the item already exists in the Orders list, if so then increment the quntity of item..
                    for (int j = 0; j < Orders.Count; j++)
                    {
                        if (Orders[j].foodItem.name == foodItem.name)
                        {
                            Debug.Print("The item is already in the order! Incrementing the quntity");
                            doesItExistAlready = true;
                            Orders[j].incrementQuantity();
                        }

                    }

                    //Add the orderItem only if it does not exist!
                    if (!doesItExistAlready)
                    {
                        //Add the oderItem to the Orders list
                        Debug.Print("Item did not exist in order so I added it!");
                        Orders.Add(new orderItem(foodItem, nextopenindex));
                        nextopenindex++;
                    }
                    //Prints
                    PrintOrders();
                }
                i++;
                calculateOrderTotal();
            }
            if (found == false)
                Debug.Print("Could not find associated object!");


        }

        private void button5_Click(object sender, EventArgs e)
        {
            string objname = ((Button)sender).Name;
            addToOder(objname);




        }

        private void btnWholePizza_Click(object sender, EventArgs e)
        {
            string objname = ((Button)sender).Name;
            addToOder(objname);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            /*
            if(lstbOrders.SelectedIndex != -1)
            {
                //Removes the order item from the linked list
                int indexOfItemInList = 0;
                indexOfItemInList = lstbOrders.SelectedIndex;
                string itemRemoved = Orders[indexOfItemInList].type;
                Orders.RemoveAt(indexOfItemInList);

                //Resets the counter to add item again
                if (itemRemoved == "Burger")
                    numBurgers = 0;
                else if (itemRemoved == "HotDog")
                    numHotDogs = 0;
                else if (itemRemoved == "Pizza")
                    numPizzas = 0;
                else if (itemRemoved == "Pizza Slice")
                    numPizzaSlices = 0;
                else if (itemRemoved == "Chicken")
                    numChicken = 0;
                else if (itemRemoved == "Coffee")
                    numCoffee = 0;
                else if (itemRemoved == "Soda")
                    numSoda = 0;
                else if (itemRemoved == "Bagel")
                    numBagel = 0;
                else if (itemRemoved == "IceCream")
                    numBagel = 0;


                //The cosmetic aspect
                calculateOrderTotal();
                lstbOrders.Items.Remove(lstbOrders.SelectedItem);
                lstbOrders.Refresh();

            }  
            */
        }



        private void btnHotDog_Click(object sender, EventArgs e)
        {
            string objname = ((Button)sender).Name;
            addToOder(objname);




        }

        private void btnPizzaSlice_Click(object sender, EventArgs e)
        {
            string objname = ((Button)sender).Name;
            addToOder(objname);

        }

        private void btnChicken_Click(object sender, EventArgs e)
        {
            string objname = ((Button)sender).Name;
            addToOder(objname);

        }

        private void btnCoffee_Click(object sender, EventArgs e)
        {
            string objname = ((Button)sender).Name;
            addToOder(objname);

        }

        private void btnSode_Click(object sender, EventArgs e)
        {
            string objname = ((Button)sender).Name;
            addToOder(objname);

        }

        private void btnBagel_Click(object sender, EventArgs e)
        {
            string objname = ((Button)sender).Name;
            addToOder(objname);

        }

        private void btnIceCream_Click(object sender, EventArgs e)
        {
            string objname = ((Button)sender).Name;
            addToOder(objname);


        }

        void PrintOrders()
        {
            Debug.Print("I am printing the orders!");
            //Clears the listbox in the ordering form
            lstbOrders.Items.Clear();
            string messagelines;
            for (int i = 0; i < Orders.Count; i++)
            {
                string type = Orders[i].getFoodItemName();
                int quantity = Orders[i].getQunatity();
                double price = Orders[i].foodItem.price;
                string strPrice = string.Format("{0:C}", price);

                string orderline = quantity.ToString().PadRight(5) + type.PadRight(21) + strPrice;
                lstbOrders.Items.Add(orderline);
                if (Orders[i].message == true)
                {
                    for (int j = 0; j < Orders[i].nummessages; j++)
                    {
                        Debug.Print("Item : " + Orders[i].foodItem.name.ToString() + " has nummessages set to: " + Orders[i].nummessages.ToString());
                        Debug.Print("I see message: " + Orders[i].strmessage[j]);
                        messagelines = " - " + Orders[i].strmessage[j];
                        lstbOrders.Items.Add(messagelines);
                    }

                }



            }
        }

        void AddItemToOrder(ref int quantity, string name, double price)
        {

        }

        void calculateOrderTotal()
        {
            //Calculates the total price
            double totalPrice = 0;
            for (int i = 0; i < Orders.Count; i++)
            {
                totalPrice = totalPrice + (Orders[i].foodItem.price * Orders[i].getQunatity());
                runningtotal = totalPrice;
            }

            rtxtbOrderFinal.Clear();
            rtxtbOrderFinal.AppendText(" Subtotal: ".PadRight(28) + "$" + totalPrice.ToString());
            rtxtbOrderFinal.AppendText(Environment.NewLine);
            rtxtbOrderFinal.AppendText(" Discount: ".PadRight(28) + "$0.00");
            rtxtbOrderFinal.AppendText(Environment.NewLine);
            rtxtbOrderFinal.AppendText(" Tax: ".PadRight(28) + "$0.00");

            rtxtbOrderFinal.AppendText(Environment.NewLine);
            rtxtbOrderFinal.AppendText(Environment.NewLine);
            rtxtbOrderFinal.AppendText(Environment.NewLine);
            rtxtbOrderFinal.AppendText("------------------------------------");
            rtxtbOrderFinal.AppendText(Environment.NewLine);

            rtxtbOrderFinal.AppendText(" Total: ".PadRight(28) + "$" + totalPrice.ToString());
            rtxtbOrderFinal.AppendText(Environment.NewLine);
        }


        //Prints the list of items in this order!
        void debugTest()
        {
            for (int i = 0; i < Orders.Count; i++)
            {
                Debug.Print(Orders[i].foodItem.name);
            }
        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            // Hides main ordering screen
            pnlOrderFunctions.Visible = false;
            pnlMenuNavigation.Visible = false;

            // Shows cash out screen 
            pnlCashOut.Visible = true;
            pnlCashOut.BringToFront();
            pnlCashOutTools.Visible = true;
            pnlCashOutTools.BringToFront();
            gpbxPaymentType.Visible = true;
            gpbxPaymentType.BringToFront();
            cashpayment = true;
            btnCashOption.BackColor = Color.LightCyan;
        }

        private void btnFAQ_Click(object sender, EventArgs e)
        {
            FormProvider.FAQForm.Show();
        }

        private void btnPage2_Click(object sender, EventArgs e)
        {
            this.pnlMenuPage1.Visible = false;
            this.pnlMenuPage2.Visible = true;
        }

        private void btnPage1_Click(object sender, EventArgs e)
        {
            this.pnlMenuPage1.Visible = true;
            this.pnlMenuPage2.Visible = false;
        }

        public void btn10_Click(object sender, EventArgs e)
        {
            string objname = ((Button)sender).Name;
            addToOder(objname);
        }

        private void pnlOrdering_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {

        }

        private void btnGoToManagerMode_Click(object sender, EventArgs e)
        {
            FormProvider.managerForm.Show();
            this.Hide();
        }

        private void lblEmployeeName_Click(object sender, EventArgs e)
        {

        }

        private void btnCancelOrder_Click(object sender, EventArgs e)
        {
            // Erases all elements from the Orders list
            Orders.Clear();
            nextopenindex = 0;
            calculateOrderTotal();
            PrintOrders();
            pnlMenuPage1.Visible = true;
            pnlMenuPage2.Visible = false;
            button1.Enabled = true;
        }



        //--------------------------------------------------------- Numeric Keypad ----------------------------------------------//

        public void updateKeypadDisplay(string num)
        {
            txtbKeypad.Text = txtbKeypad.Text + num;
        }

        private void btn1Keypad_Click(object sender, EventArgs e)
        {
            updateKeypadDisplay("1");
        }
        private void btn2Keypad_Click(object sender, EventArgs e)
        {
            updateKeypadDisplay("2");
        }

        private void btn3Keypad_Click(object sender, EventArgs e)
        {
            updateKeypadDisplay("3");
        }

        private void btn4Keypad_Click(object sender, EventArgs e)
        {
            updateKeypadDisplay("4");
        }

        private void btn5Kepad_Click(object sender, EventArgs e)
        {
            updateKeypadDisplay("5");
        }

        private void btn6Keypad_Click(object sender, EventArgs e)
        {
            updateKeypadDisplay("6");
        }

        private void btn7Keypad_Click(object sender, EventArgs e)
        {
            updateKeypadDisplay("7");
        }

        private void btn8Keypad_Click(object sender, EventArgs e)
        {
            updateKeypadDisplay("8");
        }

        private void btn9Keypad_Click(object sender, EventArgs e)
        {
            updateKeypadDisplay("9");
        }

        private void btn0Keypad_Click(object sender, EventArgs e)
        {
            updateKeypadDisplay("0");
        }

        private void btnClearKeypad_Click(object sender, EventArgs e)
        {
            txtbKeypad.ResetText();
        }

        private void btnKeypadEnter_Click(object sender, EventArgs e)
        {
            pnlOrdering.BringToFront();
            pnlOrdering.Enabled = true;
        }

        private void btnQuantity_Click(object sender, EventArgs e)
        {
            pnlKeypad.Visible = true;
            pnlKeypad.BringToFront();
            pnlOrdering.Enabled = false;
        }

        private void btnMessage_Click(object sender, EventArgs e)
        {
            txtbMessageDisplay.Text = "";
            pnlMessageKeyboard.Visible = true;
            pnlMessageKeyboard.BringToFront();
            pnlOrdering.Enabled = false;
        }

        private void btnEnterMessage_Click(object sender, EventArgs e)
        {
            int index = lstbOrders.SelectedIndex;

            if (index != -1)
            {
                for (int i = 0; i < Orders.Count; i++)
                {
                    if (Orders[i].myindex == index)
                    {
                        if (Orders[i].message == false)
                        {
                            Orders[i].message = true;
                            Orders[i].strmessage[Orders[i].nummessages] = txtbMessageDisplay.Text;
                            Orders[i].nummessages++;
                            nextopenindex++;
                            Debug.Print("This is my message " + Orders[i].strmessage[0].ToString() + "I am a " + Orders[i].foodItem.name.ToString());
                        }
                        else
                        {
                            if (Orders[i].nummessages < 5)
                            {
                                Orders[i].strmessage[Orders[i].nummessages] = txtbMessageDisplay.Text;
                                Orders[i].nummessages++;
                                nextopenindex++;
                                Debug.Print("This is my message " + Orders[i].strmessage[0].ToString() + "I am a " + Orders[i].foodItem.name.ToString());
                            }
                        }
                    }
                }
                PrintOrders();
                pnlMessageKeyboard.Visible = false;
                pnlOrdering.Enabled = true;
            }

            /*
            int index = lstbOrders.SelectedIndex;
            if (index != -1)
            {
                if (Orders[index].nummessages < 5)
                {
                    if (!Orders[index].message)
                    {
                        Orders[index].message = true;
                        Orders[index].strmessage[Orders[index].nummessages] = txtbMessageDisplay.Text;
                        Debug.Print(Orders[index].strmessage[Orders[index].nummessages].ToString());
                    }
                    else
                    {
                        Orders[index].strmessage[Orders[index].nummessages] = txtbMessageDisplay.Text;
                    }
                    Orders[index].incrementmessage();
                    PrintOrders();
                    pnlMessageKeyboard.Visible = false;
                    pnlOrdering.Enabled = true;
                }
            }
            */
        }

        private void btnCancelMessage_Click(object sender, EventArgs e)
        {
            pnlMessageKeyboard.Visible = false;
            pnlOrdering.Enabled = true;
        }

        public void handedness(bool lefthanded)
        {
            if (lefthanded)
            {
                pnlButtonSection.Location = new Point(26, 186);
                pnlOrderFunctions.Location = new Point(826, 186);
                pnlCurrentOrder.Location = new Point(1082, 186);
            }
            else
            {
                pnlButtonSection.Location = new Point(746, 186);
                pnlOrderFunctions.Location = new Point(522, 186);
                pnlCurrentOrder.Location = new Point(35, 186);
            }
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }


        //------------------------------------------------- Message Keyboard and Keypad ------------------------------------------//

        public void updateMessageDisplay(string num)
        {
            txtbMessageDisplay.Text = txtbMessageDisplay.Text + num;
        }
        private void btnA_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("A");
        }

        private void btnB_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("B");
        }

        private void btnC_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("C");
        }

        private void btnD_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("D");
        }

        private void btnE_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("E");
        }

        private void btnF_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("F");
        }

        private void btnG_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("G");
        }

        private void btnH_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("H");
        }

        private void btnI_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("I");
        }

        private void btnJ_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("J");
        }

        private void btnK_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("K");
        }

        private void btnL_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("L");
        }

        private void btnM_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("M");
        }

        private void btnN_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("N");
        }

        private void btnO_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("O");
        }

        private void btnP_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("P");
        }

        private void btnQ_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("Q");
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("R");
        }

        private void btnS_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("S");
        }

        private void btnT_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("T");
        }

        private void btnU_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("U");
        }

        private void btnV_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("V");
        }

        private void btnW_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("W");
        }

        private void btnX_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("X");
        }

        private void btnY_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("Y");
        }

        private void btnZ_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("Z");
        }

        private void btnSpaceBar_Click(object sender, EventArgs e)
        {
            updateMessageDisplay(" ");
        }

        private void btnForwardSlash_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("/");
        }

        private void btnExclamationPoint_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("!");
        }

        private void btnComma_Click(object sender, EventArgs e)
        {
            updateMessageDisplay(",");
        }

        private void btnPeriod_Click(object sender, EventArgs e)
        {
            updateMessageDisplay(".");
        }

        private void btn0Keyboard_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("0");
        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("+");
        }

        private void btnMinus_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("-");
        }

        private void btn1Keyboard_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("1");
        }

        private void btn2Keyboard_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("2");
        }

        private void btn3Keyboard_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("3");
        }

        private void btn4Keyboard_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("4");
        }

        private void btn5Keyboard_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("5");
        }

        private void btn6Keyboard_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("6");
        }

        private void btn7Keyboard_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("7");
        }

        private void btn8Keyboard_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("8");
        }

        private void btn9Keyboard_Click(object sender, EventArgs e)
        {
            updateMessageDisplay("9");
        }

        private void btnClearMessageDisplay_Click(object sender, EventArgs e)
        {
            txtbMessageDisplay.Text = "";
        }

        private void btnBackspace_Click(object sender, EventArgs e)
        {
            if (txtbMessageDisplay.Text.Length == 0)
            {
                return;
            }
            else
            {
                txtbMessageDisplay.Text = txtbMessageDisplay.Text.Remove(txtbMessageDisplay.Text.Length - 1);
            }
        }

        // FUnction to calculate new total for cashing out
        public double newTotal(double payment)
        {
            runningtotal = payment - runningtotal;
            return runningtotal;
        }

        private void btnEnterPayment_Click(object sender, EventArgs e)
        {
            double newtotal;
            double changedue;
            if (cashpayment == true)
            {
                double payment = Double.Parse(txtbPaymentAmount.Text);
                newtotal = newTotal(payment);
                if (newtotal > 0.0)
                {
                    // Prompts final cash due panel then returns to oreder screen
                    changedue = newtotal;
                    lblCashDueAmount.Text = "$" + changedue.ToString();
                    pnlTransactionComplete.Visible = true;
                    pnlTransactionComplete.BringToFront();
                    txtbPaymentAmount.Clear();
                    pnlOrdering.Enabled = false;
                    pnlMenuNavigation.Visible = true;
                    pnlCashOut.Visible = false;
                    pnlCashOutTools.Visible = false;
                    pnlOrderFunctions.Visible = true;
                    gpbxPaymentType.Visible = false;
                }
                else if (newtotal < 0.0)
                {
                    // Need 
                    txtbPaymentAmount.Text = runningtotal.ToString();
                }
                else
                {
                    MessageBox.Show("Nothing to cash out");
                }
            }
            else
            {
                lblCashDueAmount.Text = "$0.00";
                pnlTransactionComplete.Visible = true;
                pnlTransactionComplete.BringToFront();
                pnlOrdering.Enabled = false;
            }
            

        }


        //-------------------------------------------------------- Cash-Out Button Panel --------------------------------------------//
        public void updatePaymentDisplay(string num)
        {
            txtbPaymentAmount.Text = txtbPaymentAmount.Text + num;
        }

        private void btn1Payment_Click(object sender, EventArgs e)
        {
            updatePaymentDisplay("1");
        }

        private void btn2Payment_Click(object sender, EventArgs e)
        {
            updatePaymentDisplay("2");
        }

        private void button20_Click(object sender, EventArgs e)
        {

        }

        private void btnZeroPayment_Click(object sender, EventArgs e)
        {
            updatePaymentDisplay("0");
        }

        private void btn3Payment_Click(object sender, EventArgs e)
        {
            updatePaymentDisplay("3");
        }

        private void btn4Payment_Click(object sender, EventArgs e)
        {
            updatePaymentDisplay("4");
        }

        private void btn5Payment_Click(object sender, EventArgs e)
        {
            updatePaymentDisplay("5");
        }

        private void btn6Payment_Click(object sender, EventArgs e)
        {
            updatePaymentDisplay("6");
        }

        private void btn7Payment_Click(object sender, EventArgs e)
        {
            updatePaymentDisplay("7");
        }

        private void btn8Payment_Click(object sender, EventArgs e)
        {
            updatePaymentDisplay("8");
        }

        private void btn9Payment_Click(object sender, EventArgs e)
        {
            updatePaymentDisplay("9");
        }

        private void btnPeriodPayment_Click(object sender, EventArgs e)
        {
            updatePaymentDisplay(".");
        }

        private void btnDoubleZeros_Click(object sender, EventArgs e)
        {
            updatePaymentDisplay("00");
        }

        private void button19_Click(object sender, EventArgs e)
        {
            updatePaymentDisplay(".00");
        }

        private void btnBackspacePayment_Click(object sender, EventArgs e)
        {
            if (txtbPaymentAmount.Text.Length == 0)
            {
                return;
            }
            else
            {
                txtbPaymentAmount.Text = txtbPaymentAmount.Text.Remove(txtbPaymentAmount.Text.Length - 1);
            }
        }

        private void btnClearPayment_Click(object sender, EventArgs e)
        {
            txtbPaymentAmount.Clear();
        }

        private void btnBackToOrder_Click(object sender, EventArgs e)
        {
            pnlMenuNavigation.Visible = true;
            pnlCashOut.Visible = false;
            pnlCashOutTools.Visible = false;
            pnlOrderFunctions.Visible = true;
            gpbxPaymentType.Visible = false;
        }

        private void btnFiveDollars_Click(object sender, EventArgs e)
        {
            runningtotal = newTotal(5.0);
            txtbPaymentAmount.Text = runningtotal.ToString();
        }

        private void btnTenDollars_Click(object sender, EventArgs e)
        {
            runningtotal = newTotal(10.0);
            txtbPaymentAmount.Text = runningtotal.ToString();
        }

        public bool cashpayment;
        public void btnCashOption_Click(object sender, EventArgs e)
        {
            cashpayment = true;
            btnCashOption.BackColor = Color.LightCyan;
            btnCredit.BackColor = SystemColors.GradientActiveCaption;
        }

        public void btnCredit_Click(object sender, EventArgs e)
        {
            cashpayment = false;
            btnCredit.BackColor = Color.LightCyan;
            btnCashOption.BackColor = SystemColors.GradientActiveCaption;
        }

        private void btnTransactionDone_Click(object sender, EventArgs e)
        {
            pnlOrdering.Enabled = true;
            pnlTransactionComplete.Visible = false;
            pnlCashOut.Visible = false;
            pnlCashOutTools.Visible = false;
            pnlOrderFunctions.Visible = true;
            pnlMenuPage1.BringToFront();
            pnlMenuNavigation.Visible = true;
            gpbxPaymentType.Visible = false;
        }








        //Partial Class frmMain
    }   

    //Namespace Ordering
}
