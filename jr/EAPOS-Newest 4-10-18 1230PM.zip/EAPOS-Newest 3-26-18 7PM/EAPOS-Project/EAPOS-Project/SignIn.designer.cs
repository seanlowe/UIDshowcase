﻿namespace SignIn
{
    partial class frmSignIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSignIn));
            this.btnNum1 = new System.Windows.Forms.Button();
            this.btnNum2 = new System.Windows.Forms.Button();
            this.btnNum3 = new System.Windows.Forms.Button();
            this.btnNum4 = new System.Windows.Forms.Button();
            this.btnNum5 = new System.Windows.Forms.Button();
            this.btnNum6 = new System.Windows.Forms.Button();
            this.btnNum7 = new System.Windows.Forms.Button();
            this.btnNum8 = new System.Windows.Forms.Button();
            this.btnNum9 = new System.Windows.Forms.Button();
            this.lblPassword = new System.Windows.Forms.Label();
            this.btnNum0 = new System.Windows.Forms.Button();
            this.pnlSignInScreen = new System.Windows.Forms.Panel();
            this.pnlPassword = new System.Windows.Forms.Panel();
            this.btnBackspace = new System.Windows.Forms.Button();
            this.pnlChooseScreen = new System.Windows.Forms.Panel();
            this.btnBackToSignIn = new System.Windows.Forms.Button();
            this.btnAdminScreen = new System.Windows.Forms.Button();
            this.btnOrderScreen = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblVersion = new System.Windows.Forms.Label();
            this.btnExitApplication = new System.Windows.Forms.Button();
            this.lblCurrentDate = new System.Windows.Forms.Label();
            this.timerTime = new System.Windows.Forms.Timer(this.components);
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pnlSignInScreen.SuspendLayout();
            this.pnlPassword.SuspendLayout();
            this.pnlChooseScreen.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // btnNum1
            // 
            this.btnNum1.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ControlDark;
            this.btnNum1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNum1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.btnNum1.Location = new System.Drawing.Point(55, 136);
            this.btnNum1.Name = "btnNum1";
            this.btnNum1.Size = new System.Drawing.Size(75, 61);
            this.btnNum1.TabIndex = 0;
            this.btnNum1.Text = "1";
            this.btnNum1.UseVisualStyleBackColor = true;
            this.btnNum1.Click += new System.EventHandler(this.btnNum1_Click);
            // 
            // btnNum2
            // 
            this.btnNum2.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ControlDark;
            this.btnNum2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNum2.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.btnNum2.Location = new System.Drawing.Point(136, 136);
            this.btnNum2.Name = "btnNum2";
            this.btnNum2.Size = new System.Drawing.Size(75, 61);
            this.btnNum2.TabIndex = 1;
            this.btnNum2.Text = "2";
            this.btnNum2.UseVisualStyleBackColor = true;
            this.btnNum2.Click += new System.EventHandler(this.btnNum2_Click);
            // 
            // btnNum3
            // 
            this.btnNum3.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ControlDark;
            this.btnNum3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNum3.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.btnNum3.Location = new System.Drawing.Point(217, 136);
            this.btnNum3.Name = "btnNum3";
            this.btnNum3.Size = new System.Drawing.Size(75, 61);
            this.btnNum3.TabIndex = 2;
            this.btnNum3.Text = "3";
            this.btnNum3.UseVisualStyleBackColor = true;
            this.btnNum3.Click += new System.EventHandler(this.btnNum3_Click);
            // 
            // btnNum4
            // 
            this.btnNum4.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ControlDark;
            this.btnNum4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNum4.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.btnNum4.Location = new System.Drawing.Point(55, 203);
            this.btnNum4.Name = "btnNum4";
            this.btnNum4.Size = new System.Drawing.Size(75, 61);
            this.btnNum4.TabIndex = 3;
            this.btnNum4.Text = "4";
            this.btnNum4.UseVisualStyleBackColor = true;
            this.btnNum4.Click += new System.EventHandler(this.btnNum4_Click);
            // 
            // btnNum5
            // 
            this.btnNum5.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ControlDark;
            this.btnNum5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNum5.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.btnNum5.Location = new System.Drawing.Point(136, 203);
            this.btnNum5.Name = "btnNum5";
            this.btnNum5.Size = new System.Drawing.Size(75, 61);
            this.btnNum5.TabIndex = 4;
            this.btnNum5.Text = "5";
            this.btnNum5.UseVisualStyleBackColor = true;
            this.btnNum5.Click += new System.EventHandler(this.btnNum5_Click);
            // 
            // btnNum6
            // 
            this.btnNum6.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ControlDark;
            this.btnNum6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNum6.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.btnNum6.Location = new System.Drawing.Point(217, 203);
            this.btnNum6.Name = "btnNum6";
            this.btnNum6.Size = new System.Drawing.Size(75, 61);
            this.btnNum6.TabIndex = 5;
            this.btnNum6.Text = "6";
            this.btnNum6.UseVisualStyleBackColor = true;
            this.btnNum6.Click += new System.EventHandler(this.btnNum6_Click);
            // 
            // btnNum7
            // 
            this.btnNum7.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ControlDark;
            this.btnNum7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNum7.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.btnNum7.Location = new System.Drawing.Point(55, 270);
            this.btnNum7.Name = "btnNum7";
            this.btnNum7.Size = new System.Drawing.Size(75, 61);
            this.btnNum7.TabIndex = 6;
            this.btnNum7.Text = "7";
            this.btnNum7.UseVisualStyleBackColor = true;
            this.btnNum7.Click += new System.EventHandler(this.btnNum7_Click);
            // 
            // btnNum8
            // 
            this.btnNum8.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ControlDark;
            this.btnNum8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNum8.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.btnNum8.Location = new System.Drawing.Point(136, 270);
            this.btnNum8.Name = "btnNum8";
            this.btnNum8.Size = new System.Drawing.Size(75, 61);
            this.btnNum8.TabIndex = 7;
            this.btnNum8.Text = "8";
            this.btnNum8.UseVisualStyleBackColor = true;
            this.btnNum8.Click += new System.EventHandler(this.btnNum8_Click);
            // 
            // btnNum9
            // 
            this.btnNum9.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ControlDark;
            this.btnNum9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNum9.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.btnNum9.Location = new System.Drawing.Point(217, 270);
            this.btnNum9.Name = "btnNum9";
            this.btnNum9.Size = new System.Drawing.Size(75, 61);
            this.btnNum9.TabIndex = 8;
            this.btnNum9.Text = "9";
            this.btnNum9.UseVisualStyleBackColor = true;
            this.btnNum9.Click += new System.EventHandler(this.btnNum9_Click);
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.BackColor = System.Drawing.Color.Transparent;
            this.lblPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.lblPassword.ForeColor = System.Drawing.SystemColors.Control;
            this.lblPassword.Location = new System.Drawing.Point(24, 11);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(109, 39);
            this.lblPassword.TabIndex = 9;
            this.lblPassword.Text = "label1";
            // 
            // btnNum0
            // 
            this.btnNum0.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ControlDark;
            this.btnNum0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNum0.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.btnNum0.Location = new System.Drawing.Point(136, 337);
            this.btnNum0.Name = "btnNum0";
            this.btnNum0.Size = new System.Drawing.Size(75, 61);
            this.btnNum0.TabIndex = 10;
            this.btnNum0.Text = "0";
            this.btnNum0.UseVisualStyleBackColor = true;
            this.btnNum0.Click += new System.EventHandler(this.btnNum0_Click);
            // 
            // pnlSignInScreen
            // 
            this.pnlSignInScreen.BackColor = System.Drawing.SystemColors.Control;
            this.pnlSignInScreen.Controls.Add(this.pnlPassword);
            this.pnlSignInScreen.Controls.Add(this.btnBackspace);
            this.pnlSignInScreen.Controls.Add(this.btnNum1);
            this.pnlSignInScreen.Controls.Add(this.btnNum0);
            this.pnlSignInScreen.Controls.Add(this.btnNum2);
            this.pnlSignInScreen.Controls.Add(this.btnNum3);
            this.pnlSignInScreen.Controls.Add(this.btnNum9);
            this.pnlSignInScreen.Controls.Add(this.btnNum4);
            this.pnlSignInScreen.Controls.Add(this.btnNum8);
            this.pnlSignInScreen.Controls.Add(this.btnNum5);
            this.pnlSignInScreen.Controls.Add(this.btnNum7);
            this.pnlSignInScreen.Controls.Add(this.btnNum6);
            this.pnlSignInScreen.Location = new System.Drawing.Point(600, 258);
            this.pnlSignInScreen.Name = "pnlSignInScreen";
            this.pnlSignInScreen.Size = new System.Drawing.Size(346, 446);
            this.pnlSignInScreen.TabIndex = 12;
            // 
            // pnlPassword
            // 
            this.pnlPassword.BackColor = System.Drawing.Color.Black;
            this.pnlPassword.Controls.Add(this.lblPassword);
            this.pnlPassword.Location = new System.Drawing.Point(55, 69);
            this.pnlPassword.Name = "pnlPassword";
            this.pnlPassword.Size = new System.Drawing.Size(156, 61);
            this.pnlPassword.TabIndex = 14;
            // 
            // btnBackspace
            // 
            this.btnBackspace.BackColor = System.Drawing.Color.Red;
            this.btnBackspace.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBackspace.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btnBackspace.Location = new System.Drawing.Point(217, 69);
            this.btnBackspace.Name = "btnBackspace";
            this.btnBackspace.Size = new System.Drawing.Size(75, 61);
            this.btnBackspace.TabIndex = 13;
            this.btnBackspace.Text = "<=";
            this.btnBackspace.UseVisualStyleBackColor = false;
            this.btnBackspace.Click += new System.EventHandler(this.btnBackspace_Click);
            // 
            // pnlChooseScreen
            // 
            this.pnlChooseScreen.BackColor = System.Drawing.SystemColors.Control;
            this.pnlChooseScreen.Controls.Add(this.btnBackToSignIn);
            this.pnlChooseScreen.Controls.Add(this.btnAdminScreen);
            this.pnlChooseScreen.Controls.Add(this.btnOrderScreen);
            this.pnlChooseScreen.Location = new System.Drawing.Point(391, 213);
            this.pnlChooseScreen.Name = "pnlChooseScreen";
            this.pnlChooseScreen.Size = new System.Drawing.Size(764, 536);
            this.pnlChooseScreen.TabIndex = 13;
            this.pnlChooseScreen.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlChooseScreen_Paint);
            // 
            // btnBackToSignIn
            // 
            this.btnBackToSignIn.BackColor = System.Drawing.Color.Red;
            this.btnBackToSignIn.FlatAppearance.BorderSize = 0;
            this.btnBackToSignIn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnBackToSignIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBackToSignIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.btnBackToSignIn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnBackToSignIn.Location = new System.Drawing.Point(686, 445);
            this.btnBackToSignIn.Name = "btnBackToSignIn";
            this.btnBackToSignIn.Size = new System.Drawing.Size(75, 88);
            this.btnBackToSignIn.TabIndex = 2;
            this.btnBackToSignIn.Text = "X";
            this.btnBackToSignIn.UseVisualStyleBackColor = false;
            this.btnBackToSignIn.Click += new System.EventHandler(this.btnBackToSignIn_Click);
            // 
            // btnAdminScreen
            // 
            this.btnAdminScreen.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ControlDark;
            this.btnAdminScreen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdminScreen.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.btnAdminScreen.Location = new System.Drawing.Point(428, 155);
            this.btnAdminScreen.Name = "btnAdminScreen";
            this.btnAdminScreen.Size = new System.Drawing.Size(249, 102);
            this.btnAdminScreen.TabIndex = 1;
            this.btnAdminScreen.Text = "Admin Functions";
            this.btnAdminScreen.UseVisualStyleBackColor = true;
            this.btnAdminScreen.Click += new System.EventHandler(this.btnAdminScreen_Click);
            // 
            // btnOrderScreen
            // 
            this.btnOrderScreen.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ControlDark;
            this.btnOrderScreen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOrderScreen.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.btnOrderScreen.Location = new System.Drawing.Point(87, 155);
            this.btnOrderScreen.Name = "btnOrderScreen";
            this.btnOrderScreen.Size = new System.Drawing.Size(249, 102);
            this.btnOrderScreen.TabIndex = 0;
            this.btnOrderScreen.Text = "Order Menu";
            this.btnOrderScreen.UseVisualStyleBackColor = true;
            this.btnOrderScreen.Click += new System.EventHandler(this.btnOrderScreen_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(214, 155);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // lblVersion
            // 
            this.lblVersion.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVersion.ForeColor = System.Drawing.Color.White;
            this.lblVersion.Location = new System.Drawing.Point(1085, 900);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(450, 54);
            this.lblVersion.TabIndex = 15;
            this.lblVersion.Text = "PROTOTYPE Version 1.7\n\r\n\r\n";
            // 
            // btnExitApplication
            // 
            this.btnExitApplication.BackColor = System.Drawing.Color.OrangeRed;
            this.btnExitApplication.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExitApplication.Location = new System.Drawing.Point(1230, 846);
            this.btnExitApplication.Name = "btnExitApplication";
            this.btnExitApplication.Size = new System.Drawing.Size(305, 51);
            this.btnExitApplication.TabIndex = 16;
            this.btnExitApplication.Text = "EXIT PROTOTYPE";
            this.btnExitApplication.UseVisualStyleBackColor = false;
            this.btnExitApplication.Click += new System.EventHandler(this.btnExitApplication_Click);
            // 
            // lblCurrentDate
            // 
            this.lblCurrentDate.BackColor = System.Drawing.Color.OrangeRed;
            this.lblCurrentDate.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentDate.Location = new System.Drawing.Point(1289, 0);
            this.lblCurrentDate.Name = "lblCurrentDate";
            this.lblCurrentDate.Size = new System.Drawing.Size(259, 52);
            this.lblCurrentDate.TabIndex = 17;
            this.lblCurrentDate.Text = "Current Date";
            this.lblCurrentDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timerTime
            // 
            this.timerTime.Tick += new System.EventHandler(this.timerTime_Tick);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(19, 868);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(299, 83);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 19;
            this.pictureBox2.TabStop = false;
            // 
            // frmSignIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1547, 963);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.lblCurrentDate);
            this.Controls.Add(this.btnExitApplication);
            this.Controls.Add(this.lblVersion);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pnlSignInScreen);
            this.Controls.Add(this.pnlChooseScreen);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmSignIn";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "sign in screen";
            this.Load += new System.EventHandler(this.frmSignIn_Load);
            this.pnlSignInScreen.ResumeLayout(false);
            this.pnlPassword.ResumeLayout(false);
            this.pnlPassword.PerformLayout();
            this.pnlChooseScreen.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnNum1;
        private System.Windows.Forms.Button btnNum2;
        private System.Windows.Forms.Button btnNum3;
        private System.Windows.Forms.Button btnNum4;
        private System.Windows.Forms.Button btnNum5;
        private System.Windows.Forms.Button btnNum6;
        private System.Windows.Forms.Button btnNum7;
        private System.Windows.Forms.Button btnNum8;
        private System.Windows.Forms.Button btnNum9;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Button btnNum0;
        private System.Windows.Forms.Panel pnlSignInScreen;
        private System.Windows.Forms.Button btnBackspace;
        private System.Windows.Forms.Panel pnlPassword;
        private System.Windows.Forms.Panel pnlChooseScreen;
        private System.Windows.Forms.Button btnAdminScreen;
        private System.Windows.Forms.Button btnOrderScreen;
        private System.Windows.Forms.Button btnBackToSignIn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.Button btnExitApplication;
        private System.Windows.Forms.Label lblCurrentDate;
        private System.Windows.Forms.Timer timerTime;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

