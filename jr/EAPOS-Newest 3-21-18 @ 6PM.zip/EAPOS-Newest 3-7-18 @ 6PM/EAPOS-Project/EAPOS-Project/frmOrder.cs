﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using SignIn;
using WindowsFormsApplication1;
using EAPOS_Project;

namespace Ordering
{
    public partial class frmMain : Form
    {  
        
        //Class for the order Items
        public class orderItem
        {
            public string type;
            public int quantity;
            public double price;

            //Constructor
            public orderItem(int inputQuantity, string inputType,  double inputPrice)
            {
                type = inputType;
                quantity = inputQuantity;
                price = inputPrice;
            }       
        }

        //Dynamic linked list of orderItems
        List<orderItem> Orders = new List<orderItem>();

        int numBurgers = 0;
        int numPizzas = 0;
        int numHotDogs = 0;
        int numPizzaSlices = 0;
        int numChicken = 0;
        int numCoffee = 0;
        int numIceCream = 0;
        int numBagel = 0;
        int numSoda = 0;

        public frmMain()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormProvider.signInForm.Show();

            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string width;
            string height;

            width = this.Width.ToString();
            height = this.Height.ToString();

            lblResolution.Text = "Height: " + height + " Width: " + width;

        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            //lstbOrders.Font = new Font(FontFamily.GenericMonospace, lstbOrders.Font.Size);
            OrderingTimer.Enabled = true;
            this.Location = new Point(0, 0);
            this.Size = Screen.PrimaryScreen.WorkingArea.Size;
            lstbOrders.Text = "";
            lblLabelReceipt.Text = "Qty".PadRight(5) + "Description".PadRight(21) + "Amount($)";
           
        }

        private void OrderingTimer_Tick(object sender, EventArgs e)
        {
            lblCurrentDate.Text = DateTime.Now.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            AddItemToOrder(ref numBurgers, "Burger", 4.99);
        }

        private void btnWholePizza_Click(object sender, EventArgs e)
        {
            AddItemToOrder(ref numPizzas, "Pizza", 19.99);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(lstbOrders.SelectedIndex != -1)
            {
                //Removes the order item from the linked list
                int indexOfItemInList = 0;
                indexOfItemInList = lstbOrders.SelectedIndex;
                string itemRemoved = Orders[indexOfItemInList].type;
                Orders.RemoveAt(indexOfItemInList);

                //Resets the counter to add item again
                if (itemRemoved == "Burger")
                    numBurgers = 0;
                else if (itemRemoved == "HotDog")
                    numHotDogs = 0;
                else if (itemRemoved == "Pizza")
                    numPizzas = 0;
                else if (itemRemoved == "Pizza Slice")
                    numPizzaSlices = 0;
                else if (itemRemoved == "Chicken")
                    numChicken = 0;
                else if (itemRemoved == "Coffee")
                    numCoffee = 0;
                else if (itemRemoved == "Soda")
                    numSoda = 0;
                else if (itemRemoved == "Bagel")
                    numBagel = 0;
                else if (itemRemoved == "IceCream")
                    numBagel = 0;


                //The cosmetic aspect
                calculateOrderTotal();
                lstbOrders.Items.Remove(lstbOrders.SelectedItem);
                lstbOrders.Refresh();

            }          
        }

        private void btnHotDog_Click(object sender, EventArgs e)
        {
            AddItemToOrder(ref numHotDogs, "HotDog", 2.25);
        }

        private void btnPizzaSlice_Click(object sender, EventArgs e)
        {
            AddItemToOrder(ref numPizzaSlices, "Pizza Slice", 2.99);
        }

        private void btnChicken_Click(object sender, EventArgs e)
        {          
            AddItemToOrder(ref numChicken, "Chicken", 3.99);
        }

        private void btnCoffee_Click(object sender, EventArgs e)
        {          
            AddItemToOrder(ref numCoffee, "Coffee", 3.25);
        }

        private void btnSode_Click(object sender, EventArgs e)
        {           
            AddItemToOrder(ref numSoda, "Soda", 1.99);
        }

        private void btnBagel_Click(object sender, EventArgs e)
        {           
            AddItemToOrder(ref numBagel, "Bagel", 1.25);
        }

        private void btnIceCream_Click(object sender, EventArgs e)
        {           
            AddItemToOrder(ref numIceCream, "IceCream", 2.25);

        }

        void PrintOrders()
        {
            //Clears the listbox in the ordering form
            lstbOrders.Items.Clear();

            for(int i = 0; i < Orders.Count; i++)
            {
                string type = Orders[i].type;
                int quantity = Orders[i].quantity;
                double price = Orders[i].price;       
                string strPrice = string.Format("{0:C}", price);

                string orderline = quantity.ToString().PadRight(5) + type.PadRight(21) + strPrice;
               
               
                lstbOrders.Items.Add(orderline);
                


            }
        }

        void AddItemToOrder(ref int quantity, string name, double price)
        {
            if (quantity == 0)
            {
                Orders.Add(new orderItem(1, name, price));
                quantity++;
            }
            else
            {
                for (int i = 0; i < Orders.Count; i++)
                {
                    if (Orders[i].type == name)
                    {
                        quantity++;
                        Orders[i] = new orderItem(quantity, name, price);
                        break;
                    }
                }
            }
            PrintOrders();
            calculateOrderTotal();
        }

        void calculateOrderTotal()
        {
            //Calculates the total price
            double totalPrice = 0;
            for (int i = 0; i < Orders.Count; i++)
            {
                totalPrice = totalPrice + (Orders[i].price * Orders[i].quantity);
            }

            rtxtbOrderFinal.Clear();
            rtxtbOrderFinal.AppendText(" Subtotal: ".PadRight(28) + "$" + totalPrice.ToString());
            rtxtbOrderFinal.AppendText(Environment.NewLine);
            rtxtbOrderFinal.AppendText(" Discount: ".PadRight(28) + "$0.00");
            rtxtbOrderFinal.AppendText(Environment.NewLine);
            rtxtbOrderFinal.AppendText(" Tax: ".PadRight(28) + "$0.00");

            rtxtbOrderFinal.AppendText(Environment.NewLine);         
            rtxtbOrderFinal.AppendText(Environment.NewLine);
            rtxtbOrderFinal.AppendText(Environment.NewLine);
            rtxtbOrderFinal.AppendText("------------------------------------");
            rtxtbOrderFinal.AppendText(Environment.NewLine);

            rtxtbOrderFinal.AppendText(" Total: ".PadRight(28) + "$" + totalPrice.ToString());
            rtxtbOrderFinal.AppendText(Environment.NewLine);
        }

        void debugTest()
        {
            for (int i = 0; i < Orders.Count; i++)
            {
                Debug.Print(Orders[i].type);
            }
        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            debugTest();
        }

        private void btnFAQ_Click(object sender, EventArgs e)
        {
            FormProvider.FAQForm.Show();
        }

        private void btnPage2_Click(object sender, EventArgs e)
        {
            this.pnlMenuPage1.Visible = false;
            this.pnlMenuPage2.Visible = true;
        }

        private void btnPage1_Click(object sender, EventArgs e)
        {
            this.pnlMenuPage1.Visible = true;
            this.pnlMenuPage2.Visible = false;
        }

        public void btn10_Click(object sender, EventArgs e)
        {
            //string name;
            //double price;


            //AddItemToOrder(ref name, "Soda", 1.99);


        }

        //Partial Class frmMain
    }   

    //Namespace Ordering
}
