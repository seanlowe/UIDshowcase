﻿namespace Ordering
{
    partial class frmMain
    {

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        public void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.button1 = new System.Windows.Forms.Button();
            this.lblResolution = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.lstbOrders = new System.Windows.Forms.ListBox();
            this.rtxtbOrderFinal = new System.Windows.Forms.RichTextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.OrderingTimer = new System.Windows.Forms.Timer(this.components);
            this.pnlOrderItems = new System.Windows.Forms.Panel();
            this.pnlMenuPage1 = new System.Windows.Forms.Panel();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.pnlSizes = new System.Windows.Forms.Panel();
            this.btnSmall = new System.Windows.Forms.Button();
            this.btnLarge = new System.Windows.Forms.Button();
            this.btnMedium = new System.Windows.Forms.Button();
            this.pnlIceCreamFlavors = new System.Windows.Forms.Panel();
            this.btnFlavors1 = new System.Windows.Forms.Button();
            this.btnFlavors5 = new System.Windows.Forms.Button();
            this.btnFlavors8 = new System.Windows.Forms.Button();
            this.btnFlavors9 = new System.Windows.Forms.Button();
            this.btnFlavors3 = new System.Windows.Forms.Button();
            this.btnFlavors7 = new System.Windows.Forms.Button();
            this.btnFlavors2 = new System.Windows.Forms.Button();
            this.btnFlavors6 = new System.Windows.Forms.Button();
            this.btnFlavors4 = new System.Windows.Forms.Button();
            this.pnlMenuPage2 = new System.Windows.Forms.Panel();
            this.btn10 = new System.Windows.Forms.Button();
            this.btn14 = new System.Windows.Forms.Button();
            this.btn17 = new System.Windows.Forms.Button();
            this.btn18 = new System.Windows.Forms.Button();
            this.btn12 = new System.Windows.Forms.Button();
            this.btn16 = new System.Windows.Forms.Button();
            this.btn11 = new System.Windows.Forms.Button();
            this.btn15 = new System.Windows.Forms.Button();
            this.btn13 = new System.Windows.Forms.Button();
            this.pnlAddOns = new System.Windows.Forms.Panel();
            this.btnAdd1 = new System.Windows.Forms.Button();
            this.btnAdd5 = new System.Windows.Forms.Button();
            this.btnAdd8 = new System.Windows.Forms.Button();
            this.btnAdd9 = new System.Windows.Forms.Button();
            this.btnAdd3 = new System.Windows.Forms.Button();
            this.btnAdd7 = new System.Windows.Forms.Button();
            this.btnAdd2 = new System.Windows.Forms.Button();
            this.btnAdd6 = new System.Windows.Forms.Button();
            this.btnAdd4 = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.lblCurrentDate = new System.Windows.Forms.Label();
            this.btnDeleteItem = new System.Windows.Forms.Button();
            this.btnPay = new System.Windows.Forms.Button();
            this.lblEmployeeName = new System.Windows.Forms.Label();
            this.lblLabelReceipt = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnQuantity = new System.Windows.Forms.Button();
            this.btnFAQ = new System.Windows.Forms.Button();
            this.pnlOrderFunctions = new System.Windows.Forms.Panel();
            this.btnSuspendOrder = new System.Windows.Forms.Button();
            this.btnCancelOrder = new System.Windows.Forms.Button();
            this.btnOrderHistory = new System.Windows.Forms.Button();
            this.btnGoToManagerMode = new System.Windows.Forms.Button();
            this.btnPaidOut = new System.Windows.Forms.Button();
            this.btnHouseCharge = new System.Windows.Forms.Button();
            this.btnRefund = new System.Windows.Forms.Button();
            this.btnLabor = new System.Windows.Forms.Button();
            this.btnPage1 = new System.Windows.Forms.Button();
            this.btnPage2 = new System.Windows.Forms.Button();
            this.btnPage3 = new System.Windows.Forms.Button();
            this.btnPage4 = new System.Windows.Forms.Button();
            this.btnPage5 = new System.Windows.Forms.Button();
            this.pnlKeypad = new System.Windows.Forms.Panel();
            this.btn0Keypad = new System.Windows.Forms.Button();
            this.txtbKeypad = new System.Windows.Forms.TextBox();
            this.btn3Keypad = new System.Windows.Forms.Button();
            this.btn2Keypad = new System.Windows.Forms.Button();
            this.btn1Keypad = new System.Windows.Forms.Button();
            this.btn6Keypad = new System.Windows.Forms.Button();
            this.btn5Kepad = new System.Windows.Forms.Button();
            this.btn4Keypad = new System.Windows.Forms.Button();
            this.btn9Keypad = new System.Windows.Forms.Button();
            this.btn8Keypad = new System.Windows.Forms.Button();
            this.btn7Keypad = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.pnlButtonSection = new System.Windows.Forms.Panel();
            this.pnlCurrentOrder = new System.Windows.Forms.Panel();
            this.pnlOrdering = new System.Windows.Forms.Panel();
            this.pnlManagerFunctions = new System.Windows.Forms.Panel();
            this.pnlMenuNavigation = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlOrderItems.SuspendLayout();
            this.pnlMenuPage1.SuspendLayout();
            this.pnlSizes.SuspendLayout();
            this.pnlIceCreamFlavors.SuspendLayout();
            this.pnlMenuPage2.SuspendLayout();
            this.pnlAddOns.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.pnlOrderFunctions.SuspendLayout();
            this.pnlKeypad.SuspendLayout();
            this.pnlButtonSection.SuspendLayout();
            this.pnlCurrentOrder.SuspendLayout();
            this.pnlOrdering.SuspendLayout();
            this.pnlManagerFunctions.SuspendLayout();
            this.pnlMenuNavigation.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1418, 68);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(146, 47);
            this.button1.TabIndex = 0;
            this.button1.Text = "Sign Out";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblResolution
            // 
            this.lblResolution.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResolution.Location = new System.Drawing.Point(267, 82);
            this.lblResolution.Name = "lblResolution";
            this.lblResolution.Size = new System.Drawing.Size(181, 33);
            this.lblResolution.TabIndex = 1;
            this.lblResolution.Text = "Resolution";
            this.lblResolution.Visible = false;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(271, 43);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(177, 34);
            this.button2.TabIndex = 2;
            this.button2.Text = "Get Resolution";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lstbOrders
            // 
            this.lstbOrders.BackColor = System.Drawing.SystemColors.Info;
            this.lstbOrders.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstbOrders.FormattingEnabled = true;
            this.lstbOrders.ItemHeight = 24;
            this.lstbOrders.Location = new System.Drawing.Point(3, 46);
            this.lstbOrders.Name = "lstbOrders";
            this.lstbOrders.Size = new System.Drawing.Size(440, 436);
            this.lstbOrders.TabIndex = 3;
            // 
            // rtxtbOrderFinal
            // 
            this.rtxtbOrderFinal.BackColor = System.Drawing.SystemColors.Info;
            this.rtxtbOrderFinal.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtxtbOrderFinal.Location = new System.Drawing.Point(3, 520);
            this.rtxtbOrderFinal.Name = "rtxtbOrderFinal";
            this.rtxtbOrderFinal.ReadOnly = true;
            this.rtxtbOrderFinal.Size = new System.Drawing.Size(440, 242);
            this.rtxtbOrderFinal.TabIndex = 4;
            this.rtxtbOrderFinal.Text = "";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(214, 155);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // OrderingTimer
            // 
            this.OrderingTimer.Tick += new System.EventHandler(this.OrderingTimer_Tick);
            // 
            // pnlOrderItems
            // 
            this.pnlOrderItems.BackColor = System.Drawing.SystemColors.Info;
            this.pnlOrderItems.Controls.Add(this.pnlMenuPage1);
            this.pnlOrderItems.Controls.Add(this.pnlSizes);
            this.pnlOrderItems.Controls.Add(this.pnlIceCreamFlavors);
            this.pnlOrderItems.Controls.Add(this.pnlMenuPage2);
            this.pnlOrderItems.Controls.Add(this.pnlAddOns);
            this.pnlOrderItems.Location = new System.Drawing.Point(9, 49);
            this.pnlOrderItems.Name = "pnlOrderItems";
            this.pnlOrderItems.Size = new System.Drawing.Size(738, 620);
            this.pnlOrderItems.TabIndex = 7;
            // 
            // pnlMenuPage1
            // 
            this.pnlMenuPage1.Controls.Add(this.btn1);
            this.pnlMenuPage1.Controls.Add(this.btn5);
            this.pnlMenuPage1.Controls.Add(this.btn8);
            this.pnlMenuPage1.Controls.Add(this.btn9);
            this.pnlMenuPage1.Controls.Add(this.btn3);
            this.pnlMenuPage1.Controls.Add(this.btn7);
            this.pnlMenuPage1.Controls.Add(this.btn2);
            this.pnlMenuPage1.Controls.Add(this.btn6);
            this.pnlMenuPage1.Controls.Add(this.btn4);
            this.pnlMenuPage1.Location = new System.Drawing.Point(34, 25);
            this.pnlMenuPage1.Name = "pnlMenuPage1";
            this.pnlMenuPage1.Size = new System.Drawing.Size(671, 559);
            this.pnlMenuPage1.TabIndex = 29;
            // 
            // btn1
            // 
            this.btn1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn1.Location = new System.Drawing.Point(0, 0);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(168, 169);
            this.btn1.TabIndex = 20;
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Visible = false;
            this.btn1.Click += new System.EventHandler(this.button5_Click);
            // 
            // btn5
            // 
            this.btn5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn5.Location = new System.Drawing.Point(258, 198);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(168, 169);
            this.btn5.TabIndex = 28;
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Visible = false;
            this.btn5.Click += new System.EventHandler(this.btnChicken_Click);
            // 
            // btn8
            // 
            this.btn8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn8.Location = new System.Drawing.Point(258, 390);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(168, 169);
            this.btn8.TabIndex = 21;
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Visible = false;
            this.btn8.Click += new System.EventHandler(this.btnBagel_Click);
            // 
            // btn9
            // 
            this.btn9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn9.Location = new System.Drawing.Point(503, 390);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(168, 169);
            this.btn9.TabIndex = 27;
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Visible = false;
            this.btn9.Click += new System.EventHandler(this.btnSode_Click);
            // 
            // btn3
            // 
            this.btn3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn3.Location = new System.Drawing.Point(503, 0);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(168, 169);
            this.btn3.TabIndex = 22;
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Visible = false;
            this.btn3.Click += new System.EventHandler(this.btnHotDog_Click);
            // 
            // btn7
            // 
            this.btn7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn7.Location = new System.Drawing.Point(0, 390);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(168, 169);
            this.btn7.TabIndex = 26;
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Visible = false;
            this.btn7.Click += new System.EventHandler(this.btnIceCream_Click);
            // 
            // btn2
            // 
            this.btn2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn2.Location = new System.Drawing.Point(258, 0);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(168, 169);
            this.btn2.TabIndex = 23;
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Visible = false;
            this.btn2.Click += new System.EventHandler(this.btnWholePizza_Click);
            // 
            // btn6
            // 
            this.btn6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn6.Location = new System.Drawing.Point(503, 198);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(168, 169);
            this.btn6.TabIndex = 25;
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Visible = false;
            this.btn6.Click += new System.EventHandler(this.btnCoffee_Click);
            // 
            // btn4
            // 
            this.btn4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn4.Location = new System.Drawing.Point(0, 198);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(168, 169);
            this.btn4.TabIndex = 24;
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Visible = false;
            this.btn4.Click += new System.EventHandler(this.btnPizzaSlice_Click);
            // 
            // pnlSizes
            // 
            this.pnlSizes.Controls.Add(this.btnSmall);
            this.pnlSizes.Controls.Add(this.btnLarge);
            this.pnlSizes.Controls.Add(this.btnMedium);
            this.pnlSizes.Location = new System.Drawing.Point(34, 25);
            this.pnlSizes.Name = "pnlSizes";
            this.pnlSizes.Size = new System.Drawing.Size(671, 559);
            this.pnlSizes.TabIndex = 32;
            this.pnlSizes.Visible = false;
            // 
            // btnSmall
            // 
            this.btnSmall.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSmall.Location = new System.Drawing.Point(0, 0);
            this.btnSmall.Name = "btnSmall";
            this.btnSmall.Size = new System.Drawing.Size(671, 169);
            this.btnSmall.TabIndex = 20;
            this.btnSmall.UseVisualStyleBackColor = true;
            this.btnSmall.Visible = false;
            // 
            // btnLarge
            // 
            this.btnLarge.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLarge.Location = new System.Drawing.Point(0, 390);
            this.btnLarge.Name = "btnLarge";
            this.btnLarge.Size = new System.Drawing.Size(671, 169);
            this.btnLarge.TabIndex = 26;
            this.btnLarge.UseVisualStyleBackColor = true;
            this.btnLarge.Visible = false;
            // 
            // btnMedium
            // 
            this.btnMedium.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMedium.Location = new System.Drawing.Point(0, 198);
            this.btnMedium.Name = "btnMedium";
            this.btnMedium.Size = new System.Drawing.Size(671, 169);
            this.btnMedium.TabIndex = 24;
            this.btnMedium.UseVisualStyleBackColor = true;
            this.btnMedium.Visible = false;
            // 
            // pnlIceCreamFlavors
            // 
            this.pnlIceCreamFlavors.Controls.Add(this.btnFlavors1);
            this.pnlIceCreamFlavors.Controls.Add(this.btnFlavors5);
            this.pnlIceCreamFlavors.Controls.Add(this.btnFlavors8);
            this.pnlIceCreamFlavors.Controls.Add(this.btnFlavors9);
            this.pnlIceCreamFlavors.Controls.Add(this.btnFlavors3);
            this.pnlIceCreamFlavors.Controls.Add(this.btnFlavors7);
            this.pnlIceCreamFlavors.Controls.Add(this.btnFlavors2);
            this.pnlIceCreamFlavors.Controls.Add(this.btnFlavors6);
            this.pnlIceCreamFlavors.Controls.Add(this.btnFlavors4);
            this.pnlIceCreamFlavors.Location = new System.Drawing.Point(34, 25);
            this.pnlIceCreamFlavors.Name = "pnlIceCreamFlavors";
            this.pnlIceCreamFlavors.Size = new System.Drawing.Size(671, 559);
            this.pnlIceCreamFlavors.TabIndex = 31;
            this.pnlIceCreamFlavors.Visible = false;
            // 
            // btnFlavors1
            // 
            this.btnFlavors1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnFlavors1.Location = new System.Drawing.Point(0, 0);
            this.btnFlavors1.Name = "btnFlavors1";
            this.btnFlavors1.Size = new System.Drawing.Size(168, 169);
            this.btnFlavors1.TabIndex = 20;
            this.btnFlavors1.UseVisualStyleBackColor = true;
            this.btnFlavors1.Visible = false;
            // 
            // btnFlavors5
            // 
            this.btnFlavors5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnFlavors5.Location = new System.Drawing.Point(258, 198);
            this.btnFlavors5.Name = "btnFlavors5";
            this.btnFlavors5.Size = new System.Drawing.Size(168, 169);
            this.btnFlavors5.TabIndex = 28;
            this.btnFlavors5.UseVisualStyleBackColor = true;
            this.btnFlavors5.Visible = false;
            // 
            // btnFlavors8
            // 
            this.btnFlavors8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnFlavors8.Location = new System.Drawing.Point(258, 390);
            this.btnFlavors8.Name = "btnFlavors8";
            this.btnFlavors8.Size = new System.Drawing.Size(168, 169);
            this.btnFlavors8.TabIndex = 21;
            this.btnFlavors8.UseVisualStyleBackColor = true;
            this.btnFlavors8.Visible = false;
            // 
            // btnFlavors9
            // 
            this.btnFlavors9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnFlavors9.Location = new System.Drawing.Point(503, 390);
            this.btnFlavors9.Name = "btnFlavors9";
            this.btnFlavors9.Size = new System.Drawing.Size(168, 169);
            this.btnFlavors9.TabIndex = 27;
            this.btnFlavors9.UseVisualStyleBackColor = true;
            this.btnFlavors9.Visible = false;
            // 
            // btnFlavors3
            // 
            this.btnFlavors3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnFlavors3.Location = new System.Drawing.Point(503, 0);
            this.btnFlavors3.Name = "btnFlavors3";
            this.btnFlavors3.Size = new System.Drawing.Size(168, 169);
            this.btnFlavors3.TabIndex = 22;
            this.btnFlavors3.UseVisualStyleBackColor = true;
            this.btnFlavors3.Visible = false;
            // 
            // btnFlavors7
            // 
            this.btnFlavors7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnFlavors7.Location = new System.Drawing.Point(0, 390);
            this.btnFlavors7.Name = "btnFlavors7";
            this.btnFlavors7.Size = new System.Drawing.Size(168, 169);
            this.btnFlavors7.TabIndex = 26;
            this.btnFlavors7.UseVisualStyleBackColor = true;
            this.btnFlavors7.Visible = false;
            // 
            // btnFlavors2
            // 
            this.btnFlavors2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnFlavors2.Location = new System.Drawing.Point(258, 0);
            this.btnFlavors2.Name = "btnFlavors2";
            this.btnFlavors2.Size = new System.Drawing.Size(168, 169);
            this.btnFlavors2.TabIndex = 23;
            this.btnFlavors2.UseVisualStyleBackColor = true;
            this.btnFlavors2.Visible = false;
            // 
            // btnFlavors6
            // 
            this.btnFlavors6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnFlavors6.Location = new System.Drawing.Point(503, 198);
            this.btnFlavors6.Name = "btnFlavors6";
            this.btnFlavors6.Size = new System.Drawing.Size(168, 169);
            this.btnFlavors6.TabIndex = 25;
            this.btnFlavors6.UseVisualStyleBackColor = true;
            this.btnFlavors6.Visible = false;
            this.btnFlavors6.Click += new System.EventHandler(this.button12_Click);
            // 
            // btnFlavors4
            // 
            this.btnFlavors4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnFlavors4.Location = new System.Drawing.Point(0, 198);
            this.btnFlavors4.Name = "btnFlavors4";
            this.btnFlavors4.Size = new System.Drawing.Size(168, 169);
            this.btnFlavors4.TabIndex = 24;
            this.btnFlavors4.UseVisualStyleBackColor = true;
            this.btnFlavors4.Visible = false;
            // 
            // pnlMenuPage2
            // 
            this.pnlMenuPage2.Controls.Add(this.btn10);
            this.pnlMenuPage2.Controls.Add(this.btn14);
            this.pnlMenuPage2.Controls.Add(this.btn17);
            this.pnlMenuPage2.Controls.Add(this.btn18);
            this.pnlMenuPage2.Controls.Add(this.btn12);
            this.pnlMenuPage2.Controls.Add(this.btn16);
            this.pnlMenuPage2.Controls.Add(this.btn11);
            this.pnlMenuPage2.Controls.Add(this.btn15);
            this.pnlMenuPage2.Controls.Add(this.btn13);
            this.pnlMenuPage2.Location = new System.Drawing.Point(34, 25);
            this.pnlMenuPage2.Name = "pnlMenuPage2";
            this.pnlMenuPage2.Size = new System.Drawing.Size(671, 559);
            this.pnlMenuPage2.TabIndex = 30;
            this.pnlMenuPage2.Visible = false;
            // 
            // btn10
            // 
            this.btn10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn10.Location = new System.Drawing.Point(0, 0);
            this.btn10.Name = "btn10";
            this.btn10.Size = new System.Drawing.Size(168, 169);
            this.btn10.TabIndex = 20;
            this.btn10.UseVisualStyleBackColor = true;
            this.btn10.Visible = false;
            this.btn10.Click += new System.EventHandler(this.btn10_Click);
            // 
            // btn14
            // 
            this.btn14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn14.Location = new System.Drawing.Point(258, 198);
            this.btn14.Name = "btn14";
            this.btn14.Size = new System.Drawing.Size(168, 169);
            this.btn14.TabIndex = 28;
            this.btn14.UseVisualStyleBackColor = true;
            this.btn14.Visible = false;
            // 
            // btn17
            // 
            this.btn17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn17.Location = new System.Drawing.Point(258, 390);
            this.btn17.Name = "btn17";
            this.btn17.Size = new System.Drawing.Size(168, 169);
            this.btn17.TabIndex = 21;
            this.btn17.UseVisualStyleBackColor = true;
            this.btn17.Visible = false;
            // 
            // btn18
            // 
            this.btn18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn18.Location = new System.Drawing.Point(503, 390);
            this.btn18.Name = "btn18";
            this.btn18.Size = new System.Drawing.Size(168, 169);
            this.btn18.TabIndex = 27;
            this.btn18.UseVisualStyleBackColor = true;
            this.btn18.Visible = false;
            // 
            // btn12
            // 
            this.btn12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn12.Location = new System.Drawing.Point(503, 0);
            this.btn12.Name = "btn12";
            this.btn12.Size = new System.Drawing.Size(168, 169);
            this.btn12.TabIndex = 22;
            this.btn12.UseVisualStyleBackColor = true;
            this.btn12.Visible = false;
            // 
            // btn16
            // 
            this.btn16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn16.Location = new System.Drawing.Point(0, 390);
            this.btn16.Name = "btn16";
            this.btn16.Size = new System.Drawing.Size(168, 169);
            this.btn16.TabIndex = 26;
            this.btn16.UseVisualStyleBackColor = true;
            this.btn16.Visible = false;
            // 
            // btn11
            // 
            this.btn11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn11.Location = new System.Drawing.Point(258, 0);
            this.btn11.Name = "btn11";
            this.btn11.Size = new System.Drawing.Size(168, 169);
            this.btn11.TabIndex = 23;
            this.btn11.UseVisualStyleBackColor = true;
            this.btn11.Visible = false;
            // 
            // btn15
            // 
            this.btn15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn15.Location = new System.Drawing.Point(503, 198);
            this.btn15.Name = "btn15";
            this.btn15.Size = new System.Drawing.Size(168, 169);
            this.btn15.TabIndex = 25;
            this.btn15.UseVisualStyleBackColor = true;
            this.btn15.Visible = false;
            // 
            // btn13
            // 
            this.btn13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn13.Location = new System.Drawing.Point(0, 198);
            this.btn13.Name = "btn13";
            this.btn13.Size = new System.Drawing.Size(168, 169);
            this.btn13.TabIndex = 24;
            this.btn13.UseVisualStyleBackColor = true;
            this.btn13.Visible = false;
            // 
            // pnlAddOns
            // 
            this.pnlAddOns.Controls.Add(this.btnAdd1);
            this.pnlAddOns.Controls.Add(this.btnAdd5);
            this.pnlAddOns.Controls.Add(this.btnAdd8);
            this.pnlAddOns.Controls.Add(this.btnAdd9);
            this.pnlAddOns.Controls.Add(this.btnAdd3);
            this.pnlAddOns.Controls.Add(this.btnAdd7);
            this.pnlAddOns.Controls.Add(this.btnAdd2);
            this.pnlAddOns.Controls.Add(this.btnAdd6);
            this.pnlAddOns.Controls.Add(this.btnAdd4);
            this.pnlAddOns.Location = new System.Drawing.Point(34, 25);
            this.pnlAddOns.Name = "pnlAddOns";
            this.pnlAddOns.Size = new System.Drawing.Size(671, 559);
            this.pnlAddOns.TabIndex = 30;
            // 
            // btnAdd1
            // 
            this.btnAdd1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAdd1.Location = new System.Drawing.Point(0, 0);
            this.btnAdd1.Name = "btnAdd1";
            this.btnAdd1.Size = new System.Drawing.Size(168, 169);
            this.btnAdd1.TabIndex = 20;
            this.btnAdd1.UseVisualStyleBackColor = true;
            this.btnAdd1.Visible = false;
            // 
            // btnAdd5
            // 
            this.btnAdd5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAdd5.Location = new System.Drawing.Point(258, 198);
            this.btnAdd5.Name = "btnAdd5";
            this.btnAdd5.Size = new System.Drawing.Size(168, 169);
            this.btnAdd5.TabIndex = 28;
            this.btnAdd5.UseVisualStyleBackColor = true;
            this.btnAdd5.Visible = false;
            // 
            // btnAdd8
            // 
            this.btnAdd8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAdd8.Location = new System.Drawing.Point(258, 390);
            this.btnAdd8.Name = "btnAdd8";
            this.btnAdd8.Size = new System.Drawing.Size(168, 169);
            this.btnAdd8.TabIndex = 21;
            this.btnAdd8.UseVisualStyleBackColor = true;
            this.btnAdd8.Visible = false;
            // 
            // btnAdd9
            // 
            this.btnAdd9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAdd9.Location = new System.Drawing.Point(503, 390);
            this.btnAdd9.Name = "btnAdd9";
            this.btnAdd9.Size = new System.Drawing.Size(168, 169);
            this.btnAdd9.TabIndex = 27;
            this.btnAdd9.UseVisualStyleBackColor = true;
            this.btnAdd9.Visible = false;
            // 
            // btnAdd3
            // 
            this.btnAdd3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAdd3.Location = new System.Drawing.Point(503, 0);
            this.btnAdd3.Name = "btnAdd3";
            this.btnAdd3.Size = new System.Drawing.Size(168, 169);
            this.btnAdd3.TabIndex = 22;
            this.btnAdd3.UseVisualStyleBackColor = true;
            this.btnAdd3.Visible = false;
            // 
            // btnAdd7
            // 
            this.btnAdd7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAdd7.Location = new System.Drawing.Point(0, 390);
            this.btnAdd7.Name = "btnAdd7";
            this.btnAdd7.Size = new System.Drawing.Size(168, 169);
            this.btnAdd7.TabIndex = 26;
            this.btnAdd7.UseVisualStyleBackColor = true;
            this.btnAdd7.Visible = false;
            // 
            // btnAdd2
            // 
            this.btnAdd2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAdd2.Location = new System.Drawing.Point(258, 0);
            this.btnAdd2.Name = "btnAdd2";
            this.btnAdd2.Size = new System.Drawing.Size(168, 169);
            this.btnAdd2.TabIndex = 23;
            this.btnAdd2.UseVisualStyleBackColor = true;
            this.btnAdd2.Visible = false;
            // 
            // btnAdd6
            // 
            this.btnAdd6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAdd6.Location = new System.Drawing.Point(503, 198);
            this.btnAdd6.Name = "btnAdd6";
            this.btnAdd6.Size = new System.Drawing.Size(168, 169);
            this.btnAdd6.TabIndex = 25;
            this.btnAdd6.UseVisualStyleBackColor = true;
            this.btnAdd6.Visible = false;
            // 
            // btnAdd4
            // 
            this.btnAdd4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAdd4.Location = new System.Drawing.Point(0, 198);
            this.btnAdd4.Name = "btnAdd4";
            this.btnAdd4.Size = new System.Drawing.Size(168, 169);
            this.btnAdd4.TabIndex = 24;
            this.btnAdd4.UseVisualStyleBackColor = true;
            this.btnAdd4.Visible = false;
            // 
            // lblCurrentDate
            // 
            this.lblCurrentDate.BackColor = System.Drawing.Color.LightCoral;
            this.lblCurrentDate.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentDate.Location = new System.Drawing.Point(1305, 13);
            this.lblCurrentDate.Name = "lblCurrentDate";
            this.lblCurrentDate.Size = new System.Drawing.Size(259, 52);
            this.lblCurrentDate.TabIndex = 8;
            this.lblCurrentDate.Text = "Current Date";
            this.lblCurrentDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnDeleteItem
            // 
            this.btnDeleteItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnDeleteItem.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteItem.Location = new System.Drawing.Point(30, 25);
            this.btnDeleteItem.Name = "btnDeleteItem";
            this.btnDeleteItem.Size = new System.Drawing.Size(146, 86);
            this.btnDeleteItem.TabIndex = 9;
            this.btnDeleteItem.Text = "Delete Item";
            this.btnDeleteItem.UseVisualStyleBackColor = false;
            this.btnDeleteItem.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnPay
            // 
            this.btnPay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnPay.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPay.Location = new System.Drawing.Point(30, 600);
            this.btnPay.Name = "btnPay";
            this.btnPay.Size = new System.Drawing.Size(146, 86);
            this.btnPay.TabIndex = 10;
            this.btnPay.Text = "PAY";
            this.btnPay.UseVisualStyleBackColor = false;
            this.btnPay.Click += new System.EventHandler(this.btnPay_Click);
            // 
            // lblEmployeeName
            // 
            this.lblEmployeeName.BackColor = System.Drawing.Color.Silver;
            this.lblEmployeeName.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployeeName.Location = new System.Drawing.Point(941, 13);
            this.lblEmployeeName.Name = "lblEmployeeName";
            this.lblEmployeeName.Size = new System.Drawing.Size(358, 52);
            this.lblEmployeeName.TabIndex = 11;
            this.lblEmployeeName.Text = "Employee\'s Name";
            this.lblEmployeeName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblEmployeeName.Click += new System.EventHandler(this.lblEmployeeName_Click);
            // 
            // lblLabelReceipt
            // 
            this.lblLabelReceipt.BackColor = System.Drawing.Color.Transparent;
            this.lblLabelReceipt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLabelReceipt.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLabelReceipt.ForeColor = System.Drawing.Color.Black;
            this.lblLabelReceipt.Location = new System.Drawing.Point(3, 0);
            this.lblLabelReceipt.Name = "lblLabelReceipt";
            this.lblLabelReceipt.Size = new System.Drawing.Size(440, 43);
            this.lblLabelReceipt.TabIndex = 12;
            this.lblLabelReceipt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1358, 68);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(54, 47);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 13;
            this.pictureBox2.TabStop = false;
            // 
            // btnQuantity
            // 
            this.btnQuantity.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuantity.Location = new System.Drawing.Point(30, 128);
            this.btnQuantity.Name = "btnQuantity";
            this.btnQuantity.Size = new System.Drawing.Size(146, 86);
            this.btnQuantity.TabIndex = 19;
            this.btnQuantity.Text = "Quantity";
            this.btnQuantity.UseVisualStyleBackColor = true;
            // 
            // btnFAQ
            // 
            this.btnFAQ.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFAQ.Location = new System.Drawing.Point(552, 16);
            this.btnFAQ.Name = "btnFAQ";
            this.btnFAQ.Size = new System.Drawing.Size(138, 49);
            this.btnFAQ.TabIndex = 21;
            this.btnFAQ.Text = "FAQ";
            this.btnFAQ.UseVisualStyleBackColor = true;
            this.btnFAQ.Click += new System.EventHandler(this.btnFAQ_Click);
            // 
            // pnlOrderFunctions
            // 
            this.pnlOrderFunctions.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pnlOrderFunctions.Controls.Add(this.btnSuspendOrder);
            this.pnlOrderFunctions.Controls.Add(this.btnCancelOrder);
            this.pnlOrderFunctions.Controls.Add(this.btnOrderHistory);
            this.pnlOrderFunctions.Controls.Add(this.btnDeleteItem);
            this.pnlOrderFunctions.Controls.Add(this.btnPay);
            this.pnlOrderFunctions.Controls.Add(this.btnQuantity);
            this.pnlOrderFunctions.Location = new System.Drawing.Point(522, 240);
            this.pnlOrderFunctions.Name = "pnlOrderFunctions";
            this.pnlOrderFunctions.Size = new System.Drawing.Size(209, 716);
            this.pnlOrderFunctions.TabIndex = 22;
            // 
            // btnSuspendOrder
            // 
            this.btnSuspendOrder.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuspendOrder.Location = new System.Drawing.Point(30, 437);
            this.btnSuspendOrder.Name = "btnSuspendOrder";
            this.btnSuspendOrder.Size = new System.Drawing.Size(146, 86);
            this.btnSuspendOrder.TabIndex = 24;
            this.btnSuspendOrder.Text = "Suspend";
            this.btnSuspendOrder.UseVisualStyleBackColor = true;
            // 
            // btnCancelOrder
            // 
            this.btnCancelOrder.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelOrder.Location = new System.Drawing.Point(30, 334);
            this.btnCancelOrder.Name = "btnCancelOrder";
            this.btnCancelOrder.Size = new System.Drawing.Size(146, 86);
            this.btnCancelOrder.TabIndex = 23;
            this.btnCancelOrder.Text = "Cancel Order";
            this.btnCancelOrder.UseVisualStyleBackColor = true;
            this.btnCancelOrder.Click += new System.EventHandler(this.btnCancelOrder_Click);
            // 
            // btnOrderHistory
            // 
            this.btnOrderHistory.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrderHistory.Location = new System.Drawing.Point(30, 231);
            this.btnOrderHistory.Name = "btnOrderHistory";
            this.btnOrderHistory.Size = new System.Drawing.Size(146, 86);
            this.btnOrderHistory.TabIndex = 22;
            this.btnOrderHistory.Text = "Order History";
            this.btnOrderHistory.UseVisualStyleBackColor = true;
            // 
            // btnGoToManagerMode
            // 
            this.btnGoToManagerMode.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGoToManagerMode.Location = new System.Drawing.Point(1030, 68);
            this.btnGoToManagerMode.Name = "btnGoToManagerMode";
            this.btnGoToManagerMode.Size = new System.Drawing.Size(206, 47);
            this.btnGoToManagerMode.TabIndex = 23;
            this.btnGoToManagerMode.Text = "Back Office";
            this.btnGoToManagerMode.UseVisualStyleBackColor = true;
            this.btnGoToManagerMode.Visible = false;
            this.btnGoToManagerMode.Click += new System.EventHandler(this.btnGoToManagerMode_Click);
            // 
            // btnPaidOut
            // 
            this.btnPaidOut.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPaidOut.Location = new System.Drawing.Point(329, 3);
            this.btnPaidOut.Name = "btnPaidOut";
            this.btnPaidOut.Size = new System.Drawing.Size(146, 86);
            this.btnPaidOut.TabIndex = 28;
            this.btnPaidOut.Text = "Paid Out";
            this.btnPaidOut.UseVisualStyleBackColor = true;
            // 
            // btnHouseCharge
            // 
            this.btnHouseCharge.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHouseCharge.Location = new System.Drawing.Point(492, 3);
            this.btnHouseCharge.Name = "btnHouseCharge";
            this.btnHouseCharge.Size = new System.Drawing.Size(146, 86);
            this.btnHouseCharge.TabIndex = 27;
            this.btnHouseCharge.Text = "House Charge";
            this.btnHouseCharge.UseVisualStyleBackColor = true;
            // 
            // btnRefund
            // 
            this.btnRefund.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefund.Location = new System.Drawing.Point(3, 3);
            this.btnRefund.Name = "btnRefund";
            this.btnRefund.Size = new System.Drawing.Size(146, 86);
            this.btnRefund.TabIndex = 26;
            this.btnRefund.Text = "Refund";
            this.btnRefund.UseVisualStyleBackColor = true;
            // 
            // btnLabor
            // 
            this.btnLabor.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLabor.Location = new System.Drawing.Point(166, 3);
            this.btnLabor.Name = "btnLabor";
            this.btnLabor.Size = new System.Drawing.Size(146, 86);
            this.btnLabor.TabIndex = 25;
            this.btnLabor.Text = "Labor Report";
            this.btnLabor.UseVisualStyleBackColor = true;
            // 
            // btnPage1
            // 
            this.btnPage1.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPage1.Location = new System.Drawing.Point(0, 0);
            this.btnPage1.Name = "btnPage1";
            this.btnPage1.Size = new System.Drawing.Size(100, 40);
            this.btnPage1.TabIndex = 25;
            this.btnPage1.Text = "Page1";
            this.btnPage1.UseVisualStyleBackColor = true;
            this.btnPage1.Click += new System.EventHandler(this.btnPage1_Click);
            // 
            // btnPage2
            // 
            this.btnPage2.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPage2.Location = new System.Drawing.Point(142, 0);
            this.btnPage2.Name = "btnPage2";
            this.btnPage2.Size = new System.Drawing.Size(100, 40);
            this.btnPage2.TabIndex = 26;
            this.btnPage2.Text = "Page2";
            this.btnPage2.UseVisualStyleBackColor = true;
            this.btnPage2.Click += new System.EventHandler(this.btnPage2_Click);
            // 
            // btnPage3
            // 
            this.btnPage3.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPage3.Location = new System.Drawing.Point(284, 0);
            this.btnPage3.Name = "btnPage3";
            this.btnPage3.Size = new System.Drawing.Size(100, 40);
            this.btnPage3.TabIndex = 27;
            this.btnPage3.Text = "Page3";
            this.btnPage3.UseVisualStyleBackColor = true;
            this.btnPage3.Visible = false;
            // 
            // btnPage4
            // 
            this.btnPage4.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPage4.Location = new System.Drawing.Point(426, 0);
            this.btnPage4.Name = "btnPage4";
            this.btnPage4.Size = new System.Drawing.Size(100, 40);
            this.btnPage4.TabIndex = 28;
            this.btnPage4.Text = "Page4";
            this.btnPage4.UseVisualStyleBackColor = true;
            this.btnPage4.Visible = false;
            // 
            // btnPage5
            // 
            this.btnPage5.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPage5.Location = new System.Drawing.Point(568, 0);
            this.btnPage5.Name = "btnPage5";
            this.btnPage5.Size = new System.Drawing.Size(100, 40);
            this.btnPage5.TabIndex = 29;
            this.btnPage5.Text = "Page5";
            this.btnPage5.UseVisualStyleBackColor = true;
            this.btnPage5.Visible = false;
            // 
            // pnlKeypad
            // 
            this.pnlKeypad.BackColor = System.Drawing.Color.Silver;
            this.pnlKeypad.Controls.Add(this.btn0Keypad);
            this.pnlKeypad.Controls.Add(this.txtbKeypad);
            this.pnlKeypad.Controls.Add(this.btn3Keypad);
            this.pnlKeypad.Controls.Add(this.btn2Keypad);
            this.pnlKeypad.Controls.Add(this.btn1Keypad);
            this.pnlKeypad.Controls.Add(this.btn6Keypad);
            this.pnlKeypad.Controls.Add(this.btn5Kepad);
            this.pnlKeypad.Controls.Add(this.btn4Keypad);
            this.pnlKeypad.Controls.Add(this.btn9Keypad);
            this.pnlKeypad.Controls.Add(this.btn8Keypad);
            this.pnlKeypad.Controls.Add(this.btn7Keypad);
            this.pnlKeypad.Controls.Add(this.button4);
            this.pnlKeypad.Controls.Add(this.button3);
            this.pnlKeypad.Location = new System.Drawing.Point(570, 296);
            this.pnlKeypad.Name = "pnlKeypad";
            this.pnlKeypad.Size = new System.Drawing.Size(310, 386);
            this.pnlKeypad.TabIndex = 31;
            this.pnlKeypad.Visible = false;
            // 
            // btn0Keypad
            // 
            this.btn0Keypad.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn0Keypad.Location = new System.Drawing.Point(37, 304);
            this.btn0Keypad.Name = "btn0Keypad";
            this.btn0Keypad.Size = new System.Drawing.Size(75, 61);
            this.btn0Keypad.TabIndex = 32;
            this.btn0Keypad.Text = "0";
            this.btn0Keypad.UseVisualStyleBackColor = true;
            // 
            // txtbKeypad
            // 
            this.txtbKeypad.Location = new System.Drawing.Point(37, 18);
            this.txtbKeypad.Multiline = true;
            this.txtbKeypad.Name = "txtbKeypad";
            this.txtbKeypad.ReadOnly = true;
            this.txtbKeypad.Size = new System.Drawing.Size(156, 70);
            this.txtbKeypad.TabIndex = 31;
            // 
            // btn3Keypad
            // 
            this.btn3Keypad.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn3Keypad.Location = new System.Drawing.Point(201, 230);
            this.btn3Keypad.Name = "btn3Keypad";
            this.btn3Keypad.Size = new System.Drawing.Size(75, 61);
            this.btn3Keypad.TabIndex = 30;
            this.btn3Keypad.Text = "3";
            this.btn3Keypad.UseVisualStyleBackColor = true;
            // 
            // btn2Keypad
            // 
            this.btn2Keypad.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn2Keypad.Location = new System.Drawing.Point(120, 230);
            this.btn2Keypad.Name = "btn2Keypad";
            this.btn2Keypad.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn2Keypad.Size = new System.Drawing.Size(75, 61);
            this.btn2Keypad.TabIndex = 29;
            this.btn2Keypad.Text = "2";
            this.btn2Keypad.UseVisualStyleBackColor = true;
            // 
            // btn1Keypad
            // 
            this.btn1Keypad.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1Keypad.Location = new System.Drawing.Point(37, 230);
            this.btn1Keypad.Name = "btn1Keypad";
            this.btn1Keypad.Size = new System.Drawing.Size(75, 61);
            this.btn1Keypad.TabIndex = 28;
            this.btn1Keypad.Text = "1";
            this.btn1Keypad.UseVisualStyleBackColor = true;
            // 
            // btn6Keypad
            // 
            this.btn6Keypad.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn6Keypad.Location = new System.Drawing.Point(201, 162);
            this.btn6Keypad.Name = "btn6Keypad";
            this.btn6Keypad.Size = new System.Drawing.Size(75, 61);
            this.btn6Keypad.TabIndex = 27;
            this.btn6Keypad.Text = "6";
            this.btn6Keypad.UseVisualStyleBackColor = true;
            // 
            // btn5Kepad
            // 
            this.btn5Kepad.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn5Kepad.Location = new System.Drawing.Point(120, 162);
            this.btn5Kepad.Name = "btn5Kepad";
            this.btn5Kepad.Size = new System.Drawing.Size(75, 61);
            this.btn5Kepad.TabIndex = 26;
            this.btn5Kepad.Text = "5";
            this.btn5Kepad.UseVisualStyleBackColor = true;
            // 
            // btn4Keypad
            // 
            this.btn4Keypad.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn4Keypad.Location = new System.Drawing.Point(37, 162);
            this.btn4Keypad.Name = "btn4Keypad";
            this.btn4Keypad.Size = new System.Drawing.Size(75, 61);
            this.btn4Keypad.TabIndex = 25;
            this.btn4Keypad.Text = "4";
            this.btn4Keypad.UseVisualStyleBackColor = true;
            // 
            // btn9Keypad
            // 
            this.btn9Keypad.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn9Keypad.Location = new System.Drawing.Point(201, 94);
            this.btn9Keypad.Name = "btn9Keypad";
            this.btn9Keypad.Size = new System.Drawing.Size(75, 61);
            this.btn9Keypad.TabIndex = 24;
            this.btn9Keypad.Text = "9";
            this.btn9Keypad.UseVisualStyleBackColor = true;
            // 
            // btn8Keypad
            // 
            this.btn8Keypad.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn8Keypad.Location = new System.Drawing.Point(118, 94);
            this.btn8Keypad.Name = "btn8Keypad";
            this.btn8Keypad.Size = new System.Drawing.Size(75, 61);
            this.btn8Keypad.TabIndex = 23;
            this.btn8Keypad.Text = "8";
            this.btn8Keypad.UseVisualStyleBackColor = true;
            // 
            // btn7Keypad
            // 
            this.btn7Keypad.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn7Keypad.Location = new System.Drawing.Point(37, 94);
            this.btn7Keypad.Name = "btn7Keypad";
            this.btn7Keypad.Size = new System.Drawing.Size(75, 61);
            this.btn7Keypad.TabIndex = 22;
            this.btn7Keypad.Text = "7";
            this.btn7Keypad.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(201, 18);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 70);
            this.button4.TabIndex = 21;
            this.button4.Text = "Clear";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(120, 304);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(156, 61);
            this.button3.TabIndex = 20;
            this.button3.Text = "Enter";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // pnlButtonSection
            // 
            this.pnlButtonSection.Controls.Add(this.pnlMenuNavigation);
            this.pnlButtonSection.Controls.Add(this.pnlManagerFunctions);
            this.pnlButtonSection.Controls.Add(this.pnlOrderItems);
            this.pnlButtonSection.Location = new System.Drawing.Point(746, 186);
            this.pnlButtonSection.Name = "pnlButtonSection";
            this.pnlButtonSection.Size = new System.Drawing.Size(755, 795);
            this.pnlButtonSection.TabIndex = 32;
            // 
            // pnlCurrentOrder
            // 
            this.pnlCurrentOrder.Controls.Add(this.lblLabelReceipt);
            this.pnlCurrentOrder.Controls.Add(this.lstbOrders);
            this.pnlCurrentOrder.Controls.Add(this.rtxtbOrderFinal);
            this.pnlCurrentOrder.Location = new System.Drawing.Point(35, 186);
            this.pnlCurrentOrder.Name = "pnlCurrentOrder";
            this.pnlCurrentOrder.Size = new System.Drawing.Size(447, 762);
            this.pnlCurrentOrder.TabIndex = 33;
            // 
            // pnlOrdering
            // 
            this.pnlOrdering.Controls.Add(this.pictureBox1);
            this.pnlOrdering.Controls.Add(this.button1);
            this.pnlOrdering.Controls.Add(this.pnlCurrentOrder);
            this.pnlOrdering.Controls.Add(this.lblResolution);
            this.pnlOrdering.Controls.Add(this.pnlButtonSection);
            this.pnlOrdering.Controls.Add(this.button2);
            this.pnlOrdering.Controls.Add(this.btnGoToManagerMode);
            this.pnlOrdering.Controls.Add(this.lblCurrentDate);
            this.pnlOrdering.Controls.Add(this.pnlOrderFunctions);
            this.pnlOrdering.Controls.Add(this.lblEmployeeName);
            this.pnlOrdering.Controls.Add(this.btnFAQ);
            this.pnlOrdering.Controls.Add(this.pictureBox2);
            this.pnlOrdering.Location = new System.Drawing.Point(0, -1);
            this.pnlOrdering.Name = "pnlOrdering";
            this.pnlOrdering.Size = new System.Drawing.Size(1562, 1002);
            this.pnlOrdering.TabIndex = 34;
            this.pnlOrdering.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlOrdering_Paint);
            // 
            // pnlManagerFunctions
            // 
            this.pnlManagerFunctions.Controls.Add(this.btnRefund);
            this.pnlManagerFunctions.Controls.Add(this.btnPaidOut);
            this.pnlManagerFunctions.Controls.Add(this.btnLabor);
            this.pnlManagerFunctions.Controls.Add(this.btnHouseCharge);
            this.pnlManagerFunctions.Location = new System.Drawing.Point(63, 675);
            this.pnlManagerFunctions.Name = "pnlManagerFunctions";
            this.pnlManagerFunctions.Size = new System.Drawing.Size(641, 90);
            this.pnlManagerFunctions.TabIndex = 30;
            // 
            // pnlMenuNavigation
            // 
            this.pnlMenuNavigation.Controls.Add(this.btnPage1);
            this.pnlMenuNavigation.Controls.Add(this.btnPage4);
            this.pnlMenuNavigation.Controls.Add(this.btnPage3);
            this.pnlMenuNavigation.Controls.Add(this.btnPage2);
            this.pnlMenuNavigation.Controls.Add(this.btnPage5);
            this.pnlMenuNavigation.Location = new System.Drawing.Point(115, 3);
            this.pnlMenuNavigation.Name = "pnlMenuNavigation";
            this.pnlMenuNavigation.Size = new System.Drawing.Size(526, 45);
            this.pnlMenuNavigation.TabIndex = 31;
            this.pnlMenuNavigation.Visible = false;
            // 
            // frmMain
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1563, 1002);
            this.Controls.Add(this.pnlOrdering);
            this.Controls.Add(this.pnlKeypad);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximumSize = new System.Drawing.Size(1563, 1002);
            this.MinimumSize = new System.Drawing.Size(1563, 1002);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlOrderItems.ResumeLayout(false);
            this.pnlMenuPage1.ResumeLayout(false);
            this.pnlSizes.ResumeLayout(false);
            this.pnlIceCreamFlavors.ResumeLayout(false);
            this.pnlMenuPage2.ResumeLayout(false);
            this.pnlAddOns.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.pnlOrderFunctions.ResumeLayout(false);
            this.pnlKeypad.ResumeLayout(false);
            this.pnlKeypad.PerformLayout();
            this.pnlButtonSection.ResumeLayout(false);
            this.pnlCurrentOrder.ResumeLayout(false);
            this.pnlOrdering.ResumeLayout(false);
            this.pnlManagerFunctions.ResumeLayout(false);
            this.pnlMenuNavigation.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.Button button1;
        public System.Windows.Forms.Label lblResolution;
        public System.Windows.Forms.Button button2;
        public System.Windows.Forms.ListBox lstbOrders;
        public System.Windows.Forms.RichTextBox rtxtbOrderFinal;
        public System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.Timer OrderingTimer;
        public System.Windows.Forms.Panel pnlOrderItems;
        public System.ComponentModel.BackgroundWorker backgroundWorker1;
        public System.Windows.Forms.Label lblCurrentDate;
        public System.Windows.Forms.Button btnDeleteItem;
        public System.Windows.Forms.Button btn1;
        public System.Windows.Forms.Button btn5;
        public System.Windows.Forms.Button btn9;
        public System.Windows.Forms.Button btn7;
        public System.Windows.Forms.Button btn6;
        public System.Windows.Forms.Button btn4;
        public System.Windows.Forms.Button btn2;
        public System.Windows.Forms.Button btn3;
        public System.Windows.Forms.Button btn8;
        public System.Windows.Forms.Button btnPay;
        public System.Windows.Forms.Label lblEmployeeName;
        public System.Windows.Forms.Label lblLabelReceipt;
        public System.Windows.Forms.PictureBox pictureBox2;
        public System.Windows.Forms.Button btnQuantity;
        public System.Windows.Forms.Button btnFAQ;
        public System.Windows.Forms.Panel pnlOrderFunctions;
        public System.Windows.Forms.Panel pnlMenuPage2;
        public System.Windows.Forms.Button btn10;
        public System.Windows.Forms.Button btn14;
        public System.Windows.Forms.Button btn17;
        public System.Windows.Forms.Button btn18;
        public System.Windows.Forms.Button btn12;
        public System.Windows.Forms.Button btn16;
        public System.Windows.Forms.Button btn11;
        public System.Windows.Forms.Button btn15;
        public System.Windows.Forms.Button btn13;
        public System.Windows.Forms.Panel pnlMenuPage1;
        public System.Windows.Forms.Button btnSuspendOrder;
        public System.Windows.Forms.Button btnCancelOrder;
        public System.Windows.Forms.Button btnOrderHistory;
        public System.Windows.Forms.Button btnGoToManagerMode;
        public System.Windows.Forms.Button btnPaidOut;
        public System.Windows.Forms.Button btnHouseCharge;
        public System.Windows.Forms.Button btnRefund;
        public System.Windows.Forms.Button btnLabor;
        public System.Windows.Forms.Button btnPage1;
        public System.Windows.Forms.Button btnPage2;
        public System.Windows.Forms.Button btnPage3;
        public System.Windows.Forms.Button btnPage4;
        public System.Windows.Forms.Button btnPage5;
        public System.Windows.Forms.Panel pnlKeypad;
        public System.Windows.Forms.Button btn0Keypad;
        public System.Windows.Forms.TextBox txtbKeypad;
        public System.Windows.Forms.Button btn3Keypad;
        public System.Windows.Forms.Button btn2Keypad;
        public System.Windows.Forms.Button btn1Keypad;
        public System.Windows.Forms.Button btn6Keypad;
        public System.Windows.Forms.Button btn5Kepad;
        public System.Windows.Forms.Button btn4Keypad;
        public System.Windows.Forms.Button btn9Keypad;
        public System.Windows.Forms.Button btn8Keypad;
        public System.Windows.Forms.Button btn7Keypad;
        public System.Windows.Forms.Button button4;
        public System.Windows.Forms.Button button3;
        public System.Windows.Forms.Panel pnlButtonSection;
        public System.Windows.Forms.Panel pnlCurrentOrder;
        public System.Windows.Forms.Panel pnlOrdering;
        public System.ComponentModel.IContainer components;
        public System.Windows.Forms.Panel pnlIceCreamFlavors;
        public System.Windows.Forms.Button btnFlavors1;
        public System.Windows.Forms.Button btnFlavors5;
        public System.Windows.Forms.Button btnFlavors8;
        public System.Windows.Forms.Button btnFlavors9;
        public System.Windows.Forms.Button btnFlavors3;
        public System.Windows.Forms.Button btnFlavors7;
        public System.Windows.Forms.Button btnFlavors2;
        public System.Windows.Forms.Button btnFlavors6;
        public System.Windows.Forms.Button btnFlavors4;
        public System.Windows.Forms.Panel pnlAddOns;
        public System.Windows.Forms.Button btnAdd1;
        public System.Windows.Forms.Button btnAdd5;
        public System.Windows.Forms.Button btnAdd8;
        public System.Windows.Forms.Button btnAdd9;
        public System.Windows.Forms.Button btnAdd3;
        public System.Windows.Forms.Button btnAdd7;
        public System.Windows.Forms.Button btnAdd2;
        public System.Windows.Forms.Button btnAdd6;
        public System.Windows.Forms.Button btnAdd4;
        public System.Windows.Forms.Panel pnlSizes;
        public System.Windows.Forms.Button btnSmall;
        public System.Windows.Forms.Button btnLarge;
        public System.Windows.Forms.Button btnMedium;
        public System.Windows.Forms.Panel pnlMenuNavigation;
        public System.Windows.Forms.Panel pnlManagerFunctions;
    }
}

