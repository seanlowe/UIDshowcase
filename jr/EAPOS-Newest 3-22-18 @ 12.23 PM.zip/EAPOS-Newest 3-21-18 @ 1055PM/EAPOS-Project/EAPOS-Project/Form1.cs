﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using Ordering;
using SignIn;
using System.Data.OleDb;

namespace EAPOS_Project
{
    public partial class frmManagerMode : Form
    {

        public frmManagerMode()
        {
            InitializeComponent();
        }
        private void frmManagerMode_Load(object sender, EventArgs e)
        {
            txtbID.Text = "";
            txtbFirstName.Text = "";
            txtbLastName.Text = "";
            txtbStatus.Text = "";
            txtbWage.Text = "";
            //lstbStatus.SelectedIndex = 0;
        }
        private void frmManagerMode_Load_1(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'coffeeShopEmployeesDataSet.Employees' table. You can move, or remove it, as needed.
            this.employeesTableAdapter.Fill(this.coffeeShopEmployeesDataSet.Employees);
        }




        //||------------------------------------- Manager Home Page ------------------------------------||\\

        private void btnSignOutManagerMode_Click(object sender, EventArgs e)
        {
            // Manager Sign Out Button - Go To LogIn Screen
            FormProvider.signInForm.Show();
            this.Visible = false;
        }
        private void btnOrderMode_Click(object sender, EventArgs e)
        {
            // Go To Order Mode Button 
            FormProvider.orderForm.Show();
            this.Visible = false;
        }
        
        private void btnEmployees_Click(object sender, EventArgs e)
        {
            // Employee Button
            pnlEmployees.Visible = true;
            pnlManagerMode.Visible = false;
            txtbID.Text = "";
            txtbFirstName.Text = "";
            txtbLastName.Text = "";
            txtbStatus.Text = "";
            txtbWage.Text = "";
            colorblindCheckBox.Checked = false;
            leftHandedCheckBox.Checked = false;
        }
        
        private void btnProductManagement_Click(object sender, EventArgs e)
        {
            // Product Management Button
            pnlProductMgmt.Visible = true;
            pnlManagerMode.Visible = false;
        }

        private void btnSalesReport_Click(object sender, EventArgs e)
        {
            // Sales Report Button
            pnlSalesReport.Visible = true;
            pnlManagerMode.Visible = false;
        }

        private void btnCreateTrainingTests_Click(object sender, EventArgs e)
        {
            // Create Tests Button
            pnlCreateTest.Visible = true;
            pnlManagerMode.Visible = false;
        }



        //||--------------------------------------- Employees Page -------------------------------------||//

        public bool IsNumeric(string input)
        {
            int test;
            return int.TryParse(input, out test);
        }

        private void btnUpdateEmployee_Click(object sender, EventArgs e)
        {
            if (!IsNumeric(txtbID.Text))
                MessageBox.Show("ID Must Be A Number", "Error!");

            // if (lstbStatus.SelectedIndex == 0)
            //     MessageBox.Show("Must Select Status", "Error!");

            if (Regex.IsMatch(txtbFirstName.Text, @"^[a-zA-Z]+$") == false || Regex.IsMatch(txtbLastName.Text, @"^[a-zA-Z]+$") == false)
                MessageBox.Show("Name cannot contain numbers", "Error");
            this.Validate();
            this.employeesBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.coffeeShopEmployeesDataSet);
        }

        private void employeesBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeesBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.coffeeShopEmployeesDataSet);

        }

        private void btnQuitEmployees_Click(object sender, EventArgs e)
        {
            pnlEmployees.Visible = false;
            pnlManagerMode.Visible = true;
        }



        //||----------------------------------- Product Management Page -----------------------------------||\\

        private void btnDelete_Click(object sender, EventArgs e)
        {
            pnlConfirmDeletion.Visible = false;
        }

        private void btnDeleteItem_Click(object sender, EventArgs e)
        {
            pnlConfirmDeletion.Visible = true;
        }
        private void btnQuitProductMgmt_Click(object sender, EventArgs e)
        {
            pnlProductMgmt.Visible = false;
            pnlManagerMode.Visible = true;
        }
        private void btnAddItem_Click(object sender, EventArgs e)
        {
            FormProvider.orderForm.btn10.Text = this.txtbItemName.Text;
            FormProvider.orderForm.btn10.Visible = true;
            FormProvider.orderForm.btnPage1.Visible = true;
            FormProvider.orderForm.btnPage2.Visible = true;           
        }


        

        //||------------------------------------ Sales Report Page ---------------------------------------||\\
        private void btnQuitSalesReport_Click(object sender, EventArgs e)
        {
            pnlSalesReport.Visible = false;
            pnlManagerMode.Visible = true;
        }
        




        //||------------------------------------- Create Test Page --------------------------------------||\\

        private void btnCreateNewTest_Click(object sender, EventArgs e)
        {

        }

        private void btnQuitCreateTest_Click(object sender, EventArgs e)
        {
            pnlCreateTest.Visible = false;
            pnlManagerMode.Visible = true;
        }













        //!!!--------------------------------------!!! DO NOT DELETE !!!-------------------------------------------!!!\\

        private void colorblindCheckBox_CheckedChanged(object sender, EventArgs e)
        {
        }
        private void btnAddEmployee_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.PerformClick();
        }
        private void btnDeleteEmployee_Click(object sender, EventArgs e)
        {
            bindingNavigatorDeleteItem.PerformClick();
        }
        private void leftHandedLabel_Click(object sender, EventArgs e)
        {
        }
        private void colorblindLabel_Click(object sender, EventArgs e)
        {
        }
        private void leftHandedCheckBox_CheckedChanged(object sender, EventArgs e)
        {
        }
        private void pnlManagerMode_Paint(object sender, PaintEventArgs e)
        {
        }
        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
        }
        private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
        {
        }
        private void pnlEmployees_Paint(object sender, PaintEventArgs e)
        {
        }
        private void button1_Click(object sender, EventArgs e)
        {
            for(int i = 0; i < FormProvider.signInForm.POSEmployees.Count; i++)
            {
                Debug.Print(FormProvider.signInForm.POSEmployees[i].fName);
            }




            /*
            using (OleDbConnection conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\riads\Desktop\EAPOS-Newest 3-7-18 @ 6PM\EAPOS-Project\CoffeeShopEmployees.accdb"))
            using (OleDbCommand cmd = new OleDbCommand("select* from Employees", conn))
            {
                conn.Open();
                OleDbDataReader reader = null;
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    firstName.Add(reader["Fname"].ToString());
                    lastName.Add(reader["Lname"].ToString());
                }
                conn.Close();
            }
            for (int i = 0; i < firstName.Count; i++)
            {
                Debug.Print(firstName[i].ToString());
            }
            */
        }
    }
}
