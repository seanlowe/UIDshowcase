﻿namespace Ordering
{
    partial class frmMain
    {

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        public void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.button1 = new System.Windows.Forms.Button();
            this.lblResolution = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.lstbOrders = new System.Windows.Forms.ListBox();
            this.rtxtbOrderFinal = new System.Windows.Forms.RichTextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.OrderingTimer = new System.Windows.Forms.Timer(this.components);
            this.pnlOrderItems = new System.Windows.Forms.Panel();
            this.pnlMenuPage2 = new System.Windows.Forms.Panel();
            this.btn10 = new System.Windows.Forms.Button();
            this.btn14 = new System.Windows.Forms.Button();
            this.btn17 = new System.Windows.Forms.Button();
            this.btn18 = new System.Windows.Forms.Button();
            this.btn12 = new System.Windows.Forms.Button();
            this.btn16 = new System.Windows.Forms.Button();
            this.btn11 = new System.Windows.Forms.Button();
            this.btn15 = new System.Windows.Forms.Button();
            this.btn13 = new System.Windows.Forms.Button();
            this.pnlMenuPage1 = new System.Windows.Forms.Panel();
            this.btnBurger = new System.Windows.Forms.Button();
            this.btnChicken = new System.Windows.Forms.Button();
            this.btnBagel = new System.Windows.Forms.Button();
            this.btnSoda = new System.Windows.Forms.Button();
            this.btnHotDog = new System.Windows.Forms.Button();
            this.btnIceCream = new System.Windows.Forms.Button();
            this.btnWholePizza = new System.Windows.Forms.Button();
            this.btnCoffee = new System.Windows.Forms.Button();
            this.btnPizzaSlice = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.lblCurrentDate = new System.Windows.Forms.Label();
            this.btnDeleteItem = new System.Windows.Forms.Button();
            this.btnPay = new System.Windows.Forms.Button();
            this.lblEmployeeName = new System.Windows.Forms.Label();
            this.lblLabelReceipt = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnQuantity = new System.Windows.Forms.Button();
            this.btnFAQ = new System.Windows.Forms.Button();
            this.pnlOrderFunctions = new System.Windows.Forms.Panel();
            this.btnSuspendOrder = new System.Windows.Forms.Button();
            this.btnCancelOrder = new System.Windows.Forms.Button();
            this.btnOrderHistory = new System.Windows.Forms.Button();
            this.btnGoToManagerMode = new System.Windows.Forms.Button();
            this.btnPaidOut = new System.Windows.Forms.Button();
            this.btnHouseCharge = new System.Windows.Forms.Button();
            this.btnRefund = new System.Windows.Forms.Button();
            this.btnLabor = new System.Windows.Forms.Button();
            this.btnPage1 = new System.Windows.Forms.Button();
            this.btnPage2 = new System.Windows.Forms.Button();
            this.btnPage3 = new System.Windows.Forms.Button();
            this.btnPage4 = new System.Windows.Forms.Button();
            this.btnPage5 = new System.Windows.Forms.Button();
            this.pnlKeypad = new System.Windows.Forms.Panel();
            this.btn0Keypad = new System.Windows.Forms.Button();
            this.txtbKeypad = new System.Windows.Forms.TextBox();
            this.btn3Keypad = new System.Windows.Forms.Button();
            this.btn2Keypad = new System.Windows.Forms.Button();
            this.btn1Keypad = new System.Windows.Forms.Button();
            this.btn6Keypad = new System.Windows.Forms.Button();
            this.btn5Kepad = new System.Windows.Forms.Button();
            this.btn4Keypad = new System.Windows.Forms.Button();
            this.btn9Keypad = new System.Windows.Forms.Button();
            this.btn8Keypad = new System.Windows.Forms.Button();
            this.btn7Keypad = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.pnlButtonSection = new System.Windows.Forms.Panel();
            this.pnlCurrentOrder = new System.Windows.Forms.Panel();
            this.pnlOrdering = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlOrderItems.SuspendLayout();
            this.pnlMenuPage2.SuspendLayout();
            this.pnlMenuPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.pnlOrderFunctions.SuspendLayout();
            this.pnlKeypad.SuspendLayout();
            this.pnlButtonSection.SuspendLayout();
            this.pnlCurrentOrder.SuspendLayout();
            this.pnlOrdering.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1418, 68);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(146, 47);
            this.button1.TabIndex = 0;
            this.button1.Text = "Sign Out";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblResolution
            // 
            this.lblResolution.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResolution.Location = new System.Drawing.Point(267, 82);
            this.lblResolution.Name = "lblResolution";
            this.lblResolution.Size = new System.Drawing.Size(181, 33);
            this.lblResolution.TabIndex = 1;
            this.lblResolution.Text = "Resolution";
            this.lblResolution.Visible = false;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(271, 43);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(177, 34);
            this.button2.TabIndex = 2;
            this.button2.Text = "Get Resolution";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lstbOrders
            // 
            this.lstbOrders.BackColor = System.Drawing.SystemColors.Info;
            this.lstbOrders.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstbOrders.FormattingEnabled = true;
            this.lstbOrders.ItemHeight = 24;
            this.lstbOrders.Location = new System.Drawing.Point(3, 46);
            this.lstbOrders.Name = "lstbOrders";
            this.lstbOrders.Size = new System.Drawing.Size(440, 436);
            this.lstbOrders.TabIndex = 3;
            // 
            // rtxtbOrderFinal
            // 
            this.rtxtbOrderFinal.BackColor = System.Drawing.SystemColors.Info;
            this.rtxtbOrderFinal.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtxtbOrderFinal.Location = new System.Drawing.Point(3, 520);
            this.rtxtbOrderFinal.Name = "rtxtbOrderFinal";
            this.rtxtbOrderFinal.ReadOnly = true;
            this.rtxtbOrderFinal.Size = new System.Drawing.Size(440, 242);
            this.rtxtbOrderFinal.TabIndex = 4;
            this.rtxtbOrderFinal.Text = "";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(214, 155);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // OrderingTimer
            // 
            this.OrderingTimer.Tick += new System.EventHandler(this.OrderingTimer_Tick);
            // 
            // pnlOrderItems
            // 
            this.pnlOrderItems.BackColor = System.Drawing.SystemColors.Info;
            this.pnlOrderItems.Controls.Add(this.pnlMenuPage2);
            this.pnlOrderItems.Controls.Add(this.pnlMenuPage1);
            this.pnlOrderItems.Location = new System.Drawing.Point(9, 49);
            this.pnlOrderItems.Name = "pnlOrderItems";
            this.pnlOrderItems.Size = new System.Drawing.Size(738, 620);
            this.pnlOrderItems.TabIndex = 7;
            // 
            // pnlMenuPage2
            // 
            this.pnlMenuPage2.Controls.Add(this.btn10);
            this.pnlMenuPage2.Controls.Add(this.btn14);
            this.pnlMenuPage2.Controls.Add(this.btn17);
            this.pnlMenuPage2.Controls.Add(this.btn18);
            this.pnlMenuPage2.Controls.Add(this.btn12);
            this.pnlMenuPage2.Controls.Add(this.btn16);
            this.pnlMenuPage2.Controls.Add(this.btn11);
            this.pnlMenuPage2.Controls.Add(this.btn15);
            this.pnlMenuPage2.Controls.Add(this.btn13);
            this.pnlMenuPage2.Location = new System.Drawing.Point(34, 25);
            this.pnlMenuPage2.Name = "pnlMenuPage2";
            this.pnlMenuPage2.Size = new System.Drawing.Size(671, 559);
            this.pnlMenuPage2.TabIndex = 30;
            this.pnlMenuPage2.Visible = false;
            // 
            // btn10
            // 
            this.btn10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn10.Location = new System.Drawing.Point(0, 0);
            this.btn10.Name = "btn10";
            this.btn10.Size = new System.Drawing.Size(168, 169);
            this.btn10.TabIndex = 20;
            this.btn10.UseVisualStyleBackColor = true;
            this.btn10.Visible = false;
            this.btn10.Click += new System.EventHandler(this.btn10_Click);
            // 
            // btn14
            // 
            this.btn14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn14.Location = new System.Drawing.Point(258, 198);
            this.btn14.Name = "btn14";
            this.btn14.Size = new System.Drawing.Size(168, 169);
            this.btn14.TabIndex = 28;
            this.btn14.UseVisualStyleBackColor = true;
            this.btn14.Visible = false;
            // 
            // btn17
            // 
            this.btn17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn17.Location = new System.Drawing.Point(258, 390);
            this.btn17.Name = "btn17";
            this.btn17.Size = new System.Drawing.Size(168, 169);
            this.btn17.TabIndex = 21;
            this.btn17.UseVisualStyleBackColor = true;
            this.btn17.Visible = false;
            // 
            // btn18
            // 
            this.btn18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn18.Location = new System.Drawing.Point(503, 390);
            this.btn18.Name = "btn18";
            this.btn18.Size = new System.Drawing.Size(168, 169);
            this.btn18.TabIndex = 27;
            this.btn18.UseVisualStyleBackColor = true;
            this.btn18.Visible = false;
            // 
            // btn12
            // 
            this.btn12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn12.Location = new System.Drawing.Point(503, 0);
            this.btn12.Name = "btn12";
            this.btn12.Size = new System.Drawing.Size(168, 169);
            this.btn12.TabIndex = 22;
            this.btn12.UseVisualStyleBackColor = true;
            this.btn12.Visible = false;
            // 
            // btn16
            // 
            this.btn16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn16.Location = new System.Drawing.Point(0, 390);
            this.btn16.Name = "btn16";
            this.btn16.Size = new System.Drawing.Size(168, 169);
            this.btn16.TabIndex = 26;
            this.btn16.UseVisualStyleBackColor = true;
            this.btn16.Visible = false;
            // 
            // btn11
            // 
            this.btn11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn11.Location = new System.Drawing.Point(258, 0);
            this.btn11.Name = "btn11";
            this.btn11.Size = new System.Drawing.Size(168, 169);
            this.btn11.TabIndex = 23;
            this.btn11.UseVisualStyleBackColor = true;
            this.btn11.Visible = false;
            // 
            // btn15
            // 
            this.btn15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn15.Location = new System.Drawing.Point(503, 198);
            this.btn15.Name = "btn15";
            this.btn15.Size = new System.Drawing.Size(168, 169);
            this.btn15.TabIndex = 25;
            this.btn15.UseVisualStyleBackColor = true;
            this.btn15.Visible = false;
            // 
            // btn13
            // 
            this.btn13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn13.Location = new System.Drawing.Point(0, 198);
            this.btn13.Name = "btn13";
            this.btn13.Size = new System.Drawing.Size(168, 169);
            this.btn13.TabIndex = 24;
            this.btn13.UseVisualStyleBackColor = true;
            this.btn13.Visible = false;
            // 
            // pnlMenuPage1
            // 
            this.pnlMenuPage1.Controls.Add(this.btnBurger);
            this.pnlMenuPage1.Controls.Add(this.btnChicken);
            this.pnlMenuPage1.Controls.Add(this.btnBagel);
            this.pnlMenuPage1.Controls.Add(this.btnSoda);
            this.pnlMenuPage1.Controls.Add(this.btnHotDog);
            this.pnlMenuPage1.Controls.Add(this.btnIceCream);
            this.pnlMenuPage1.Controls.Add(this.btnWholePizza);
            this.pnlMenuPage1.Controls.Add(this.btnCoffee);
            this.pnlMenuPage1.Controls.Add(this.btnPizzaSlice);
            this.pnlMenuPage1.Location = new System.Drawing.Point(34, 25);
            this.pnlMenuPage1.Name = "pnlMenuPage1";
            this.pnlMenuPage1.Size = new System.Drawing.Size(671, 559);
            this.pnlMenuPage1.TabIndex = 29;
            // 
            // btnBurger
            // 
            this.btnBurger.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBurger.BackgroundImage")));
            this.btnBurger.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBurger.Location = new System.Drawing.Point(0, 0);
            this.btnBurger.Name = "btnBurger";
            this.btnBurger.Size = new System.Drawing.Size(168, 169);
            this.btnBurger.TabIndex = 20;
            this.btnBurger.UseVisualStyleBackColor = true;
            this.btnBurger.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnChicken
            // 
            this.btnChicken.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnChicken.BackgroundImage")));
            this.btnChicken.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnChicken.Location = new System.Drawing.Point(258, 198);
            this.btnChicken.Name = "btnChicken";
            this.btnChicken.Size = new System.Drawing.Size(168, 169);
            this.btnChicken.TabIndex = 28;
            this.btnChicken.UseVisualStyleBackColor = true;
            this.btnChicken.Click += new System.EventHandler(this.btnChicken_Click);
            // 
            // btnBagel
            // 
            this.btnBagel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBagel.BackgroundImage")));
            this.btnBagel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBagel.Location = new System.Drawing.Point(258, 390);
            this.btnBagel.Name = "btnBagel";
            this.btnBagel.Size = new System.Drawing.Size(168, 169);
            this.btnBagel.TabIndex = 21;
            this.btnBagel.UseVisualStyleBackColor = true;
            this.btnBagel.Click += new System.EventHandler(this.btnBagel_Click);
            // 
            // btnSoda
            // 
            this.btnSoda.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSoda.BackgroundImage")));
            this.btnSoda.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSoda.Location = new System.Drawing.Point(503, 390);
            this.btnSoda.Name = "btnSoda";
            this.btnSoda.Size = new System.Drawing.Size(168, 169);
            this.btnSoda.TabIndex = 27;
            this.btnSoda.UseVisualStyleBackColor = true;
            this.btnSoda.Click += new System.EventHandler(this.btnSode_Click);
            // 
            // btnHotDog
            // 
            this.btnHotDog.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnHotDog.BackgroundImage")));
            this.btnHotDog.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHotDog.Location = new System.Drawing.Point(503, 0);
            this.btnHotDog.Name = "btnHotDog";
            this.btnHotDog.Size = new System.Drawing.Size(168, 169);
            this.btnHotDog.TabIndex = 22;
            this.btnHotDog.UseVisualStyleBackColor = true;
            this.btnHotDog.Click += new System.EventHandler(this.btnHotDog_Click);
            // 
            // btnIceCream
            // 
            this.btnIceCream.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnIceCream.BackgroundImage")));
            this.btnIceCream.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnIceCream.Location = new System.Drawing.Point(0, 390);
            this.btnIceCream.Name = "btnIceCream";
            this.btnIceCream.Size = new System.Drawing.Size(168, 169);
            this.btnIceCream.TabIndex = 26;
            this.btnIceCream.UseVisualStyleBackColor = true;
            this.btnIceCream.Click += new System.EventHandler(this.btnIceCream_Click);
            // 
            // btnWholePizza
            // 
            this.btnWholePizza.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnWholePizza.BackgroundImage")));
            this.btnWholePizza.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnWholePizza.Location = new System.Drawing.Point(258, 0);
            this.btnWholePizza.Name = "btnWholePizza";
            this.btnWholePizza.Size = new System.Drawing.Size(168, 169);
            this.btnWholePizza.TabIndex = 23;
            this.btnWholePizza.UseVisualStyleBackColor = true;
            this.btnWholePizza.Click += new System.EventHandler(this.btnWholePizza_Click);
            // 
            // btnCoffee
            // 
            this.btnCoffee.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCoffee.BackgroundImage")));
            this.btnCoffee.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCoffee.Location = new System.Drawing.Point(503, 198);
            this.btnCoffee.Name = "btnCoffee";
            this.btnCoffee.Size = new System.Drawing.Size(168, 169);
            this.btnCoffee.TabIndex = 25;
            this.btnCoffee.UseVisualStyleBackColor = true;
            this.btnCoffee.Click += new System.EventHandler(this.btnCoffee_Click);
            // 
            // btnPizzaSlice
            // 
            this.btnPizzaSlice.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPizzaSlice.BackgroundImage")));
            this.btnPizzaSlice.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPizzaSlice.Location = new System.Drawing.Point(0, 198);
            this.btnPizzaSlice.Name = "btnPizzaSlice";
            this.btnPizzaSlice.Size = new System.Drawing.Size(168, 169);
            this.btnPizzaSlice.TabIndex = 24;
            this.btnPizzaSlice.UseVisualStyleBackColor = true;
            this.btnPizzaSlice.Click += new System.EventHandler(this.btnPizzaSlice_Click);
            // 
            // lblCurrentDate
            // 
            this.lblCurrentDate.BackColor = System.Drawing.Color.LightCoral;
            this.lblCurrentDate.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentDate.Location = new System.Drawing.Point(1305, 13);
            this.lblCurrentDate.Name = "lblCurrentDate";
            this.lblCurrentDate.Size = new System.Drawing.Size(259, 52);
            this.lblCurrentDate.TabIndex = 8;
            this.lblCurrentDate.Text = "Current Date";
            this.lblCurrentDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnDeleteItem
            // 
            this.btnDeleteItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnDeleteItem.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteItem.Location = new System.Drawing.Point(30, 25);
            this.btnDeleteItem.Name = "btnDeleteItem";
            this.btnDeleteItem.Size = new System.Drawing.Size(146, 86);
            this.btnDeleteItem.TabIndex = 9;
            this.btnDeleteItem.Text = "Delete Item";
            this.btnDeleteItem.UseVisualStyleBackColor = false;
            this.btnDeleteItem.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnPay
            // 
            this.btnPay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnPay.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPay.Location = new System.Drawing.Point(30, 600);
            this.btnPay.Name = "btnPay";
            this.btnPay.Size = new System.Drawing.Size(146, 86);
            this.btnPay.TabIndex = 10;
            this.btnPay.Text = "PAY";
            this.btnPay.UseVisualStyleBackColor = false;
            this.btnPay.Click += new System.EventHandler(this.btnPay_Click);
            // 
            // lblEmployeeName
            // 
            this.lblEmployeeName.BackColor = System.Drawing.Color.Silver;
            this.lblEmployeeName.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployeeName.Location = new System.Drawing.Point(941, 13);
            this.lblEmployeeName.Name = "lblEmployeeName";
            this.lblEmployeeName.Size = new System.Drawing.Size(358, 52);
            this.lblEmployeeName.TabIndex = 11;
            this.lblEmployeeName.Text = "Employee\'s Name";
            this.lblEmployeeName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLabelReceipt
            // 
            this.lblLabelReceipt.BackColor = System.Drawing.Color.Transparent;
            this.lblLabelReceipt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLabelReceipt.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLabelReceipt.ForeColor = System.Drawing.Color.Black;
            this.lblLabelReceipt.Location = new System.Drawing.Point(3, 0);
            this.lblLabelReceipt.Name = "lblLabelReceipt";
            this.lblLabelReceipt.Size = new System.Drawing.Size(440, 43);
            this.lblLabelReceipt.TabIndex = 12;
            this.lblLabelReceipt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1358, 68);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(54, 47);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 13;
            this.pictureBox2.TabStop = false;
            // 
            // btnQuantity
            // 
            this.btnQuantity.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuantity.Location = new System.Drawing.Point(30, 128);
            this.btnQuantity.Name = "btnQuantity";
            this.btnQuantity.Size = new System.Drawing.Size(146, 86);
            this.btnQuantity.TabIndex = 19;
            this.btnQuantity.Text = "Quantity";
            this.btnQuantity.UseVisualStyleBackColor = true;
            // 
            // btnFAQ
            // 
            this.btnFAQ.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFAQ.Location = new System.Drawing.Point(552, 16);
            this.btnFAQ.Name = "btnFAQ";
            this.btnFAQ.Size = new System.Drawing.Size(138, 49);
            this.btnFAQ.TabIndex = 21;
            this.btnFAQ.Text = "FAQ";
            this.btnFAQ.UseVisualStyleBackColor = true;
            this.btnFAQ.Click += new System.EventHandler(this.btnFAQ_Click);
            // 
            // pnlOrderFunctions
            // 
            this.pnlOrderFunctions.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pnlOrderFunctions.Controls.Add(this.btnSuspendOrder);
            this.pnlOrderFunctions.Controls.Add(this.btnCancelOrder);
            this.pnlOrderFunctions.Controls.Add(this.btnOrderHistory);
            this.pnlOrderFunctions.Controls.Add(this.btnDeleteItem);
            this.pnlOrderFunctions.Controls.Add(this.btnPay);
            this.pnlOrderFunctions.Controls.Add(this.btnQuantity);
            this.pnlOrderFunctions.Location = new System.Drawing.Point(522, 240);
            this.pnlOrderFunctions.Name = "pnlOrderFunctions";
            this.pnlOrderFunctions.Size = new System.Drawing.Size(209, 716);
            this.pnlOrderFunctions.TabIndex = 22;
            // 
            // btnSuspendOrder
            // 
            this.btnSuspendOrder.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuspendOrder.Location = new System.Drawing.Point(30, 437);
            this.btnSuspendOrder.Name = "btnSuspendOrder";
            this.btnSuspendOrder.Size = new System.Drawing.Size(146, 86);
            this.btnSuspendOrder.TabIndex = 24;
            this.btnSuspendOrder.Text = "Suspend";
            this.btnSuspendOrder.UseVisualStyleBackColor = true;
            // 
            // btnCancelOrder
            // 
            this.btnCancelOrder.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelOrder.Location = new System.Drawing.Point(30, 334);
            this.btnCancelOrder.Name = "btnCancelOrder";
            this.btnCancelOrder.Size = new System.Drawing.Size(146, 86);
            this.btnCancelOrder.TabIndex = 23;
            this.btnCancelOrder.Text = "Cancel Order";
            this.btnCancelOrder.UseVisualStyleBackColor = true;
            // 
            // btnOrderHistory
            // 
            this.btnOrderHistory.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrderHistory.Location = new System.Drawing.Point(30, 231);
            this.btnOrderHistory.Name = "btnOrderHistory";
            this.btnOrderHistory.Size = new System.Drawing.Size(146, 86);
            this.btnOrderHistory.TabIndex = 22;
            this.btnOrderHistory.Text = "Order History";
            this.btnOrderHistory.UseVisualStyleBackColor = true;
            // 
            // btnGoToManagerMode
            // 
            this.btnGoToManagerMode.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGoToManagerMode.Location = new System.Drawing.Point(1030, 68);
            this.btnGoToManagerMode.Name = "btnGoToManagerMode";
            this.btnGoToManagerMode.Size = new System.Drawing.Size(206, 47);
            this.btnGoToManagerMode.TabIndex = 23;
            this.btnGoToManagerMode.Text = "Back Office";
            this.btnGoToManagerMode.UseVisualStyleBackColor = true;
            this.btnGoToManagerMode.Visible = false;
            // 
            // btnPaidOut
            // 
            this.btnPaidOut.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPaidOut.Location = new System.Drawing.Point(382, 679);
            this.btnPaidOut.Name = "btnPaidOut";
            this.btnPaidOut.Size = new System.Drawing.Size(146, 86);
            this.btnPaidOut.TabIndex = 28;
            this.btnPaidOut.Text = "Paid Out";
            this.btnPaidOut.UseVisualStyleBackColor = true;
            // 
            // btnHouseCharge
            // 
            this.btnHouseCharge.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHouseCharge.Location = new System.Drawing.Point(545, 679);
            this.btnHouseCharge.Name = "btnHouseCharge";
            this.btnHouseCharge.Size = new System.Drawing.Size(146, 86);
            this.btnHouseCharge.TabIndex = 27;
            this.btnHouseCharge.Text = "House Charge";
            this.btnHouseCharge.UseVisualStyleBackColor = true;
            // 
            // btnRefund
            // 
            this.btnRefund.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefund.Location = new System.Drawing.Point(56, 679);
            this.btnRefund.Name = "btnRefund";
            this.btnRefund.Size = new System.Drawing.Size(146, 86);
            this.btnRefund.TabIndex = 26;
            this.btnRefund.Text = "Refund";
            this.btnRefund.UseVisualStyleBackColor = true;
            // 
            // btnLabor
            // 
            this.btnLabor.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLabor.Location = new System.Drawing.Point(219, 679);
            this.btnLabor.Name = "btnLabor";
            this.btnLabor.Size = new System.Drawing.Size(146, 86);
            this.btnLabor.TabIndex = 25;
            this.btnLabor.Text = "Labor Report";
            this.btnLabor.UseVisualStyleBackColor = true;
            // 
            // btnPage1
            // 
            this.btnPage1.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPage1.Location = new System.Drawing.Point(46, 3);
            this.btnPage1.Name = "btnPage1";
            this.btnPage1.Size = new System.Drawing.Size(100, 40);
            this.btnPage1.TabIndex = 25;
            this.btnPage1.Text = "Page1";
            this.btnPage1.UseVisualStyleBackColor = true;
            this.btnPage1.Visible = false;
            this.btnPage1.Click += new System.EventHandler(this.btnPage1_Click);
            // 
            // btnPage2
            // 
            this.btnPage2.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPage2.Location = new System.Drawing.Point(188, 3);
            this.btnPage2.Name = "btnPage2";
            this.btnPage2.Size = new System.Drawing.Size(100, 40);
            this.btnPage2.TabIndex = 26;
            this.btnPage2.Text = "Page2";
            this.btnPage2.UseVisualStyleBackColor = true;
            this.btnPage2.Visible = false;
            this.btnPage2.Click += new System.EventHandler(this.btnPage2_Click);
            // 
            // btnPage3
            // 
            this.btnPage3.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPage3.Location = new System.Drawing.Point(330, 3);
            this.btnPage3.Name = "btnPage3";
            this.btnPage3.Size = new System.Drawing.Size(100, 40);
            this.btnPage3.TabIndex = 27;
            this.btnPage3.Text = "Page3";
            this.btnPage3.UseVisualStyleBackColor = true;
            this.btnPage3.Visible = false;
            // 
            // btnPage4
            // 
            this.btnPage4.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPage4.Location = new System.Drawing.Point(472, 3);
            this.btnPage4.Name = "btnPage4";
            this.btnPage4.Size = new System.Drawing.Size(100, 40);
            this.btnPage4.TabIndex = 28;
            this.btnPage4.Text = "Page4";
            this.btnPage4.UseVisualStyleBackColor = true;
            this.btnPage4.Visible = false;
            // 
            // btnPage5
            // 
            this.btnPage5.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPage5.Location = new System.Drawing.Point(614, 3);
            this.btnPage5.Name = "btnPage5";
            this.btnPage5.Size = new System.Drawing.Size(100, 40);
            this.btnPage5.TabIndex = 29;
            this.btnPage5.Text = "Page5";
            this.btnPage5.UseVisualStyleBackColor = true;
            this.btnPage5.Visible = false;
            // 
            // pnlKeypad
            // 
            this.pnlKeypad.BackColor = System.Drawing.Color.Silver;
            this.pnlKeypad.Controls.Add(this.btn0Keypad);
            this.pnlKeypad.Controls.Add(this.txtbKeypad);
            this.pnlKeypad.Controls.Add(this.btn3Keypad);
            this.pnlKeypad.Controls.Add(this.btn2Keypad);
            this.pnlKeypad.Controls.Add(this.btn1Keypad);
            this.pnlKeypad.Controls.Add(this.btn6Keypad);
            this.pnlKeypad.Controls.Add(this.btn5Kepad);
            this.pnlKeypad.Controls.Add(this.btn4Keypad);
            this.pnlKeypad.Controls.Add(this.btn9Keypad);
            this.pnlKeypad.Controls.Add(this.btn8Keypad);
            this.pnlKeypad.Controls.Add(this.btn7Keypad);
            this.pnlKeypad.Controls.Add(this.button4);
            this.pnlKeypad.Controls.Add(this.button3);
            this.pnlKeypad.Location = new System.Drawing.Point(570, 296);
            this.pnlKeypad.Name = "pnlKeypad";
            this.pnlKeypad.Size = new System.Drawing.Size(310, 386);
            this.pnlKeypad.TabIndex = 31;
            this.pnlKeypad.Visible = false;
            // 
            // btn0Keypad
            // 
            this.btn0Keypad.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn0Keypad.Location = new System.Drawing.Point(37, 304);
            this.btn0Keypad.Name = "btn0Keypad";
            this.btn0Keypad.Size = new System.Drawing.Size(75, 61);
            this.btn0Keypad.TabIndex = 32;
            this.btn0Keypad.Text = "0";
            this.btn0Keypad.UseVisualStyleBackColor = true;
            // 
            // txtbKeypad
            // 
            this.txtbKeypad.Location = new System.Drawing.Point(37, 18);
            this.txtbKeypad.Multiline = true;
            this.txtbKeypad.Name = "txtbKeypad";
            this.txtbKeypad.ReadOnly = true;
            this.txtbKeypad.Size = new System.Drawing.Size(156, 70);
            this.txtbKeypad.TabIndex = 31;
            // 
            // btn3Keypad
            // 
            this.btn3Keypad.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn3Keypad.Location = new System.Drawing.Point(201, 230);
            this.btn3Keypad.Name = "btn3Keypad";
            this.btn3Keypad.Size = new System.Drawing.Size(75, 61);
            this.btn3Keypad.TabIndex = 30;
            this.btn3Keypad.Text = "3";
            this.btn3Keypad.UseVisualStyleBackColor = true;
            // 
            // btn2Keypad
            // 
            this.btn2Keypad.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn2Keypad.Location = new System.Drawing.Point(120, 230);
            this.btn2Keypad.Name = "btn2Keypad";
            this.btn2Keypad.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn2Keypad.Size = new System.Drawing.Size(75, 61);
            this.btn2Keypad.TabIndex = 29;
            this.btn2Keypad.Text = "2";
            this.btn2Keypad.UseVisualStyleBackColor = true;
            // 
            // btn1Keypad
            // 
            this.btn1Keypad.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1Keypad.Location = new System.Drawing.Point(37, 230);
            this.btn1Keypad.Name = "btn1Keypad";
            this.btn1Keypad.Size = new System.Drawing.Size(75, 61);
            this.btn1Keypad.TabIndex = 28;
            this.btn1Keypad.Text = "1";
            this.btn1Keypad.UseVisualStyleBackColor = true;
            // 
            // btn6Keypad
            // 
            this.btn6Keypad.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn6Keypad.Location = new System.Drawing.Point(201, 162);
            this.btn6Keypad.Name = "btn6Keypad";
            this.btn6Keypad.Size = new System.Drawing.Size(75, 61);
            this.btn6Keypad.TabIndex = 27;
            this.btn6Keypad.Text = "6";
            this.btn6Keypad.UseVisualStyleBackColor = true;
            // 
            // btn5Kepad
            // 
            this.btn5Kepad.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn5Kepad.Location = new System.Drawing.Point(120, 162);
            this.btn5Kepad.Name = "btn5Kepad";
            this.btn5Kepad.Size = new System.Drawing.Size(75, 61);
            this.btn5Kepad.TabIndex = 26;
            this.btn5Kepad.Text = "5";
            this.btn5Kepad.UseVisualStyleBackColor = true;
            // 
            // btn4Keypad
            // 
            this.btn4Keypad.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn4Keypad.Location = new System.Drawing.Point(37, 162);
            this.btn4Keypad.Name = "btn4Keypad";
            this.btn4Keypad.Size = new System.Drawing.Size(75, 61);
            this.btn4Keypad.TabIndex = 25;
            this.btn4Keypad.Text = "4";
            this.btn4Keypad.UseVisualStyleBackColor = true;
            // 
            // btn9Keypad
            // 
            this.btn9Keypad.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn9Keypad.Location = new System.Drawing.Point(201, 94);
            this.btn9Keypad.Name = "btn9Keypad";
            this.btn9Keypad.Size = new System.Drawing.Size(75, 61);
            this.btn9Keypad.TabIndex = 24;
            this.btn9Keypad.Text = "9";
            this.btn9Keypad.UseVisualStyleBackColor = true;
            // 
            // btn8Keypad
            // 
            this.btn8Keypad.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn8Keypad.Location = new System.Drawing.Point(118, 94);
            this.btn8Keypad.Name = "btn8Keypad";
            this.btn8Keypad.Size = new System.Drawing.Size(75, 61);
            this.btn8Keypad.TabIndex = 23;
            this.btn8Keypad.Text = "8";
            this.btn8Keypad.UseVisualStyleBackColor = true;
            // 
            // btn7Keypad
            // 
            this.btn7Keypad.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn7Keypad.Location = new System.Drawing.Point(37, 94);
            this.btn7Keypad.Name = "btn7Keypad";
            this.btn7Keypad.Size = new System.Drawing.Size(75, 61);
            this.btn7Keypad.TabIndex = 22;
            this.btn7Keypad.Text = "7";
            this.btn7Keypad.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(201, 18);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 70);
            this.button4.TabIndex = 21;
            this.button4.Text = "Clear";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(120, 304);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(156, 61);
            this.button3.TabIndex = 20;
            this.button3.Text = "Enter";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // pnlButtonSection
            // 
            this.pnlButtonSection.Controls.Add(this.btnPaidOut);
            this.pnlButtonSection.Controls.Add(this.btnPage1);
            this.pnlButtonSection.Controls.Add(this.btnPage2);
            this.pnlButtonSection.Controls.Add(this.btnHouseCharge);
            this.pnlButtonSection.Controls.Add(this.btnPage5);
            this.pnlButtonSection.Controls.Add(this.btnPage3);
            this.pnlButtonSection.Controls.Add(this.btnRefund);
            this.pnlButtonSection.Controls.Add(this.btnPage4);
            this.pnlButtonSection.Controls.Add(this.btnLabor);
            this.pnlButtonSection.Controls.Add(this.pnlOrderItems);
            this.pnlButtonSection.Location = new System.Drawing.Point(746, 186);
            this.pnlButtonSection.Name = "pnlButtonSection";
            this.pnlButtonSection.Size = new System.Drawing.Size(755, 795);
            this.pnlButtonSection.TabIndex = 32;
            // 
            // pnlCurrentOrder
            // 
            this.pnlCurrentOrder.Controls.Add(this.lblLabelReceipt);
            this.pnlCurrentOrder.Controls.Add(this.lstbOrders);
            this.pnlCurrentOrder.Controls.Add(this.rtxtbOrderFinal);
            this.pnlCurrentOrder.Location = new System.Drawing.Point(35, 186);
            this.pnlCurrentOrder.Name = "pnlCurrentOrder";
            this.pnlCurrentOrder.Size = new System.Drawing.Size(447, 762);
            this.pnlCurrentOrder.TabIndex = 33;
            // 
            // pnlOrdering
            // 
            this.pnlOrdering.Controls.Add(this.pictureBox1);
            this.pnlOrdering.Controls.Add(this.button1);
            this.pnlOrdering.Controls.Add(this.pnlCurrentOrder);
            this.pnlOrdering.Controls.Add(this.lblResolution);
            this.pnlOrdering.Controls.Add(this.pnlButtonSection);
            this.pnlOrdering.Controls.Add(this.button2);
            this.pnlOrdering.Controls.Add(this.btnGoToManagerMode);
            this.pnlOrdering.Controls.Add(this.lblCurrentDate);
            this.pnlOrdering.Controls.Add(this.pnlOrderFunctions);
            this.pnlOrdering.Controls.Add(this.lblEmployeeName);
            this.pnlOrdering.Controls.Add(this.btnFAQ);
            this.pnlOrdering.Controls.Add(this.pictureBox2);
            this.pnlOrdering.Location = new System.Drawing.Point(0, -1);
            this.pnlOrdering.Name = "pnlOrdering";
            this.pnlOrdering.Size = new System.Drawing.Size(1562, 1002);
            this.pnlOrdering.TabIndex = 34;
            // 
            // frmMain
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1563, 1002);
            this.Controls.Add(this.pnlOrdering);
            this.Controls.Add(this.pnlKeypad);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximumSize = new System.Drawing.Size(1563, 1002);
            this.MinimumSize = new System.Drawing.Size(1563, 1002);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlOrderItems.ResumeLayout(false);
            this.pnlMenuPage2.ResumeLayout(false);
            this.pnlMenuPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.pnlOrderFunctions.ResumeLayout(false);
            this.pnlKeypad.ResumeLayout(false);
            this.pnlKeypad.PerformLayout();
            this.pnlButtonSection.ResumeLayout(false);
            this.pnlCurrentOrder.ResumeLayout(false);
            this.pnlOrdering.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.Button button1;
        public System.Windows.Forms.Label lblResolution;
        public System.Windows.Forms.Button button2;
        public System.Windows.Forms.ListBox lstbOrders;
        public System.Windows.Forms.RichTextBox rtxtbOrderFinal;
        public System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.Timer OrderingTimer;
        public System.Windows.Forms.Panel pnlOrderItems;
        public System.ComponentModel.BackgroundWorker backgroundWorker1;
        public System.Windows.Forms.Label lblCurrentDate;
        public System.Windows.Forms.Button btnDeleteItem;
        public System.Windows.Forms.Button btnBurger;
        public System.Windows.Forms.Button btnChicken;
        public System.Windows.Forms.Button btnSoda;
        public System.Windows.Forms.Button btnIceCream;
        public System.Windows.Forms.Button btnCoffee;
        public System.Windows.Forms.Button btnPizzaSlice;
        public System.Windows.Forms.Button btnWholePizza;
        public System.Windows.Forms.Button btnHotDog;
        public System.Windows.Forms.Button btnBagel;
        public System.Windows.Forms.Button btnPay;
        public System.Windows.Forms.Label lblEmployeeName;
        public System.Windows.Forms.Label lblLabelReceipt;
        public System.Windows.Forms.PictureBox pictureBox2;
        public System.Windows.Forms.Button btnQuantity;
        public System.Windows.Forms.Button btnFAQ;
        public System.Windows.Forms.Panel pnlOrderFunctions;
        public System.Windows.Forms.Panel pnlMenuPage2;
        public System.Windows.Forms.Button btn10;
        public System.Windows.Forms.Button btn14;
        public System.Windows.Forms.Button btn17;
        public System.Windows.Forms.Button btn18;
        public System.Windows.Forms.Button btn12;
        public System.Windows.Forms.Button btn16;
        public System.Windows.Forms.Button btn11;
        public System.Windows.Forms.Button btn15;
        public System.Windows.Forms.Button btn13;
        public System.Windows.Forms.Panel pnlMenuPage1;
        public System.Windows.Forms.Button btnSuspendOrder;
        public System.Windows.Forms.Button btnCancelOrder;
        public System.Windows.Forms.Button btnOrderHistory;
        public System.Windows.Forms.Button btnGoToManagerMode;
        public System.Windows.Forms.Button btnPaidOut;
        public System.Windows.Forms.Button btnHouseCharge;
        public System.Windows.Forms.Button btnRefund;
        public System.Windows.Forms.Button btnLabor;
        public System.Windows.Forms.Button btnPage1;
        public System.Windows.Forms.Button btnPage2;
        private System.ComponentModel.IContainer components;
        public System.Windows.Forms.Button btnPage3;
        public System.Windows.Forms.Button btnPage4;
        public System.Windows.Forms.Button btnPage5;
        private System.Windows.Forms.Panel pnlKeypad;
        private System.Windows.Forms.Button btn0Keypad;
        private System.Windows.Forms.TextBox txtbKeypad;
        private System.Windows.Forms.Button btn3Keypad;
        private System.Windows.Forms.Button btn2Keypad;
        private System.Windows.Forms.Button btn1Keypad;
        private System.Windows.Forms.Button btn6Keypad;
        private System.Windows.Forms.Button btn5Kepad;
        private System.Windows.Forms.Button btn4Keypad;
        private System.Windows.Forms.Button btn9Keypad;
        private System.Windows.Forms.Button btn8Keypad;
        private System.Windows.Forms.Button btn7Keypad;
        public System.Windows.Forms.Button button4;
        public System.Windows.Forms.Button button3;
        private System.Windows.Forms.Panel pnlButtonSection;
        private System.Windows.Forms.Panel pnlCurrentOrder;
        private System.Windows.Forms.Panel pnlOrdering;
    }
}

