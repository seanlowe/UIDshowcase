﻿namespace EAPOS_Project
{
    partial class frmManagerMode
    {

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        public void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label lblEmployeeId;
            System.Windows.Forms.Label lblFirstName;
            System.Windows.Forms.Label lblLastName;
            System.Windows.Forms.Label lblStatus;
            System.Windows.Forms.Label lblWage;
            System.Windows.Forms.Label colorblindLabel;
            System.Windows.Forms.Label leftHandedLabel;
            System.Windows.Forms.Label addOnOptionsLabel;
            System.Windows.Forms.Label sizeOptionsLabel;
            System.Windows.Forms.Label iceCreamOptionsLabel;
            System.Windows.Forms.Label lblUpdateItemName;
            System.Windows.Forms.Label lblUpdatePrice;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmManagerMode));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.Label leftHandedLabel1;
            System.Windows.Forms.Label colorblindLabel1;
            this.pnlManagerMode = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnSignOutManagerMode = new System.Windows.Forms.Button();
            this.lblManagerMode = new System.Windows.Forms.Label();
            this.btnOrderMode = new System.Windows.Forms.Button();
            this.btnSalesReport = new System.Windows.Forms.Button();
            this.btnCreateTrainingTests = new System.Windows.Forms.Button();
            this.btnProductManagement = new System.Windows.Forms.Button();
            this.btnEmployees = new System.Windows.Forms.Button();
            this.pnlEmployees = new System.Windows.Forms.Panel();
            this.pnlManageHours = new System.Windows.Forms.Panel();
            this.btnManageHours = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.gpbEmployee = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.leftHandedCheckBox = new System.Windows.Forms.CheckBox();
            this.colorblindCheckBox = new System.Windows.Forms.CheckBox();
            this.btnAddEmployee = new System.Windows.Forms.Button();
            this.btnUpdateEmployee = new System.Windows.Forms.Button();
            this.btnDeleteEmployee = new System.Windows.Forms.Button();
            this.btnQuitEmployees = new System.Windows.Forms.Button();
            this.lblEmployees = new System.Windows.Forms.Label();
            this.hoursBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.coffeeShopEmployeesDataSet1 = new EAPOS_Project.CoffeeShopEmployeesDataSet1();
            this.pnlProductMgmt = new System.Windows.Forms.Panel();
            this.gpbxUpdateItems = new System.Windows.Forms.GroupBox();
            this.btnUpdateItem = new System.Windows.Forms.Button();
            this.iceCreamOptionsCheckBox = new System.Windows.Forms.CheckBox();
            this.buttonMainPanelBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.storedItemsDataSet = new EAPOS_Project.StoredItemsDataSet();
            this.itemNameTextBox = new System.Windows.Forms.TextBox();
            this.priceTextBox = new System.Windows.Forms.TextBox();
            this.sizeOptionsCheckBox = new System.Windows.Forms.CheckBox();
            this.addOnOptionsCheckBox = new System.Windows.Forms.CheckBox();
            this.grpbProducts = new System.Windows.Forms.GroupBox();
            this.buttonMainPanelDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn6 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn7 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn8 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.grpbRemoveItem = new System.Windows.Forms.GroupBox();
            this.btnDeleteItem = new System.Windows.Forms.Button();
            this.txtbItemToDelete = new System.Windows.Forms.TextBox();
            this.lblItemToRemove = new System.Windows.Forms.Label();
            this.grpbAddItem = new System.Windows.Forms.GroupBox();
            this.lblSubMenus = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.btnAddItem = new System.Windows.Forms.Button();
            this.lblItemPrice = new System.Windows.Forms.Label();
            this.txtbItemPrice = new System.Windows.Forms.TextBox();
            this.lblItemName = new System.Windows.Forms.Label();
            this.txtbItemName = new System.Windows.Forms.TextBox();
            this.btnQuitProductMgmt = new System.Windows.Forms.Button();
            this.lblProductManagement = new System.Windows.Forms.Label();
            this.pnlConfirmDeletion = new System.Windows.Forms.Panel();
            this.lblConfirmDeletionWarning = new System.Windows.Forms.Label();
            this.btnCancelDeleteItem = new System.Windows.Forms.Button();
            this.lblDeleteWarningInfo = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.lblConfirmDeletion = new System.Windows.Forms.Label();
            this.buttonMainPanelBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.pnlCreateTest = new System.Windows.Forms.Panel();
            this.btnCreateNewTest = new System.Windows.Forms.Button();
            this.txtbNewTestName = new System.Windows.Forms.TextBox();
            this.lblNewTestName = new System.Windows.Forms.Label();
            this.btnQuitCreateTest = new System.Windows.Forms.Button();
            this.lblCreatePracticeTest = new System.Windows.Forms.Label();
            this.pnlSalesReport = new System.Windows.Forms.Panel();
            this.rtxtbSalesReport = new System.Windows.Forms.RichTextBox();
            this.lblSalesReport = new System.Windows.Forms.Label();
            this.btnQuitSalesReport = new System.Windows.Forms.Button();
            this.employeesBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.employeesBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.buttonMainPanelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.buttonMainPanelTableAdapter = new EAPOS_Project.StoredItemsDataSetTableAdapters.ButtonMainPanelTableAdapter();
            this.tableAdapterManager1 = new EAPOS_Project.StoredItemsDataSetTableAdapters.TableAdapterManager();
            this.hoursTableAdapter = new EAPOS_Project.CoffeeShopEmployeesDataSet1TableAdapters.HoursTableAdapter();
            this.tableAdapterManager2 = new EAPOS_Project.CoffeeShopEmployeesDataSet1TableAdapters.TableAdapterManager();
            this.gpbxSelectedImage = new System.Windows.Forms.GroupBox();
            this.pictureBoxSelectedImage = new System.Windows.Forms.PictureBox();
            this.btnAddImage = new System.Windows.Forms.Button();
            this.employeesBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.employeesTableAdapter1 = new EAPOS_Project.CoffeeShopEmployeesDataSet1TableAdapters.EmployeesTableAdapter();
            this.employeesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.coffeeShopEmployeesDataSet = new EAPOS_Project.CoffeeShopEmployeesDataSet();
            this.employeesTableAdapter = new EAPOS_Project.CoffeeShopEmployeesDataSetTableAdapters.EmployeesTableAdapter();
            this.tableAdapterManager = new EAPOS_Project.CoffeeShopEmployeesDataSetTableAdapters.TableAdapterManager();
            this.employeesDataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn9 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn10 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.txtbID = new System.Windows.Forms.TextBox();
            this.txtbFirstName = new System.Windows.Forms.TextBox();
            this.txtbLastName = new System.Windows.Forms.TextBox();
            this.txtbStatus = new System.Windows.Forms.TextBox();
            this.txtbWage = new System.Windows.Forms.TextBox();
            this.leftHandedCheckBox1 = new System.Windows.Forms.CheckBox();
            this.colorblindCheckBox1 = new System.Windows.Forms.CheckBox();
            lblEmployeeId = new System.Windows.Forms.Label();
            lblFirstName = new System.Windows.Forms.Label();
            lblLastName = new System.Windows.Forms.Label();
            lblStatus = new System.Windows.Forms.Label();
            lblWage = new System.Windows.Forms.Label();
            colorblindLabel = new System.Windows.Forms.Label();
            leftHandedLabel = new System.Windows.Forms.Label();
            addOnOptionsLabel = new System.Windows.Forms.Label();
            sizeOptionsLabel = new System.Windows.Forms.Label();
            iceCreamOptionsLabel = new System.Windows.Forms.Label();
            lblUpdateItemName = new System.Windows.Forms.Label();
            lblUpdatePrice = new System.Windows.Forms.Label();
            leftHandedLabel1 = new System.Windows.Forms.Label();
            colorblindLabel1 = new System.Windows.Forms.Label();
            this.pnlManagerMode.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlEmployees.SuspendLayout();
            this.gpbEmployee.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hoursBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coffeeShopEmployeesDataSet1)).BeginInit();
            this.pnlProductMgmt.SuspendLayout();
            this.gpbxUpdateItems.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.buttonMainPanelBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.storedItemsDataSet)).BeginInit();
            this.grpbProducts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.buttonMainPanelDataGridView)).BeginInit();
            this.grpbRemoveItem.SuspendLayout();
            this.grpbAddItem.SuspendLayout();
            this.pnlConfirmDeletion.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.buttonMainPanelBindingSource1)).BeginInit();
            this.pnlCreateTest.SuspendLayout();
            this.pnlSalesReport.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingNavigator)).BeginInit();
            this.employeesBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.buttonMainPanelBindingSource)).BeginInit();
            this.gpbxSelectedImage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSelectedImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coffeeShopEmployeesDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeesDataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblEmployeeId
            // 
            lblEmployeeId.AutoSize = true;
            lblEmployeeId.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lblEmployeeId.Location = new System.Drawing.Point(30, 49);
            lblEmployeeId.Name = "lblEmployeeId";
            lblEmployeeId.Size = new System.Drawing.Size(37, 31);
            lblEmployeeId.TabIndex = 13;
            lblEmployeeId.Text = "Id";
            // 
            // lblFirstName
            // 
            lblFirstName.AutoSize = true;
            lblFirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lblFirstName.Location = new System.Drawing.Point(26, 116);
            lblFirstName.Name = "lblFirstName";
            lblFirstName.Size = new System.Drawing.Size(147, 31);
            lblFirstName.TabIndex = 15;
            lblFirstName.Text = "First Name";
            // 
            // lblLastName
            // 
            lblLastName.AutoSize = true;
            lblLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lblLastName.Location = new System.Drawing.Point(26, 182);
            lblLastName.Name = "lblLastName";
            lblLastName.Size = new System.Drawing.Size(145, 31);
            lblLastName.TabIndex = 17;
            lblLastName.Text = "Last Name";
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lblStatus.Location = new System.Drawing.Point(26, 253);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new System.Drawing.Size(92, 31);
            lblStatus.TabIndex = 19;
            lblStatus.Text = "Status";
            // 
            // lblWage
            // 
            lblWage.AutoSize = true;
            lblWage.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lblWage.Location = new System.Drawing.Point(30, 323);
            lblWage.Name = "lblWage";
            lblWage.Size = new System.Drawing.Size(84, 31);
            lblWage.TabIndex = 21;
            lblWage.Text = "Wage";
            // 
            // colorblindLabel
            // 
            colorblindLabel.AutoSize = true;
            colorblindLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            colorblindLabel.Location = new System.Drawing.Point(55, 147);
            colorblindLabel.Name = "colorblindLabel";
            colorblindLabel.Size = new System.Drawing.Size(144, 31);
            colorblindLabel.TabIndex = 25;
            colorblindLabel.Text = "Colorblind:";
            colorblindLabel.Click += new System.EventHandler(this.colorblindLabel_Click);
            // 
            // leftHandedLabel
            // 
            leftHandedLabel.AutoSize = true;
            leftHandedLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            leftHandedLabel.Location = new System.Drawing.Point(42, 44);
            leftHandedLabel.Name = "leftHandedLabel";
            leftHandedLabel.Size = new System.Drawing.Size(170, 31);
            leftHandedLabel.TabIndex = 23;
            leftHandedLabel.Text = "Left Handed:";
            leftHandedLabel.Click += new System.EventHandler(this.leftHandedLabel_Click);
            // 
            // addOnOptionsLabel
            // 
            addOnOptionsLabel.AutoSize = true;
            addOnOptionsLabel.Location = new System.Drawing.Point(57, 185);
            addOnOptionsLabel.Name = "addOnOptionsLabel";
            addOnOptionsLabel.Size = new System.Drawing.Size(141, 20);
            addOnOptionsLabel.TabIndex = 13;
            addOnOptionsLabel.Text = "Add On Options:";
            // 
            // sizeOptionsLabel
            // 
            sizeOptionsLabel.AutoSize = true;
            sizeOptionsLabel.Location = new System.Drawing.Point(57, 215);
            sizeOptionsLabel.Name = "sizeOptionsLabel";
            sizeOptionsLabel.Size = new System.Drawing.Size(116, 20);
            sizeOptionsLabel.TabIndex = 15;
            sizeOptionsLabel.Text = "Size Options:";
            // 
            // iceCreamOptionsLabel
            // 
            iceCreamOptionsLabel.AutoSize = true;
            iceCreamOptionsLabel.Location = new System.Drawing.Point(57, 245);
            iceCreamOptionsLabel.Name = "iceCreamOptionsLabel";
            iceCreamOptionsLabel.Size = new System.Drawing.Size(163, 20);
            iceCreamOptionsLabel.TabIndex = 17;
            iceCreamOptionsLabel.Text = "Ice Cream Options:";
            // 
            // lblUpdateItemName
            // 
            lblUpdateItemName.AutoSize = true;
            lblUpdateItemName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lblUpdateItemName.Location = new System.Drawing.Point(21, 52);
            lblUpdateItemName.Name = "lblUpdateItemName";
            lblUpdateItemName.Size = new System.Drawing.Size(155, 31);
            lblUpdateItemName.TabIndex = 19;
            lblUpdateItemName.Text = "Item Name";
            // 
            // lblUpdatePrice
            // 
            lblUpdatePrice.AutoSize = true;
            lblUpdatePrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lblUpdatePrice.Location = new System.Drawing.Point(21, 122);
            lblUpdatePrice.Name = "lblUpdatePrice";
            lblUpdatePrice.Size = new System.Drawing.Size(81, 31);
            lblUpdatePrice.TabIndex = 20;
            lblUpdatePrice.Text = "Price";
            // 
            // pnlManagerMode
            // 
            this.pnlManagerMode.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlManagerMode.Controls.Add(this.pictureBox1);
            this.pnlManagerMode.Controls.Add(this.btnSignOutManagerMode);
            this.pnlManagerMode.Controls.Add(this.lblManagerMode);
            this.pnlManagerMode.Controls.Add(this.btnOrderMode);
            this.pnlManagerMode.Controls.Add(this.btnSalesReport);
            this.pnlManagerMode.Controls.Add(this.btnCreateTrainingTests);
            this.pnlManagerMode.Controls.Add(this.btnProductManagement);
            this.pnlManagerMode.Controls.Add(this.btnEmployees);
            this.pnlManagerMode.Location = new System.Drawing.Point(0, 0);
            this.pnlManagerMode.Name = "pnlManagerMode";
            this.pnlManagerMode.Size = new System.Drawing.Size(1545, 960);
            this.pnlManagerMode.TabIndex = 0;
            this.pnlManagerMode.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlManagerMode_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(14, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(214, 155);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // btnSignOutManagerMode
            // 
            this.btnSignOutManagerMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSignOutManagerMode.Location = new System.Drawing.Point(1338, 873);
            this.btnSignOutManagerMode.Name = "btnSignOutManagerMode";
            this.btnSignOutManagerMode.Size = new System.Drawing.Size(182, 60);
            this.btnSignOutManagerMode.TabIndex = 5;
            this.btnSignOutManagerMode.Text = "Sign Out";
            this.btnSignOutManagerMode.UseVisualStyleBackColor = true;
            this.btnSignOutManagerMode.Click += new System.EventHandler(this.btnSignOutManagerMode_Click);
            // 
            // lblManagerMode
            // 
            this.lblManagerMode.AutoSize = true;
            this.lblManagerMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblManagerMode.Location = new System.Drawing.Point(638, 23);
            this.lblManagerMode.Name = "lblManagerMode";
            this.lblManagerMode.Size = new System.Drawing.Size(268, 55);
            this.lblManagerMode.TabIndex = 4;
            this.lblManagerMode.Text = "Back Office";
            // 
            // btnOrderMode
            // 
            this.btnOrderMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrderMode.Location = new System.Drawing.Point(649, 769);
            this.btnOrderMode.Name = "btnOrderMode";
            this.btnOrderMode.Size = new System.Drawing.Size(246, 113);
            this.btnOrderMode.TabIndex = 2;
            this.btnOrderMode.Text = "Order Mode";
            this.btnOrderMode.UseVisualStyleBackColor = true;
            this.btnOrderMode.Click += new System.EventHandler(this.btnOrderMode_Click);
            // 
            // btnSalesReport
            // 
            this.btnSalesReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalesReport.Location = new System.Drawing.Point(876, 471);
            this.btnSalesReport.Name = "btnSalesReport";
            this.btnSalesReport.Size = new System.Drawing.Size(400, 231);
            this.btnSalesReport.TabIndex = 3;
            this.btnSalesReport.Text = "Sales Report";
            this.btnSalesReport.UseVisualStyleBackColor = true;
            this.btnSalesReport.Click += new System.EventHandler(this.btnSalesReport_Click);
            // 
            // btnCreateTrainingTests
            // 
            this.btnCreateTrainingTests.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateTrainingTests.Location = new System.Drawing.Point(269, 471);
            this.btnCreateTrainingTests.Name = "btnCreateTrainingTests";
            this.btnCreateTrainingTests.Size = new System.Drawing.Size(400, 231);
            this.btnCreateTrainingTests.TabIndex = 2;
            this.btnCreateTrainingTests.Text = "Create Training Tests";
            this.btnCreateTrainingTests.UseVisualStyleBackColor = true;
            this.btnCreateTrainingTests.Click += new System.EventHandler(this.btnCreateTrainingTests_Click);
            // 
            // btnProductManagement
            // 
            this.btnProductManagement.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProductManagement.Location = new System.Drawing.Point(876, 158);
            this.btnProductManagement.Name = "btnProductManagement";
            this.btnProductManagement.Size = new System.Drawing.Size(400, 231);
            this.btnProductManagement.TabIndex = 1;
            this.btnProductManagement.Text = "Product Management";
            this.btnProductManagement.UseVisualStyleBackColor = true;
            this.btnProductManagement.Click += new System.EventHandler(this.btnProductManagement_Click);
            // 
            // btnEmployees
            // 
            this.btnEmployees.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmployees.Location = new System.Drawing.Point(269, 158);
            this.btnEmployees.Name = "btnEmployees";
            this.btnEmployees.Size = new System.Drawing.Size(400, 231);
            this.btnEmployees.TabIndex = 0;
            this.btnEmployees.Text = "Employees";
            this.btnEmployees.UseVisualStyleBackColor = true;
            this.btnEmployees.Click += new System.EventHandler(this.btnEmployees_Click);
            // 
            // pnlEmployees
            // 
            this.pnlEmployees.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlEmployees.Controls.Add(leftHandedLabel1);
            this.pnlEmployees.Controls.Add(this.leftHandedCheckBox1);
            this.pnlEmployees.Controls.Add(colorblindLabel1);
            this.pnlEmployees.Controls.Add(this.colorblindCheckBox1);
            this.pnlEmployees.Controls.Add(this.employeesDataGridView1);
            this.pnlEmployees.Controls.Add(this.btnManageHours);
            this.pnlEmployees.Controls.Add(this.button1);
            this.pnlEmployees.Controls.Add(this.gpbEmployee);
            this.pnlEmployees.Controls.Add(this.btnQuitEmployees);
            this.pnlEmployees.Controls.Add(this.lblEmployees);
            this.pnlEmployees.Location = new System.Drawing.Point(0, 0);
            this.pnlEmployees.Name = "pnlEmployees";
            this.pnlEmployees.Size = new System.Drawing.Size(1545, 960);
            this.pnlEmployees.TabIndex = 4;
            this.pnlEmployees.Visible = false;
            this.pnlEmployees.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlEmployees_Paint);
            // 
            // pnlManageHours
            // 
            this.pnlManageHours.Location = new System.Drawing.Point(168, 417);
            this.pnlManageHours.Name = "pnlManageHours";
            this.pnlManageHours.Size = new System.Drawing.Size(1168, 393);
            this.pnlManageHours.TabIndex = 16;
            this.pnlManageHours.Visible = false;
            // 
            // btnManageHours
            // 
            this.btnManageHours.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManageHours.Location = new System.Drawing.Point(1295, 613);
            this.btnManageHours.Name = "btnManageHours";
            this.btnManageHours.Size = new System.Drawing.Size(193, 158);
            this.btnManageHours.TabIndex = 15;
            this.btnManageHours.Text = "Manage Employee Hours";
            this.btnManageHours.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1295, 417);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(193, 158);
            this.button1.TabIndex = 14;
            this.button1.Text = "GET ALL THE EMPLOYEE NAMES!";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // gpbEmployee
            // 
            this.gpbEmployee.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.gpbEmployee.Controls.Add(this.groupBox1);
            this.gpbEmployee.Controls.Add(this.txtbID);
            this.gpbEmployee.Controls.Add(this.txtbFirstName);
            this.gpbEmployee.Controls.Add(this.txtbLastName);
            this.gpbEmployee.Controls.Add(this.txtbStatus);
            this.gpbEmployee.Controls.Add(this.txtbWage);
            this.gpbEmployee.Controls.Add(this.btnAddEmployee);
            this.gpbEmployee.Controls.Add(this.btnUpdateEmployee);
            this.gpbEmployee.Controls.Add(this.btnDeleteEmployee);
            this.gpbEmployee.Controls.Add(lblWage);
            this.gpbEmployee.Controls.Add(lblStatus);
            this.gpbEmployee.Controls.Add(lblLastName);
            this.gpbEmployee.Controls.Add(lblFirstName);
            this.gpbEmployee.Controls.Add(lblEmployeeId);
            this.gpbEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpbEmployee.Location = new System.Drawing.Point(357, 405);
            this.gpbEmployee.Name = "gpbEmployee";
            this.gpbEmployee.Size = new System.Drawing.Size(830, 515);
            this.gpbEmployee.TabIndex = 12;
            this.gpbEmployee.TabStop = false;
            this.gpbEmployee.Text = "Employee Info/Update";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.groupBox1.Controls.Add(leftHandedLabel);
            this.groupBox1.Controls.Add(this.leftHandedCheckBox);
            this.groupBox1.Controls.Add(this.colorblindCheckBox);
            this.groupBox1.Controls.Add(colorblindLabel);
            this.groupBox1.Location = new System.Drawing.Point(513, 46);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(254, 258);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Special Needs";
            // 
            // leftHandedCheckBox
            // 
            this.leftHandedCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.employeesBindingSource, "LeftHanded", true));
            this.leftHandedCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.leftHandedCheckBox.Location = new System.Drawing.Point(90, 78);
            this.leftHandedCheckBox.Name = "leftHandedCheckBox";
            this.leftHandedCheckBox.Size = new System.Drawing.Size(79, 38);
            this.leftHandedCheckBox.TabIndex = 24;
            this.leftHandedCheckBox.Text = "Yes";
            this.leftHandedCheckBox.UseVisualStyleBackColor = true;
            this.leftHandedCheckBox.CheckedChanged += new System.EventHandler(this.leftHandedCheckBox_CheckedChanged);
            // 
            // colorblindCheckBox
            // 
            this.colorblindCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.employeesBindingSource, "Colorblind", true));
            this.colorblindCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colorblindCheckBox.Location = new System.Drawing.Point(90, 187);
            this.colorblindCheckBox.Name = "colorblindCheckBox";
            this.colorblindCheckBox.Size = new System.Drawing.Size(79, 36);
            this.colorblindCheckBox.TabIndex = 26;
            this.colorblindCheckBox.Text = "Yes";
            this.colorblindCheckBox.UseVisualStyleBackColor = true;
            this.colorblindCheckBox.CheckedChanged += new System.EventHandler(this.colorblindCheckBox_CheckedChanged);
            // 
            // btnAddEmployee
            // 
            this.btnAddEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddEmployee.Location = new System.Drawing.Point(59, 400);
            this.btnAddEmployee.Name = "btnAddEmployee";
            this.btnAddEmployee.Size = new System.Drawing.Size(181, 83);
            this.btnAddEmployee.TabIndex = 28;
            this.btnAddEmployee.Text = "Add Employee";
            this.btnAddEmployee.UseVisualStyleBackColor = true;
            this.btnAddEmployee.Click += new System.EventHandler(this.btnAddEmployee_Click);
            // 
            // btnUpdateEmployee
            // 
            this.btnUpdateEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateEmployee.Location = new System.Drawing.Point(542, 358);
            this.btnUpdateEmployee.Name = "btnUpdateEmployee";
            this.btnUpdateEmployee.Size = new System.Drawing.Size(209, 125);
            this.btnUpdateEmployee.TabIndex = 13;
            this.btnUpdateEmployee.Text = "Update Employees";
            this.btnUpdateEmployee.UseVisualStyleBackColor = true;
            this.btnUpdateEmployee.Click += new System.EventHandler(this.btnUpdateEmployee_Click);
            // 
            // btnDeleteEmployee
            // 
            this.btnDeleteEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteEmployee.Location = new System.Drawing.Point(278, 400);
            this.btnDeleteEmployee.Name = "btnDeleteEmployee";
            this.btnDeleteEmployee.Size = new System.Drawing.Size(181, 83);
            this.btnDeleteEmployee.TabIndex = 27;
            this.btnDeleteEmployee.Text = "Delete Employee";
            this.btnDeleteEmployee.UseVisualStyleBackColor = true;
            this.btnDeleteEmployee.Click += new System.EventHandler(this.btnDeleteEmployee_Click);
            // 
            // btnQuitEmployees
            // 
            this.btnQuitEmployees.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuitEmployees.Location = new System.Drawing.Point(1295, 834);
            this.btnQuitEmployees.Name = "btnQuitEmployees";
            this.btnQuitEmployees.Size = new System.Drawing.Size(201, 87);
            this.btnQuitEmployees.TabIndex = 11;
            this.btnQuitEmployees.Text = "Quit";
            this.btnQuitEmployees.UseVisualStyleBackColor = true;
            this.btnQuitEmployees.Click += new System.EventHandler(this.btnQuitEmployees_Click);
            // 
            // lblEmployees
            // 
            this.lblEmployees.AutoSize = true;
            this.lblEmployees.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployees.Location = new System.Drawing.Point(641, 23);
            this.lblEmployees.Name = "lblEmployees";
            this.lblEmployees.Size = new System.Drawing.Size(262, 55);
            this.lblEmployees.TabIndex = 3;
            this.lblEmployees.Text = "Employees";
            // 
            // hoursBindingSource
            // 
            this.hoursBindingSource.DataMember = "Hours";
            this.hoursBindingSource.DataSource = this.coffeeShopEmployeesDataSet1;
            // 
            // coffeeShopEmployeesDataSet1
            // 
            this.coffeeShopEmployeesDataSet1.DataSetName = "CoffeeShopEmployeesDataSet1";
            this.coffeeShopEmployeesDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pnlProductMgmt
            // 
            this.pnlProductMgmt.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlProductMgmt.Controls.Add(this.gpbxUpdateItems);
            this.pnlProductMgmt.Controls.Add(this.grpbProducts);
            this.pnlProductMgmt.Controls.Add(this.grpbRemoveItem);
            this.pnlProductMgmt.Controls.Add(this.grpbAddItem);
            this.pnlProductMgmt.Controls.Add(this.btnQuitProductMgmt);
            this.pnlProductMgmt.Controls.Add(this.lblProductManagement);
            this.pnlProductMgmt.Location = new System.Drawing.Point(0, 0);
            this.pnlProductMgmt.Name = "pnlProductMgmt";
            this.pnlProductMgmt.Size = new System.Drawing.Size(1545, 960);
            this.pnlProductMgmt.TabIndex = 11;
            this.pnlProductMgmt.Visible = false;
            this.pnlProductMgmt.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlProductMgmt_Paint);
            // 
            // gpbxUpdateItems
            // 
            this.gpbxUpdateItems.BackColor = System.Drawing.SystemColors.Info;
            this.gpbxUpdateItems.Controls.Add(this.btnUpdateItem);
            this.gpbxUpdateItems.Controls.Add(lblUpdatePrice);
            this.gpbxUpdateItems.Controls.Add(lblUpdateItemName);
            this.gpbxUpdateItems.Controls.Add(addOnOptionsLabel);
            this.gpbxUpdateItems.Controls.Add(this.iceCreamOptionsCheckBox);
            this.gpbxUpdateItems.Controls.Add(this.itemNameTextBox);
            this.gpbxUpdateItems.Controls.Add(iceCreamOptionsLabel);
            this.gpbxUpdateItems.Controls.Add(this.priceTextBox);
            this.gpbxUpdateItems.Controls.Add(this.sizeOptionsCheckBox);
            this.gpbxUpdateItems.Controls.Add(sizeOptionsLabel);
            this.gpbxUpdateItems.Controls.Add(this.addOnOptionsCheckBox);
            this.gpbxUpdateItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpbxUpdateItems.Location = new System.Drawing.Point(65, 118);
            this.gpbxUpdateItems.Name = "gpbxUpdateItems";
            this.gpbxUpdateItems.Size = new System.Drawing.Size(451, 385);
            this.gpbxUpdateItems.TabIndex = 20;
            this.gpbxUpdateItems.TabStop = false;
            this.gpbxUpdateItems.Text = "Selected Item Info";
            // 
            // btnUpdateItem
            // 
            this.btnUpdateItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateItem.Location = new System.Drawing.Point(125, 287);
            this.btnUpdateItem.Name = "btnUpdateItem";
            this.btnUpdateItem.Size = new System.Drawing.Size(199, 60);
            this.btnUpdateItem.TabIndex = 21;
            this.btnUpdateItem.Text = "Update Item";
            this.btnUpdateItem.UseVisualStyleBackColor = true;
            // 
            // iceCreamOptionsCheckBox
            // 
            this.iceCreamOptionsCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.buttonMainPanelBindingSource2, "IceCreamOptions", true));
            this.iceCreamOptionsCheckBox.Location = new System.Drawing.Point(260, 244);
            this.iceCreamOptionsCheckBox.Name = "iceCreamOptionsCheckBox";
            this.iceCreamOptionsCheckBox.Size = new System.Drawing.Size(16, 24);
            this.iceCreamOptionsCheckBox.TabIndex = 18;
            this.iceCreamOptionsCheckBox.UseVisualStyleBackColor = true;
            // 
            // buttonMainPanelBindingSource2
            // 
            this.buttonMainPanelBindingSource2.DataMember = "ButtonMainPanel";
            this.buttonMainPanelBindingSource2.DataSource = this.storedItemsDataSet;
            // 
            // storedItemsDataSet
            // 
            this.storedItemsDataSet.DataSetName = "StoredItemsDataSet";
            this.storedItemsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // itemNameTextBox
            // 
            this.itemNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.buttonMainPanelBindingSource2, "ItemName", true));
            this.itemNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemNameTextBox.Location = new System.Drawing.Point(182, 49);
            this.itemNameTextBox.Name = "itemNameTextBox";
            this.itemNameTextBox.Size = new System.Drawing.Size(246, 38);
            this.itemNameTextBox.TabIndex = 10;
            // 
            // priceTextBox
            // 
            this.priceTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.buttonMainPanelBindingSource2, "Price", true));
            this.priceTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.priceTextBox.Location = new System.Drawing.Point(182, 119);
            this.priceTextBox.Name = "priceTextBox";
            this.priceTextBox.Size = new System.Drawing.Size(246, 38);
            this.priceTextBox.TabIndex = 12;
            // 
            // sizeOptionsCheckBox
            // 
            this.sizeOptionsCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.buttonMainPanelBindingSource2, "SizeOptions", true));
            this.sizeOptionsCheckBox.Location = new System.Drawing.Point(260, 214);
            this.sizeOptionsCheckBox.Name = "sizeOptionsCheckBox";
            this.sizeOptionsCheckBox.Size = new System.Drawing.Size(16, 24);
            this.sizeOptionsCheckBox.TabIndex = 16;
            this.sizeOptionsCheckBox.UseVisualStyleBackColor = true;
            // 
            // addOnOptionsCheckBox
            // 
            this.addOnOptionsCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.buttonMainPanelBindingSource2, "AddOnOptions", true));
            this.addOnOptionsCheckBox.Location = new System.Drawing.Point(260, 184);
            this.addOnOptionsCheckBox.Name = "addOnOptionsCheckBox";
            this.addOnOptionsCheckBox.Size = new System.Drawing.Size(16, 24);
            this.addOnOptionsCheckBox.TabIndex = 14;
            this.addOnOptionsCheckBox.UseVisualStyleBackColor = true;
            // 
            // grpbProducts
            // 
            this.grpbProducts.Controls.Add(this.buttonMainPanelDataGridView);
            this.grpbProducts.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbProducts.Location = new System.Drawing.Point(587, 118);
            this.grpbProducts.Name = "grpbProducts";
            this.grpbProducts.Size = new System.Drawing.Size(858, 385);
            this.grpbProducts.TabIndex = 19;
            this.grpbProducts.TabStop = false;
            this.grpbProducts.Text = "Products";
            // 
            // buttonMainPanelDataGridView
            // 
            this.buttonMainPanelDataGridView.AutoGenerateColumns = false;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.buttonMainPanelDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.buttonMainPanelDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.buttonMainPanelDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewCheckBoxColumn6,
            this.dataGridViewCheckBoxColumn7,
            this.dataGridViewCheckBoxColumn8});
            this.buttonMainPanelDataGridView.DataSource = this.buttonMainPanelBindingSource2;
            this.buttonMainPanelDataGridView.Location = new System.Drawing.Point(20, 25);
            this.buttonMainPanelDataGridView.Name = "buttonMainPanelDataGridView";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.buttonMainPanelDataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle16;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMainPanelDataGridView.RowsDefaultCellStyle = dataGridViewCellStyle17;
            this.buttonMainPanelDataGridView.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMainPanelDataGridView.RowTemplate.Height = 28;
            this.buttonMainPanelDataGridView.Size = new System.Drawing.Size(814, 346);
            this.buttonMainPanelDataGridView.TabIndex = 18;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "ItemName";
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.PaleGoldenrod;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn8.DefaultCellStyle = dataGridViewCellStyle11;
            this.dataGridViewTextBoxColumn8.DividerWidth = 1;
            this.dataGridViewTextBoxColumn8.HeaderText = "Item Name";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn8.Width = 200;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Price";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.PaleGoldenrod;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.Format = "C2";
            dataGridViewCellStyle12.NullValue = null;
            this.dataGridViewTextBoxColumn9.DefaultCellStyle = dataGridViewCellStyle12;
            this.dataGridViewTextBoxColumn9.DividerWidth = 2;
            this.dataGridViewTextBoxColumn9.HeaderText = "Price";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn9.Width = 150;
            // 
            // dataGridViewCheckBoxColumn6
            // 
            this.dataGridViewCheckBoxColumn6.DataPropertyName = "AddOnOptions";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.NullValue = false;
            this.dataGridViewCheckBoxColumn6.DefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewCheckBoxColumn6.DividerWidth = 2;
            this.dataGridViewCheckBoxColumn6.HeaderText = "Add Ons";
            this.dataGridViewCheckBoxColumn6.Name = "dataGridViewCheckBoxColumn6";
            this.dataGridViewCheckBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewCheckBoxColumn6.Width = 140;
            // 
            // dataGridViewCheckBoxColumn7
            // 
            this.dataGridViewCheckBoxColumn7.DataPropertyName = "SizeOptions";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.NullValue = false;
            this.dataGridViewCheckBoxColumn7.DefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridViewCheckBoxColumn7.DividerWidth = 2;
            this.dataGridViewCheckBoxColumn7.HeaderText = "Sizes";
            this.dataGridViewCheckBoxColumn7.Name = "dataGridViewCheckBoxColumn7";
            this.dataGridViewCheckBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewCheckBoxColumn7.Width = 120;
            // 
            // dataGridViewCheckBoxColumn8
            // 
            this.dataGridViewCheckBoxColumn8.DataPropertyName = "IceCreamOptions";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.NullValue = false;
            this.dataGridViewCheckBoxColumn8.DefaultCellStyle = dataGridViewCellStyle15;
            this.dataGridViewCheckBoxColumn8.HeaderText = "Ice Cream";
            this.dataGridViewCheckBoxColumn8.Name = "dataGridViewCheckBoxColumn8";
            this.dataGridViewCheckBoxColumn8.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewCheckBoxColumn8.Width = 140;
            // 
            // grpbRemoveItem
            // 
            this.grpbRemoveItem.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.grpbRemoveItem.Controls.Add(this.btnDeleteItem);
            this.grpbRemoveItem.Controls.Add(this.txtbItemToDelete);
            this.grpbRemoveItem.Controls.Add(this.lblItemToRemove);
            this.grpbRemoveItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbRemoveItem.Location = new System.Drawing.Point(962, 521);
            this.grpbRemoveItem.Name = "grpbRemoveItem";
            this.grpbRemoveItem.Size = new System.Drawing.Size(483, 285);
            this.grpbRemoveItem.TabIndex = 9;
            this.grpbRemoveItem.TabStop = false;
            this.grpbRemoveItem.Text = "Remove Item";
            // 
            // btnDeleteItem
            // 
            this.btnDeleteItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteItem.Location = new System.Drawing.Point(151, 180);
            this.btnDeleteItem.Name = "btnDeleteItem";
            this.btnDeleteItem.Size = new System.Drawing.Size(199, 60);
            this.btnDeleteItem.TabIndex = 2;
            this.btnDeleteItem.Text = "Delete Item";
            this.btnDeleteItem.UseVisualStyleBackColor = true;
            this.btnDeleteItem.Click += new System.EventHandler(this.btnDeleteItem_Click);
            // 
            // txtbItemToDelete
            // 
            this.txtbItemToDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbItemToDelete.Location = new System.Drawing.Point(100, 119);
            this.txtbItemToDelete.Name = "txtbItemToDelete";
            this.txtbItemToDelete.Size = new System.Drawing.Size(289, 38);
            this.txtbItemToDelete.TabIndex = 1;
            // 
            // lblItemToRemove
            // 
            this.lblItemToRemove.AutoSize = true;
            this.lblItemToRemove.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemToRemove.Location = new System.Drawing.Point(105, 47);
            this.lblItemToRemove.Name = "lblItemToRemove";
            this.lblItemToRemove.Size = new System.Drawing.Size(284, 31);
            this.lblItemToRemove.TabIndex = 0;
            this.lblItemToRemove.Text = "Name Item to Remove";
            // 
            // grpbAddItem
            // 
            this.grpbAddItem.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.grpbAddItem.Controls.Add(this.btnAddImage);
            this.grpbAddItem.Controls.Add(this.gpbxSelectedImage);
            this.grpbAddItem.Controls.Add(this.lblSubMenus);
            this.grpbAddItem.Controls.Add(this.comboBox1);
            this.grpbAddItem.Controls.Add(this.btnAddItem);
            this.grpbAddItem.Controls.Add(this.lblItemPrice);
            this.grpbAddItem.Controls.Add(this.txtbItemPrice);
            this.grpbAddItem.Controls.Add(this.lblItemName);
            this.grpbAddItem.Controls.Add(this.txtbItemName);
            this.grpbAddItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbAddItem.Location = new System.Drawing.Point(65, 548);
            this.grpbAddItem.Name = "grpbAddItem";
            this.grpbAddItem.Size = new System.Drawing.Size(838, 364);
            this.grpbAddItem.TabIndex = 8;
            this.grpbAddItem.TabStop = false;
            this.grpbAddItem.Text = "Add New Item";
            // 
            // lblSubMenus
            // 
            this.lblSubMenus.AutoSize = true;
            this.lblSubMenus.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubMenus.Location = new System.Drawing.Point(37, 189);
            this.lblSubMenus.Name = "lblSubMenus";
            this.lblSubMenus.Size = new System.Drawing.Size(150, 31);
            this.lblSubMenus.TabIndex = 16;
            this.lblSubMenus.Text = "Sub Menus";
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Add-On Options",
            "Size Options",
            "Ice Cream Options"});
            this.comboBox1.Location = new System.Drawing.Point(210, 185);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(258, 39);
            this.comboBox1.TabIndex = 15;
            // 
            // btnAddItem
            // 
            this.btnAddItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddItem.Location = new System.Drawing.Point(229, 268);
            this.btnAddItem.Name = "btnAddItem";
            this.btnAddItem.Size = new System.Drawing.Size(199, 60);
            this.btnAddItem.TabIndex = 14;
            this.btnAddItem.Text = "Add Item";
            this.btnAddItem.UseVisualStyleBackColor = true;
            this.btnAddItem.Click += new System.EventHandler(this.btnAddItem_Click);
            // 
            // lblItemPrice
            // 
            this.lblItemPrice.AutoSize = true;
            this.lblItemPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemPrice.Location = new System.Drawing.Point(37, 123);
            this.lblItemPrice.Name = "lblItemPrice";
            this.lblItemPrice.Size = new System.Drawing.Size(76, 31);
            this.lblItemPrice.TabIndex = 8;
            this.lblItemPrice.Text = "Price";
            // 
            // txtbItemPrice
            // 
            this.txtbItemPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbItemPrice.Location = new System.Drawing.Point(209, 121);
            this.txtbItemPrice.Name = "txtbItemPrice";
            this.txtbItemPrice.Size = new System.Drawing.Size(258, 38);
            this.txtbItemPrice.TabIndex = 9;
            // 
            // lblItemName
            // 
            this.lblItemName.AutoSize = true;
            this.lblItemName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemName.Location = new System.Drawing.Point(37, 54);
            this.lblItemName.Name = "lblItemName";
            this.lblItemName.Size = new System.Drawing.Size(146, 31);
            this.lblItemName.TabIndex = 6;
            this.lblItemName.Text = "Item Name";
            // 
            // txtbItemName
            // 
            this.txtbItemName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbItemName.Location = new System.Drawing.Point(209, 51);
            this.txtbItemName.Name = "txtbItemName";
            this.txtbItemName.Size = new System.Drawing.Size(258, 38);
            this.txtbItemName.TabIndex = 7;
            this.txtbItemName.TextChanged += new System.EventHandler(this.txtbItemName_TextChanged);
            // 
            // btnQuitProductMgmt
            // 
            this.btnQuitProductMgmt.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuitProductMgmt.Location = new System.Drawing.Point(1244, 846);
            this.btnQuitProductMgmt.Name = "btnQuitProductMgmt";
            this.btnQuitProductMgmt.Size = new System.Drawing.Size(201, 87);
            this.btnQuitProductMgmt.TabIndex = 5;
            this.btnQuitProductMgmt.Text = "Quit";
            this.btnQuitProductMgmt.UseVisualStyleBackColor = true;
            this.btnQuitProductMgmt.Click += new System.EventHandler(this.btnQuitProductMgmt_Click);
            // 
            // lblProductManagement
            // 
            this.lblProductManagement.AutoSize = true;
            this.lblProductManagement.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductManagement.Location = new System.Drawing.Point(530, 23);
            this.lblProductManagement.Name = "lblProductManagement";
            this.lblProductManagement.Size = new System.Drawing.Size(485, 55);
            this.lblProductManagement.TabIndex = 3;
            this.lblProductManagement.Text = "Product Management";
            // 
            // pnlConfirmDeletion
            // 
            this.pnlConfirmDeletion.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pnlConfirmDeletion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlConfirmDeletion.Controls.Add(this.lblConfirmDeletionWarning);
            this.pnlConfirmDeletion.Controls.Add(this.btnCancelDeleteItem);
            this.pnlConfirmDeletion.Controls.Add(this.lblDeleteWarningInfo);
            this.pnlConfirmDeletion.Controls.Add(this.btnDelete);
            this.pnlConfirmDeletion.Controls.Add(this.lblConfirmDeletion);
            this.pnlConfirmDeletion.Location = new System.Drawing.Point(635, 217);
            this.pnlConfirmDeletion.Name = "pnlConfirmDeletion";
            this.pnlConfirmDeletion.Size = new System.Drawing.Size(540, 309);
            this.pnlConfirmDeletion.TabIndex = 10;
            this.pnlConfirmDeletion.Visible = false;
            // 
            // lblConfirmDeletionWarning
            // 
            this.lblConfirmDeletionWarning.AutoSize = true;
            this.lblConfirmDeletionWarning.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConfirmDeletionWarning.ForeColor = System.Drawing.Color.Red;
            this.lblConfirmDeletionWarning.Location = new System.Drawing.Point(161, 74);
            this.lblConfirmDeletionWarning.Name = "lblConfirmDeletionWarning";
            this.lblConfirmDeletionWarning.Size = new System.Drawing.Size(216, 33);
            this.lblConfirmDeletionWarning.TabIndex = 4;
            this.lblConfirmDeletionWarning.Text = "!!!WARNING!!!";
            // 
            // btnCancelDeleteItem
            // 
            this.btnCancelDeleteItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelDeleteItem.Location = new System.Drawing.Point(277, 211);
            this.btnCancelDeleteItem.Name = "btnCancelDeleteItem";
            this.btnCancelDeleteItem.Size = new System.Drawing.Size(136, 54);
            this.btnCancelDeleteItem.TabIndex = 3;
            this.btnCancelDeleteItem.Text = "Cancel";
            this.btnCancelDeleteItem.UseVisualStyleBackColor = true;
            this.btnCancelDeleteItem.Click += new System.EventHandler(this.btnCancelDeleteItem_Click);
            // 
            // lblDeleteWarningInfo
            // 
            this.lblDeleteWarningInfo.AutoSize = true;
            this.lblDeleteWarningInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDeleteWarningInfo.Location = new System.Drawing.Point(63, 126);
            this.lblDeleteWarningInfo.Name = "lblDeleteWarningInfo";
            this.lblDeleteWarningInfo.Size = new System.Drawing.Size(409, 58);
            this.lblDeleteWarningInfo.TabIndex = 2;
            this.lblDeleteWarningInfo.Text = "All data will be permanently erased. *\r\nClick \'Delete\' to continue :";
            this.lblDeleteWarningInfo.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(123, 211);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(136, 54);
            this.btnDelete.TabIndex = 1;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // lblConfirmDeletion
            // 
            this.lblConfirmDeletion.AutoSize = true;
            this.lblConfirmDeletion.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConfirmDeletion.Location = new System.Drawing.Point(121, 25);
            this.lblConfirmDeletion.Name = "lblConfirmDeletion";
            this.lblConfirmDeletion.Size = new System.Drawing.Size(297, 37);
            this.lblConfirmDeletion.TabIndex = 0;
            this.lblConfirmDeletion.Text = "* Confirm Deletion *";
            // 
            // pnlCreateTest
            // 
            this.pnlCreateTest.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCreateTest.Controls.Add(this.btnCreateNewTest);
            this.pnlCreateTest.Controls.Add(this.txtbNewTestName);
            this.pnlCreateTest.Controls.Add(this.lblNewTestName);
            this.pnlCreateTest.Controls.Add(this.btnQuitCreateTest);
            this.pnlCreateTest.Controls.Add(this.lblCreatePracticeTest);
            this.pnlCreateTest.Location = new System.Drawing.Point(0, 0);
            this.pnlCreateTest.Name = "pnlCreateTest";
            this.pnlCreateTest.Size = new System.Drawing.Size(1545, 960);
            this.pnlCreateTest.TabIndex = 5;
            this.pnlCreateTest.Visible = false;
            // 
            // btnCreateNewTest
            // 
            this.btnCreateNewTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateNewTest.Location = new System.Drawing.Point(655, 429);
            this.btnCreateNewTest.Name = "btnCreateNewTest";
            this.btnCreateNewTest.Size = new System.Drawing.Size(271, 127);
            this.btnCreateNewTest.TabIndex = 4;
            this.btnCreateNewTest.Text = "Create Test";
            this.btnCreateNewTest.UseVisualStyleBackColor = true;
            this.btnCreateNewTest.Click += new System.EventHandler(this.btnCreateNewTest_Click);
            // 
            // txtbNewTestName
            // 
            this.txtbNewTestName.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbNewTestName.Location = new System.Drawing.Point(723, 260);
            this.txtbNewTestName.Name = "txtbNewTestName";
            this.txtbNewTestName.Size = new System.Drawing.Size(367, 40);
            this.txtbNewTestName.TabIndex = 3;
            // 
            // lblNewTestName
            // 
            this.lblNewTestName.AutoSize = true;
            this.lblNewTestName.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewTestName.Location = new System.Drawing.Point(455, 263);
            this.lblNewTestName.Name = "lblNewTestName";
            this.lblNewTestName.Size = new System.Drawing.Size(224, 33);
            this.lblNewTestName.TabIndex = 2;
            this.lblNewTestName.Text = "New Test Name";
            this.lblNewTestName.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnQuitCreateTest
            // 
            this.btnQuitCreateTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuitCreateTest.Location = new System.Drawing.Point(1295, 834);
            this.btnQuitCreateTest.Name = "btnQuitCreateTest";
            this.btnQuitCreateTest.Size = new System.Drawing.Size(201, 87);
            this.btnQuitCreateTest.TabIndex = 1;
            this.btnQuitCreateTest.Text = "Quit";
            this.btnQuitCreateTest.UseVisualStyleBackColor = true;
            this.btnQuitCreateTest.Click += new System.EventHandler(this.btnQuitCreateTest_Click);
            // 
            // lblCreatePracticeTest
            // 
            this.lblCreatePracticeTest.AutoSize = true;
            this.lblCreatePracticeTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCreatePracticeTest.Location = new System.Drawing.Point(530, 42);
            this.lblCreatePracticeTest.Name = "lblCreatePracticeTest";
            this.lblCreatePracticeTest.Size = new System.Drawing.Size(485, 55);
            this.lblCreatePracticeTest.TabIndex = 0;
            this.lblCreatePracticeTest.Text = "Create Practice Tests";
            // 
            // pnlSalesReport
            // 
            this.pnlSalesReport.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlSalesReport.Controls.Add(this.rtxtbSalesReport);
            this.pnlSalesReport.Controls.Add(this.lblSalesReport);
            this.pnlSalesReport.Controls.Add(this.btnQuitSalesReport);
            this.pnlSalesReport.Location = new System.Drawing.Point(0, 0);
            this.pnlSalesReport.Name = "pnlSalesReport";
            this.pnlSalesReport.Size = new System.Drawing.Size(1545, 960);
            this.pnlSalesReport.TabIndex = 5;
            this.pnlSalesReport.Visible = false;
            // 
            // rtxtbSalesReport
            // 
            this.rtxtbSalesReport.Location = new System.Drawing.Point(314, 134);
            this.rtxtbSalesReport.Name = "rtxtbSalesReport";
            this.rtxtbSalesReport.Size = new System.Drawing.Size(916, 688);
            this.rtxtbSalesReport.TabIndex = 2;
            this.rtxtbSalesReport.Text = "";
            // 
            // lblSalesReport
            // 
            this.lblSalesReport.AutoSize = true;
            this.lblSalesReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalesReport.Location = new System.Drawing.Point(621, 23);
            this.lblSalesReport.Name = "lblSalesReport";
            this.lblSalesReport.Size = new System.Drawing.Size(302, 55);
            this.lblSalesReport.TabIndex = 1;
            this.lblSalesReport.Text = "Sales Report";
            // 
            // btnQuitSalesReport
            // 
            this.btnQuitSalesReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuitSalesReport.Location = new System.Drawing.Point(1319, 834);
            this.btnQuitSalesReport.Name = "btnQuitSalesReport";
            this.btnQuitSalesReport.Size = new System.Drawing.Size(201, 87);
            this.btnQuitSalesReport.TabIndex = 0;
            this.btnQuitSalesReport.Text = "Quit";
            this.btnQuitSalesReport.UseVisualStyleBackColor = true;
            this.btnQuitSalesReport.Click += new System.EventHandler(this.btnQuitSalesReport_Click);
            // 
            // employeesBindingNavigator
            // 
            this.employeesBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.employeesBindingNavigator.BindingSource = this.employeesBindingSource;
            this.employeesBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.employeesBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.employeesBindingNavigator.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.employeesBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.employeesBindingNavigatorSaveItem});
            this.employeesBindingNavigator.Location = new System.Drawing.Point(0, 960);
            this.employeesBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.employeesBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.employeesBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.employeesBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.employeesBindingNavigator.Name = "employeesBindingNavigator";
            this.employeesBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.employeesBindingNavigator.Size = new System.Drawing.Size(1547, 25);
            this.employeesBindingNavigator.TabIndex = 12;
            this.employeesBindingNavigator.Text = "bindingNavigator1";
            this.employeesBindingNavigator.Visible = false;
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            this.bindingNavigatorAddNewItem.Click += new System.EventHandler(this.bindingNavigatorAddNewItem_Click);
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            this.bindingNavigatorDeleteItem.Click += new System.EventHandler(this.bindingNavigatorDeleteItem_Click);
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // employeesBindingNavigatorSaveItem
            // 
            this.employeesBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.employeesBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("employeesBindingNavigatorSaveItem.Image")));
            this.employeesBindingNavigatorSaveItem.Name = "employeesBindingNavigatorSaveItem";
            this.employeesBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.employeesBindingNavigatorSaveItem.Text = "Save Data";
            this.employeesBindingNavigatorSaveItem.Click += new System.EventHandler(this.employeesBindingNavigatorSaveItem_Click);
            // 
            // buttonMainPanelTableAdapter
            // 
            this.buttonMainPanelTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.AddOnsTableAdapter = null;
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.ButtonMainPanelTableAdapter = this.buttonMainPanelTableAdapter;
            this.tableAdapterManager1.IceCreamFlavorsPanelTableAdapter = null;
            this.tableAdapterManager1.SizeOptionsPanelTableAdapter = null;
            this.tableAdapterManager1.UpdateOrder = EAPOS_Project.StoredItemsDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // hoursTableAdapter
            // 
            this.hoursTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager2
            // 
            this.tableAdapterManager2.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager2.EmployeesTableAdapter = null;
            this.tableAdapterManager2.HoursTableAdapter = this.hoursTableAdapter;
            this.tableAdapterManager2.UpdateOrder = EAPOS_Project.CoffeeShopEmployeesDataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // gpbxSelectedImage
            // 
            this.gpbxSelectedImage.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.gpbxSelectedImage.Controls.Add(this.pictureBoxSelectedImage);
            this.gpbxSelectedImage.Location = new System.Drawing.Point(559, 51);
            this.gpbxSelectedImage.Name = "gpbxSelectedImage";
            this.gpbxSelectedImage.Size = new System.Drawing.Size(229, 183);
            this.gpbxSelectedImage.TabIndex = 19;
            this.gpbxSelectedImage.TabStop = false;
            this.gpbxSelectedImage.Text = "Selected Image";
            // 
            // pictureBoxSelectedImage
            // 
            this.pictureBoxSelectedImage.Location = new System.Drawing.Point(15, 29);
            this.pictureBoxSelectedImage.Name = "pictureBoxSelectedImage";
            this.pictureBoxSelectedImage.Size = new System.Drawing.Size(199, 138);
            this.pictureBoxSelectedImage.TabIndex = 0;
            this.pictureBoxSelectedImage.TabStop = false;
            // 
            // btnAddImage
            // 
            this.btnAddImage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddImage.Location = new System.Drawing.Point(613, 257);
            this.btnAddImage.Name = "btnAddImage";
            this.btnAddImage.Size = new System.Drawing.Size(121, 44);
            this.btnAddImage.TabIndex = 20;
            this.btnAddImage.Text = "Add Image";
            this.btnAddImage.UseVisualStyleBackColor = true;
            // 
            // employeesBindingSource1
            // 
            this.employeesBindingSource1.DataMember = "Employees";
            this.employeesBindingSource1.DataSource = this.coffeeShopEmployeesDataSet1;
            // 
            // employeesTableAdapter1
            // 
            this.employeesTableAdapter1.ClearBeforeFill = true;
            // 
            // employeesBindingSource
            // 
            this.employeesBindingSource.DataMember = "Employees";
            this.employeesBindingSource.DataSource = this.coffeeShopEmployeesDataSet;
            // 
            // coffeeShopEmployeesDataSet
            // 
            this.coffeeShopEmployeesDataSet.DataSetName = "CoffeeShopEmployeesDataSet";
            this.coffeeShopEmployeesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // employeesTableAdapter
            // 
            this.employeesTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.EmployeesTableAdapter = this.employeesTableAdapter;
            this.tableAdapterManager.UpdateOrder = EAPOS_Project.CoffeeShopEmployeesDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // employeesDataGridView1
            // 
            this.employeesDataGridView1.AutoGenerateColumns = false;
            this.employeesDataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.employeesDataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.employeesDataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.employeesDataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewCheckBoxColumn9,
            this.dataGridViewCheckBoxColumn10});
            this.employeesDataGridView1.DataSource = this.employeesBindingSource1;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.employeesDataGridView1.DefaultCellStyle = dataGridViewCellStyle9;
            this.employeesDataGridView1.Location = new System.Drawing.Point(203, 100);
            this.employeesDataGridView1.Name = "employeesDataGridView1";
            this.employeesDataGridView1.RowTemplate.Height = 32;
            this.employeesDataGridView1.Size = new System.Drawing.Size(1133, 220);
            this.employeesDataGridView1.TabIndex = 16;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "ID";
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn10.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewTextBoxColumn10.HeaderText = "ID";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn10.Width = 80;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Fname";
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn11.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewTextBoxColumn11.HeaderText = "First Name";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn11.Width = 200;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Lname";
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn12.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewTextBoxColumn12.HeaderText = "Last Name";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn12.Width = 220;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "Status";
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn13.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewTextBoxColumn13.HeaderText = "Status";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn13.Width = 180;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "Wage";
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn14.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewTextBoxColumn14.HeaderText = "Wage";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn14.Width = 130;
            // 
            // dataGridViewCheckBoxColumn9
            // 
            this.dataGridViewCheckBoxColumn9.DataPropertyName = "LeftHanded";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.NullValue = false;
            this.dataGridViewCheckBoxColumn9.DefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewCheckBoxColumn9.HeaderText = "Left-Handed";
            this.dataGridViewCheckBoxColumn9.Name = "dataGridViewCheckBoxColumn9";
            this.dataGridViewCheckBoxColumn9.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewCheckBoxColumn9.Width = 150;
            // 
            // dataGridViewCheckBoxColumn10
            // 
            this.dataGridViewCheckBoxColumn10.DataPropertyName = "Colorblind";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.NullValue = false;
            this.dataGridViewCheckBoxColumn10.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridViewCheckBoxColumn10.HeaderText = "Colorblind";
            this.dataGridViewCheckBoxColumn10.Name = "dataGridViewCheckBoxColumn10";
            this.dataGridViewCheckBoxColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewCheckBoxColumn10.Width = 130;
            // 
            // txtbID
            // 
            this.txtbID.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource1, "ID", true));
            this.txtbID.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbID.Location = new System.Drawing.Point(218, 46);
            this.txtbID.Name = "txtbID";
            this.txtbID.Size = new System.Drawing.Size(104, 38);
            this.txtbID.TabIndex = 17;
            // 
            // txtbFirstName
            // 
            this.txtbFirstName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource1, "Fname", true));
            this.txtbFirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbFirstName.Location = new System.Drawing.Point(218, 113);
            this.txtbFirstName.Name = "txtbFirstName";
            this.txtbFirstName.Size = new System.Drawing.Size(214, 38);
            this.txtbFirstName.TabIndex = 19;
            // 
            // txtbLastName
            // 
            this.txtbLastName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource1, "Lname", true));
            this.txtbLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbLastName.Location = new System.Drawing.Point(218, 179);
            this.txtbLastName.Name = "txtbLastName";
            this.txtbLastName.Size = new System.Drawing.Size(214, 38);
            this.txtbLastName.TabIndex = 21;
            // 
            // txtbStatus
            // 
            this.txtbStatus.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource1, "Status", true));
            this.txtbStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbStatus.Location = new System.Drawing.Point(218, 253);
            this.txtbStatus.Name = "txtbStatus";
            this.txtbStatus.Size = new System.Drawing.Size(214, 38);
            this.txtbStatus.TabIndex = 23;
            // 
            // txtbWage
            // 
            this.txtbWage.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource1, "Wage", true));
            this.txtbWage.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbWage.Location = new System.Drawing.Point(218, 328);
            this.txtbWage.Name = "txtbWage";
            this.txtbWage.Size = new System.Drawing.Size(214, 38);
            this.txtbWage.TabIndex = 25;
            // 
            // leftHandedLabel1
            // 
            leftHandedLabel1.AutoSize = true;
            leftHandedLabel1.Location = new System.Drawing.Point(71, 500);
            leftHandedLabel1.Name = "leftHandedLabel1";
            leftHandedLabel1.Size = new System.Drawing.Size(69, 13);
            leftHandedLabel1.TabIndex = 26;
            leftHandedLabel1.Text = "Left Handed:";
            // 
            // leftHandedCheckBox1
            // 
            this.leftHandedCheckBox1.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.employeesBindingSource1, "LeftHanded", true));
            this.leftHandedCheckBox1.Location = new System.Drawing.Point(146, 495);
            this.leftHandedCheckBox1.Name = "leftHandedCheckBox1";
            this.leftHandedCheckBox1.Size = new System.Drawing.Size(104, 24);
            this.leftHandedCheckBox1.TabIndex = 27;
            this.leftHandedCheckBox1.Text = "checkBox1";
            this.leftHandedCheckBox1.UseVisualStyleBackColor = true;
            // 
            // colorblindLabel1
            // 
            colorblindLabel1.AutoSize = true;
            colorblindLabel1.Location = new System.Drawing.Point(71, 530);
            colorblindLabel1.Name = "colorblindLabel1";
            colorblindLabel1.Size = new System.Drawing.Size(56, 13);
            colorblindLabel1.TabIndex = 28;
            colorblindLabel1.Text = "Colorblind:";
            // 
            // colorblindCheckBox1
            // 
            this.colorblindCheckBox1.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.employeesBindingSource1, "Colorblind", true));
            this.colorblindCheckBox1.Location = new System.Drawing.Point(146, 525);
            this.colorblindCheckBox1.Name = "colorblindCheckBox1";
            this.colorblindCheckBox1.Size = new System.Drawing.Size(104, 24);
            this.colorblindCheckBox1.TabIndex = 29;
            this.colorblindCheckBox1.Text = "checkBox1";
            this.colorblindCheckBox1.UseVisualStyleBackColor = true;
            // 
            // frmManagerMode
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1547, 985);
            this.Controls.Add(this.pnlEmployees);
            this.Controls.Add(this.pnlManageHours);
            this.Controls.Add(this.pnlProductMgmt);
            this.Controls.Add(this.pnlCreateTest);
            this.Controls.Add(this.pnlSalesReport);
            this.Controls.Add(this.pnlManagerMode);
            this.Controls.Add(this.pnlConfirmDeletion);
            this.Controls.Add(this.employeesBindingNavigator);
            this.Name = "frmManagerMode";
            this.Text = "Manager Mode";
            this.Load += new System.EventHandler(this.frmManagerMode_Load_1);
            this.pnlManagerMode.ResumeLayout(false);
            this.pnlManagerMode.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlEmployees.ResumeLayout(false);
            this.pnlEmployees.PerformLayout();
            this.gpbEmployee.ResumeLayout(false);
            this.gpbEmployee.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hoursBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coffeeShopEmployeesDataSet1)).EndInit();
            this.pnlProductMgmt.ResumeLayout(false);
            this.pnlProductMgmt.PerformLayout();
            this.gpbxUpdateItems.ResumeLayout(false);
            this.gpbxUpdateItems.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.buttonMainPanelBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.storedItemsDataSet)).EndInit();
            this.grpbProducts.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.buttonMainPanelDataGridView)).EndInit();
            this.grpbRemoveItem.ResumeLayout(false);
            this.grpbRemoveItem.PerformLayout();
            this.grpbAddItem.ResumeLayout(false);
            this.grpbAddItem.PerformLayout();
            this.pnlConfirmDeletion.ResumeLayout(false);
            this.pnlConfirmDeletion.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.buttonMainPanelBindingSource1)).EndInit();
            this.pnlCreateTest.ResumeLayout(false);
            this.pnlCreateTest.PerformLayout();
            this.pnlSalesReport.ResumeLayout(false);
            this.pnlSalesReport.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingNavigator)).EndInit();
            this.employeesBindingNavigator.ResumeLayout(false);
            this.employeesBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.buttonMainPanelBindingSource)).EndInit();
            this.gpbxSelectedImage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSelectedImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coffeeShopEmployeesDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeesDataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Panel pnlManagerMode;
        public System.Windows.Forms.Button btnOrderMode;
        public System.Windows.Forms.Button btnSalesReport;
        public System.Windows.Forms.Button btnCreateTrainingTests;
        public System.Windows.Forms.Button btnProductManagement;
        public System.Windows.Forms.Button btnEmployees;
        public System.Windows.Forms.Panel pnlEmployees;
        public System.Windows.Forms.Label lblEmployees;
        public System.Windows.Forms.Label lblManagerMode;
        public System.Windows.Forms.Panel pnlProductMgmt;
        public System.Windows.Forms.Label lblProductManagement;
        public System.Windows.Forms.Button btnQuitProductMgmt;
        public System.Windows.Forms.Button btnQuitEmployees;
        public System.Windows.Forms.Button btnUpdateEmployee;
        public System.Windows.Forms.GroupBox gpbEmployee;
        public System.Windows.Forms.GroupBox grpbAddItem;
        public System.Windows.Forms.Label lblItemName;
        public System.Windows.Forms.Panel pnlConfirmDeletion;
        public System.Windows.Forms.Label lblDeleteWarningInfo;
        public System.Windows.Forms.Button btnDelete;
        public System.Windows.Forms.Label lblConfirmDeletion;
        public System.Windows.Forms.GroupBox grpbRemoveItem;
        public System.Windows.Forms.Button btnDeleteItem;
        public System.Windows.Forms.TextBox txtbItemToDelete;
        public System.Windows.Forms.Label lblItemToRemove;
        public System.Windows.Forms.Label lblItemPrice;
        public System.Windows.Forms.Panel pnlCreateTest;
        public System.Windows.Forms.Button btnQuitCreateTest;
        public System.Windows.Forms.Label lblCreatePracticeTest;
        public System.Windows.Forms.Panel pnlSalesReport;
        public System.Windows.Forms.Button btnQuitSalesReport;
        public System.Windows.Forms.Label lblSalesReport;
        public System.Windows.Forms.Button btnCreateNewTest;
        public System.Windows.Forms.TextBox txtbNewTestName;
        public System.Windows.Forms.Label lblNewTestName;
        public System.Windows.Forms.Button btnAddItem;
        public System.Windows.Forms.RichTextBox rtxtbSalesReport;
        public CoffeeShopEmployeesDataSet coffeeShopEmployeesDataSet;
        public System.Windows.Forms.BindingSource employeesBindingSource;
        public CoffeeShopEmployeesDataSetTableAdapters.EmployeesTableAdapter employeesTableAdapter;
        public CoffeeShopEmployeesDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        public System.Windows.Forms.BindingNavigator employeesBindingNavigator;
        public System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        public System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        public System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        public System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        public System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        public System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        public System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        public System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        public System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        public System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        public System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        public System.Windows.Forms.ToolStripButton employeesBindingNavigatorSaveItem;
        public System.Windows.Forms.Button btnSignOutManagerMode;
        public System.Windows.Forms.CheckBox colorblindCheckBox;
        public System.Windows.Forms.Button btnDeleteEmployee;
        public System.Windows.Forms.CheckBox leftHandedCheckBox;
        public System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.Button btnAddEmployee;
        public System.Windows.Forms.PictureBox pictureBox1;
        private System.ComponentModel.IContainer components;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.BindingSource buttonMainPanelBindingSource;
        private System.Windows.Forms.BindingSource buttonMainPanelBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn3;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn4;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn5;
        private StoredItemsDataSet storedItemsDataSet;
        private System.Windows.Forms.BindingSource buttonMainPanelBindingSource2;
        private StoredItemsDataSetTableAdapters.ButtonMainPanelTableAdapter buttonMainPanelTableAdapter;
        private StoredItemsDataSetTableAdapters.TableAdapterManager tableAdapterManager1;
        private System.Windows.Forms.TextBox itemNameTextBox;
        private System.Windows.Forms.TextBox priceTextBox;
        private System.Windows.Forms.CheckBox addOnOptionsCheckBox;
        private System.Windows.Forms.CheckBox sizeOptionsCheckBox;
        private System.Windows.Forms.CheckBox iceCreamOptionsCheckBox;
        private System.Windows.Forms.DataGridView buttonMainPanelDataGridView;
        private System.Windows.Forms.Label lblConfirmDeletionWarning;
        private System.Windows.Forms.Button btnCancelDeleteItem;
        private System.Windows.Forms.ComboBox comboBox1;
        public System.Windows.Forms.TextBox txtbItemPrice;
        public System.Windows.Forms.TextBox txtbItemName;
        private System.Windows.Forms.GroupBox grpbProducts;
        private System.Windows.Forms.GroupBox gpbxUpdateItems;
        public System.Windows.Forms.Button btnUpdateItem;
        public System.Windows.Forms.Label lblSubMenus;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn6;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn7;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn8;
        private System.Windows.Forms.Button btnManageHours;
        private System.Windows.Forms.Panel pnlManageHours;
        private CoffeeShopEmployeesDataSet1 coffeeShopEmployeesDataSet1;
        private System.Windows.Forms.BindingSource hoursBindingSource;
        private CoffeeShopEmployeesDataSet1TableAdapters.HoursTableAdapter hoursTableAdapter;
        private CoffeeShopEmployeesDataSet1TableAdapters.TableAdapterManager tableAdapterManager2;
        private System.Windows.Forms.Button btnAddImage;
        private System.Windows.Forms.GroupBox gpbxSelectedImage;
        private System.Windows.Forms.PictureBox pictureBoxSelectedImage;
        private System.Windows.Forms.BindingSource employeesBindingSource1;
        private CoffeeShopEmployeesDataSet1TableAdapters.EmployeesTableAdapter employeesTableAdapter1;
        private System.Windows.Forms.DataGridView employeesDataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn9;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn10;
        private System.Windows.Forms.TextBox txtbID;
        private System.Windows.Forms.TextBox txtbFirstName;
        private System.Windows.Forms.TextBox txtbLastName;
        private System.Windows.Forms.TextBox txtbStatus;
        private System.Windows.Forms.TextBox txtbWage;
        private System.Windows.Forms.CheckBox leftHandedCheckBox1;
        private System.Windows.Forms.CheckBox colorblindCheckBox1;
    }
}

