﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EAPOS_Project;
using Ordering;
using WindowsFormsApplication1;

namespace SignIn
{
    public partial class frmSignIn : Form
    {

        public frmSignIn()
        {
            InitializeComponent();
        }

        public bool checkLength()
        {
            if (lblPassword.Text.Length <= 3)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void logIn()
        {
            lblPassword.ResetText();
            pnlSignInScreen.Visible = false;
            pnlChooseScreen.Visible = true;
        }

        public void updatelblPassword(string num)
        {
            if (checkLength() == true)
            {
                lblPassword.Text = lblPassword.Text + num;
                if (lblPassword.Text.Length == 4)
                {
                    if (lblPassword.Text == "5555")
                    {
                        logIn();
                    }
                    else
                    {
                        FormProvider.orderForm.Show();
                        this.Hide();
                        lblPassword.ResetText();
                        return;
                    }

                }
            }
        }

        private void btnNum1_Click(object sender, EventArgs e)
        {
            updatelblPassword("1");
        }

        private void btnNum2_Click(object sender, EventArgs e)
        {
            updatelblPassword("2");
        }

        private void btnNum3_Click(object sender, EventArgs e)
        {
            updatelblPassword("3");
        }

        private void btnNum4_Click(object sender, EventArgs e)
        {
            updatelblPassword("4");
        }

        private void btnNum5_Click(object sender, EventArgs e)
        {
            updatelblPassword("5");
        }

        private void btnNum6_Click(object sender, EventArgs e)
        {
            updatelblPassword("6");
        }

        private void btnNum7_Click(object sender, EventArgs e)
        {
            updatelblPassword("7");
        }

        private void btnNum8_Click(object sender, EventArgs e)
        {
            updatelblPassword("8");
        }

        private void btnNum9_Click(object sender, EventArgs e)
        {
            updatelblPassword("9");
        }

        private void btnNum0_Click(object sender, EventArgs e)
        {
            updatelblPassword("0");
        }

        private void btnBackspace_Click(object sender, EventArgs e)
        {
            if (lblPassword.Text.Length == 0)
            {
                return;
            }
            else
            {
                lblPassword.Text = lblPassword.Text.Remove(lblPassword.Text.Length - 1);
            }
        }

        public void frmSignIn_Load(object sender, EventArgs e)
        {
            timerTime.Enabled = true;
            this.Location = new Point(0, 0);
            lblPassword.ResetText();
            pnlChooseScreen.Visible = false;

        }

        private void btnBackToSignIn_Click(object sender, EventArgs e)
        {
            pnlChooseScreen.Visible = false;
            pnlSignInScreen.Visible = true;
        }

        private void btnOrderScreen_Click(object sender, EventArgs e)
        {
            /* go to the order menu (Ray's screen) */
            FormProvider.orderForm.Show();
            this.Hide();
        }

        private void btnAdminScreen_Click(object sender, EventArgs e)
        {
            /* go to the admin screen (JR's screen) */
            FormProvider.managerForm.Show();
            this.Hide();
        }

        private void pnlChooseScreen_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnExitApplication_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void timerTime_Tick(object sender, EventArgs e)
        {
            lblCurrentDate.Text = DateTime.Now.ToString();
        }
    }

    /*
    We do not want to create new instances of the forms. In order to
    show and hide one instance of the forms, we need to hold a reference to
    them. This static class below uses the singleton pattern to ensure only
    one instance of the form runs at runtime.
    */
    public class FormProvider
    {
        //These are the forms...
        private static frmMain _orderingForm;
        private static frmManagerMode _managerForm;
        private static frmSignIn _signInForm;
        private static frmQandA _FAQForm;

        //Returns a reference to the form
        public static frmMain orderForm
        {
            get
            {
                if (_orderingForm == null)
                {
                    _orderingForm = new frmMain();
                }
                return _orderingForm;
            }
        }

        //Returns a reference to the form
        public static frmManagerMode managerForm
        {
            get
            {
                if (_managerForm == null)
                {
                    _managerForm = new frmManagerMode();
                }
                return _managerForm;
            }
        }

        //Returns a reference to the form
        public static frmSignIn signInForm
        {
            get
            {
                if (_signInForm == null)
                {
                    _signInForm = new frmSignIn();
                }
                return _signInForm;
            }
        }

        //Returns a reference to the form
        public static frmQandA FAQForm
        {
            get
            {
                if (_FAQForm == null)
                {
                    _FAQForm = new frmQandA();
                }
                return _FAQForm;
            }
        }
    }
}
