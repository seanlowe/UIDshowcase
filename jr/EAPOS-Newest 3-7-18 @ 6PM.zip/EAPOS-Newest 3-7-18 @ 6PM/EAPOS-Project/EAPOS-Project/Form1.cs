﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Ordering;
using SignIn;


namespace EAPOS_Project
{
    public partial class frmManagerMode : Form
    {
        frmMain Ordering = new frmMain();
        frmSignIn SignIn = new frmSignIn();
        public frmManagerMode()
        {
            InitializeComponent();
        }

        private void btnOrderMode_Click(object sender, EventArgs e)
        {
            Ordering.Show();
            this.Visible = false;
        }

        private void btnEmployees_Click(object sender, EventArgs e)
        {
            pnlEmployees.Visible = true;
            pnlManagerMode.Visible = false;
            txtbID.Text = "";
            txtbFirstName.Text = "";
            txtbLastName.Text = "";
            txtbStatus.Text = "";
            txtbWage.Text = "";
            colorblindCheckBox.Checked = false;
            leftHandedCheckBox.Checked = false;
        }

        private void btnQuitProductMgmt_Click(object sender, EventArgs e)
        {
            pnlProductMgmt.Visible = false;
            pnlManagerMode.Visible = true;
        }

        private void btnQuitEmployees_Click(object sender, EventArgs e)
        {
            pnlEmployees.Visible = false;
            pnlManagerMode.Visible = true;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            pnlConfirmDeletion.Visible = false;
        }

        private void btnDeleteItem_Click(object sender, EventArgs e)
        {
            pnlConfirmDeletion.Visible = true;
        }

        private void btnProductManagement_Click(object sender, EventArgs e)
        {
            pnlProductMgmt.Visible = true;
            pnlManagerMode.Visible = false;
        }

        private void btnQuitCreateTest_Click(object sender, EventArgs e)
        {
            pnlCreateTest.Visible = false;
            pnlManagerMode.Visible = true;
        }

        private void btnCreateTrainingTests_Click(object sender, EventArgs e)
        {
            pnlCreateTest.Visible = true;
            pnlManagerMode.Visible = false;
        }

        private void btnQuitSalesReport_Click(object sender, EventArgs e)
        {
            pnlSalesReport.Visible = false;
            pnlManagerMode.Visible = true;
        }

        private void btnSalesReport_Click(object sender, EventArgs e)
        {
            pnlSalesReport.Visible = true;
            pnlManagerMode.Visible = false;
        }

        private void btnCreateNewTest_Click(object sender, EventArgs e)
        {

        }

        public bool IsNumeric(string input)
        {
            int test;
            return int.TryParse(input, out test);
        }

        private void btnUpdateEmployee_Click(object sender, EventArgs e)
        {
            if (!IsNumeric(txtbID.Text))
                MessageBox.Show("ID Must Be A Number", "Error!");

           // if (lstbStatus.SelectedIndex == 0)
           //     MessageBox.Show("Must Select Status", "Error!");
            
            if (Regex.IsMatch(txtbFirstName.Text, @"^[a-zA-Z]+$") == false || Regex.IsMatch(txtbLastName.Text, @"^[a-zA-Z]+$") == false)
                MessageBox.Show("Name cannot contain numbers", "Error");
            this.Validate();
            this.employeesBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.coffeeShopEmployeesDataSet);
        }

        private void btnAddItem_Click(object sender, EventArgs e)
        {
            
            Ordering.btn10.name = this.txtbItemName.Text;
            Ordering.btn10.

            Ordering.btn10.Text = this.txtbItemName.Text;
            Ordering.btn10.Visible = true;
            Ordering.btnPage1.Visible = true;
            Ordering.btnPage2.Visible = true;
        }

        private void frmManagerMode_Load(object sender, EventArgs e)
        {
            txtbID.Text = "";
            txtbFirstName.Text = "";
            txtbLastName.Text = "";
            txtbStatus.Text = "";
            txtbWage.Text = "";
            //lstbStatus.SelectedIndex = 0;
        }

        private void employeesBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeesBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.coffeeShopEmployeesDataSet);

        }

        private void frmManagerMode_Load_1(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'coffeeShopEmployeesDataSet.Employees' table. You can move, or remove it, as needed.
            this.employeesTableAdapter.Fill(this.coffeeShopEmployeesDataSet.Employees);
        }

        private void colorblindCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnSignOutManagerMode_Click(object sender, EventArgs e)
        {
            SignIn.Show();
            this.Visible = false;
        }

        private void leftHandedLabel_Click(object sender, EventArgs e)
        {
        }

        private void colorblindLabel_Click(object sender, EventArgs e)
        {
        }

        private void leftHandedCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void pnlManagerMode_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {

        }

        private void btnAddEmployee_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.PerformClick();
        }

        private void btnDeleteEmployee_Click(object sender, EventArgs e)
        {
            bindingNavigatorDeleteItem.PerformClick();
        }

        private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
        {

        }

        private void pnlEmployees_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
