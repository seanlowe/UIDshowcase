﻿namespace Ordering
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.button1 = new System.Windows.Forms.Button();
            this.lblResolution = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.lstbOrders = new System.Windows.Forms.ListBox();
            this.rtxtbOrderFinal = new System.Windows.Forms.RichTextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.OrderingTimer = new System.Windows.Forms.Timer(this.components);
            this.pnlOrderItems = new System.Windows.Forms.Panel();
            this.btnChicken = new System.Windows.Forms.Button();
            this.btnSoda = new System.Windows.Forms.Button();
            this.btnIceCream = new System.Windows.Forms.Button();
            this.btnCoffee = new System.Windows.Forms.Button();
            this.btnPizzaSlice = new System.Windows.Forms.Button();
            this.btnWholePizza = new System.Windows.Forms.Button();
            this.btnHotDog = new System.Windows.Forms.Button();
            this.btnBagel = new System.Windows.Forms.Button();
            this.btnBurger = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.lblCurrentDate = new System.Windows.Forms.Label();
            this.btnDeleteItem = new System.Windows.Forms.Button();
            this.btnPay = new System.Windows.Forms.Button();
            this.lblEmployeeName = new System.Windows.Forms.Label();
            this.lblLabelReceipt = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.btnFAQ = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlOrderItems.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1418, 55);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(146, 47);
            this.button1.TabIndex = 0;
            this.button1.Text = "Sign Out";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblResolution
            // 
            this.lblResolution.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResolution.Location = new System.Drawing.Point(370, 66);
            this.lblResolution.Name = "lblResolution";
            this.lblResolution.Size = new System.Drawing.Size(181, 33);
            this.lblResolution.TabIndex = 1;
            this.lblResolution.Text = "Resolution";
            this.lblResolution.Visible = false;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(374, 27);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(177, 34);
            this.button2.TabIndex = 2;
            this.button2.Text = "Get Resolution";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lstbOrders
            // 
            this.lstbOrders.BackColor = System.Drawing.SystemColors.Info;
            this.lstbOrders.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstbOrders.FormattingEnabled = true;
            this.lstbOrders.ItemHeight = 25;
            this.lstbOrders.Location = new System.Drawing.Point(47, 227);
            this.lstbOrders.Name = "lstbOrders";
            this.lstbOrders.Size = new System.Drawing.Size(440, 429);
            this.lstbOrders.TabIndex = 3;
            // 
            // rtxtbOrderFinal
            // 
            this.rtxtbOrderFinal.BackColor = System.Drawing.SystemColors.Info;
            this.rtxtbOrderFinal.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtxtbOrderFinal.Location = new System.Drawing.Point(47, 701);
            this.rtxtbOrderFinal.Name = "rtxtbOrderFinal";
            this.rtxtbOrderFinal.ReadOnly = true;
            this.rtxtbOrderFinal.Size = new System.Drawing.Size(440, 242);
            this.rtxtbOrderFinal.TabIndex = 4;
            this.rtxtbOrderFinal.Text = "";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(214, 155);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // OrderingTimer
            // 
            this.OrderingTimer.Tick += new System.EventHandler(this.OrderingTimer_Tick);
            // 
            // pnlOrderItems
            // 
            this.pnlOrderItems.Controls.Add(this.btnChicken);
            this.pnlOrderItems.Controls.Add(this.btnSoda);
            this.pnlOrderItems.Controls.Add(this.btnIceCream);
            this.pnlOrderItems.Controls.Add(this.btnCoffee);
            this.pnlOrderItems.Controls.Add(this.btnPizzaSlice);
            this.pnlOrderItems.Controls.Add(this.btnWholePizza);
            this.pnlOrderItems.Controls.Add(this.btnHotDog);
            this.pnlOrderItems.Controls.Add(this.btnBagel);
            this.pnlOrderItems.Controls.Add(this.btnBurger);
            this.pnlOrderItems.Location = new System.Drawing.Point(505, 143);
            this.pnlOrderItems.Name = "pnlOrderItems";
            this.pnlOrderItems.Size = new System.Drawing.Size(756, 605);
            this.pnlOrderItems.TabIndex = 7;
            // 
            // btnChicken
            // 
            this.btnChicken.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnChicken.BackgroundImage")));
            this.btnChicken.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnChicken.Location = new System.Drawing.Point(292, 223);
            this.btnChicken.Name = "btnChicken";
            this.btnChicken.Size = new System.Drawing.Size(168, 169);
            this.btnChicken.TabIndex = 28;
            this.btnChicken.UseVisualStyleBackColor = true;
            this.btnChicken.Click += new System.EventHandler(this.btnChicken_Click);
            // 
            // btnSoda
            // 
            this.btnSoda.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSoda.BackgroundImage")));
            this.btnSoda.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSoda.Location = new System.Drawing.Point(537, 415);
            this.btnSoda.Name = "btnSoda";
            this.btnSoda.Size = new System.Drawing.Size(168, 169);
            this.btnSoda.TabIndex = 27;
            this.btnSoda.UseVisualStyleBackColor = true;
            this.btnSoda.Click += new System.EventHandler(this.btnSode_Click);
            // 
            // btnIceCream
            // 
            this.btnIceCream.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnIceCream.BackgroundImage")));
            this.btnIceCream.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnIceCream.Location = new System.Drawing.Point(34, 415);
            this.btnIceCream.Name = "btnIceCream";
            this.btnIceCream.Size = new System.Drawing.Size(168, 169);
            this.btnIceCream.TabIndex = 26;
            this.btnIceCream.UseVisualStyleBackColor = true;
            this.btnIceCream.Click += new System.EventHandler(this.btnIceCream_Click);
            // 
            // btnCoffee
            // 
            this.btnCoffee.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCoffee.BackgroundImage")));
            this.btnCoffee.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCoffee.Location = new System.Drawing.Point(537, 223);
            this.btnCoffee.Name = "btnCoffee";
            this.btnCoffee.Size = new System.Drawing.Size(168, 169);
            this.btnCoffee.TabIndex = 25;
            this.btnCoffee.UseVisualStyleBackColor = true;
            this.btnCoffee.Click += new System.EventHandler(this.btnCoffee_Click);
            // 
            // btnPizzaSlice
            // 
            this.btnPizzaSlice.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPizzaSlice.BackgroundImage")));
            this.btnPizzaSlice.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPizzaSlice.Location = new System.Drawing.Point(34, 223);
            this.btnPizzaSlice.Name = "btnPizzaSlice";
            this.btnPizzaSlice.Size = new System.Drawing.Size(168, 169);
            this.btnPizzaSlice.TabIndex = 24;
            this.btnPizzaSlice.UseVisualStyleBackColor = true;
            this.btnPizzaSlice.Click += new System.EventHandler(this.btnPizzaSlice_Click);
            // 
            // btnWholePizza
            // 
            this.btnWholePizza.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnWholePizza.BackgroundImage")));
            this.btnWholePizza.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnWholePizza.Location = new System.Drawing.Point(292, 25);
            this.btnWholePizza.Name = "btnWholePizza";
            this.btnWholePizza.Size = new System.Drawing.Size(168, 169);
            this.btnWholePizza.TabIndex = 23;
            this.btnWholePizza.UseVisualStyleBackColor = true;
            this.btnWholePizza.Click += new System.EventHandler(this.btnWholePizza_Click);
            // 
            // btnHotDog
            // 
            this.btnHotDog.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnHotDog.BackgroundImage")));
            this.btnHotDog.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHotDog.Location = new System.Drawing.Point(537, 25);
            this.btnHotDog.Name = "btnHotDog";
            this.btnHotDog.Size = new System.Drawing.Size(168, 169);
            this.btnHotDog.TabIndex = 22;
            this.btnHotDog.UseVisualStyleBackColor = true;
            this.btnHotDog.Click += new System.EventHandler(this.btnHotDog_Click);
            // 
            // btnBagel
            // 
            this.btnBagel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBagel.BackgroundImage")));
            this.btnBagel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBagel.Location = new System.Drawing.Point(292, 415);
            this.btnBagel.Name = "btnBagel";
            this.btnBagel.Size = new System.Drawing.Size(168, 169);
            this.btnBagel.TabIndex = 21;
            this.btnBagel.UseVisualStyleBackColor = true;
            this.btnBagel.Click += new System.EventHandler(this.btnBagel_Click);
            // 
            // btnBurger
            // 
            this.btnBurger.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBurger.BackgroundImage")));
            this.btnBurger.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBurger.Location = new System.Drawing.Point(34, 25);
            this.btnBurger.Name = "btnBurger";
            this.btnBurger.Size = new System.Drawing.Size(168, 169);
            this.btnBurger.TabIndex = 20;
            this.btnBurger.UseVisualStyleBackColor = true;
            this.btnBurger.Click += new System.EventHandler(this.button5_Click);
            // 
            // lblCurrentDate
            // 
            this.lblCurrentDate.BackColor = System.Drawing.Color.LightCoral;
            this.lblCurrentDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentDate.Location = new System.Drawing.Point(1305, 0);
            this.lblCurrentDate.Name = "lblCurrentDate";
            this.lblCurrentDate.Size = new System.Drawing.Size(259, 52);
            this.lblCurrentDate.TabIndex = 8;
            this.lblCurrentDate.Text = "Current Date";
            this.lblCurrentDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnDeleteItem
            // 
            this.btnDeleteItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnDeleteItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteItem.Location = new System.Drawing.Point(222, 109);
            this.btnDeleteItem.Name = "btnDeleteItem";
            this.btnDeleteItem.Size = new System.Drawing.Size(146, 86);
            this.btnDeleteItem.TabIndex = 9;
            this.btnDeleteItem.Text = "Delete Item";
            this.btnDeleteItem.UseVisualStyleBackColor = false;
            this.btnDeleteItem.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnPay
            // 
            this.btnPay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnPay.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPay.Location = new System.Drawing.Point(56, 109);
            this.btnPay.Name = "btnPay";
            this.btnPay.Size = new System.Drawing.Size(146, 86);
            this.btnPay.TabIndex = 10;
            this.btnPay.Text = "PAY";
            this.btnPay.UseVisualStyleBackColor = false;
            this.btnPay.Click += new System.EventHandler(this.btnPay_Click);
            // 
            // lblEmployeeName
            // 
            this.lblEmployeeName.BackColor = System.Drawing.Color.Silver;
            this.lblEmployeeName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployeeName.Location = new System.Drawing.Point(941, 0);
            this.lblEmployeeName.Name = "lblEmployeeName";
            this.lblEmployeeName.Size = new System.Drawing.Size(358, 52);
            this.lblEmployeeName.TabIndex = 11;
            this.lblEmployeeName.Text = "Employee\'s Name";
            this.lblEmployeeName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLabelReceipt
            // 
            this.lblLabelReceipt.BackColor = System.Drawing.Color.Transparent;
            this.lblLabelReceipt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLabelReceipt.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLabelReceipt.ForeColor = System.Drawing.Color.Black;
            this.lblLabelReceipt.Location = new System.Drawing.Point(47, 181);
            this.lblLabelReceipt.Name = "lblLabelReceipt";
            this.lblLabelReceipt.Size = new System.Drawing.Size(440, 43);
            this.lblLabelReceipt.TabIndex = 12;
            this.lblLabelReceipt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1358, 55);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(54, 47);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 13;
            this.pictureBox2.TabStop = false;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(56, 17);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(146, 86);
            this.button3.TabIndex = 14;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(222, 17);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(146, 86);
            this.button4.TabIndex = 15;
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(393, 17);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(146, 86);
            this.button5.TabIndex = 16;
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(393, 111);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(146, 86);
            this.button6.TabIndex = 17;
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(560, 17);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(146, 86);
            this.button7.TabIndex = 18;
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(560, 111);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(146, 86);
            this.button8.TabIndex = 19;
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(723, 17);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(146, 86);
            this.button9.TabIndex = 20;
            this.button9.UseVisualStyleBackColor = true;
            // 
            // btnFAQ
            // 
            this.btnFAQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFAQ.Location = new System.Drawing.Point(723, 111);
            this.btnFAQ.Name = "btnFAQ";
            this.btnFAQ.Size = new System.Drawing.Size(146, 86);
            this.btnFAQ.TabIndex = 21;
            this.btnFAQ.Text = "FAQ";
            this.btnFAQ.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.btnFAQ);
            this.panel1.Controls.Add(this.btnDeleteItem);
            this.panel1.Controls.Add(this.button9);
            this.panel1.Controls.Add(this.btnPay);
            this.panel1.Controls.Add(this.button8);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button7);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Location = new System.Drawing.Point(505, 754);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1036, 219);
            this.panel1.TabIndex = 22;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button15);
            this.panel2.Controls.Add(this.button14);
            this.panel2.Controls.Add(this.button13);
            this.panel2.Controls.Add(this.button12);
            this.panel2.Controls.Add(this.button11);
            this.panel2.Location = new System.Drawing.Point(1289, 143);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(252, 605);
            this.panel2.TabIndex = 23;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(52, 498);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(146, 86);
            this.button15.TabIndex = 26;
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(52, 381);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(146, 86);
            this.button14.TabIndex = 25;
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(52, 264);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(146, 86);
            this.button13.TabIndex = 24;
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(52, 139);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(146, 86);
            this.button12.TabIndex = 23;
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(52, 18);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(146, 86);
            this.button11.TabIndex = 22;
            this.button11.UseVisualStyleBackColor = true;
            // 
            // frmMain
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1563, 1002);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.lblLabelReceipt);
            this.Controls.Add(this.lblEmployeeName);
            this.Controls.Add(this.lblCurrentDate);
            this.Controls.Add(this.pnlOrderItems);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.rtxtbOrderFinal);
            this.Controls.Add(this.lstbOrders);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.lblResolution);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximumSize = new System.Drawing.Size(1563, 1002);
            this.MinimumSize = new System.Drawing.Size(1563, 1002);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlOrderItems.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblResolution;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ListBox lstbOrders;
        private System.Windows.Forms.RichTextBox rtxtbOrderFinal;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Timer OrderingTimer;
        private System.Windows.Forms.Panel pnlOrderItems;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label lblCurrentDate;
        private System.Windows.Forms.Button btnDeleteItem;
        private System.Windows.Forms.Button btnBurger;
        private System.Windows.Forms.Button btnChicken;
        private System.Windows.Forms.Button btnSoda;
        private System.Windows.Forms.Button btnIceCream;
        private System.Windows.Forms.Button btnCoffee;
        private System.Windows.Forms.Button btnPizzaSlice;
        private System.Windows.Forms.Button btnWholePizza;
        private System.Windows.Forms.Button btnHotDog;
        private System.Windows.Forms.Button btnBagel;
        private System.Windows.Forms.Button btnPay;
        private System.Windows.Forms.Label lblEmployeeName;
        private System.Windows.Forms.Label lblLabelReceipt;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button btnFAQ;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
    }
}

