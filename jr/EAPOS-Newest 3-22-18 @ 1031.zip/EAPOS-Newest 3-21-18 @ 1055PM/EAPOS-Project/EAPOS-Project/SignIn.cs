﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EAPOS_Project;
using Ordering;
using WindowsFormsApplication1;
using System.Data.OleDb;

namespace SignIn
{
    public partial class frmSignIn : Form
    {
        public class Employee
        {
            public int id;
            public string fName;
            public string lName;
            public string userStatus;
            public double wage;
            public bool leftHanded;
            public bool colorBlind;
            public double hours;

            //Constructor
            public Employee(int inID, string infName, string inlName, string inUserStats, double inWage, bool inLeft, bool inColor, double inHours)
            {
                id = inID;
                fName = infName;
                lName = inlName;
                inUserStats = userStatus;
                wage = inWage;
                leftHanded = inLeft;
                colorBlind = inColor;
                hours = inHours;
            }

            //TO DO: Add more functions...
        }

        //Dynamic Linked list of POS Employees
        public List<Employee> POSEmployees = new List<Employee>();

        public frmSignIn()
        {
            InitializeComponent();
        }

        public bool checkLength()
        {
            if (lblPassword.Text.Length <= 3)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void logIn()
        {
            lblPassword.ResetText();
            pnlSignInScreen.Visible = false;
            pnlChooseScreen.Visible = true;
        }

        public void updatelblPassword(string num)
        {
            if (checkLength() == true)
            {
                lblPassword.Text = lblPassword.Text + num;
                if (lblPassword.Text.Length == 4)
                {
                    if (lblPassword.Text == "5555")
                    {
                        logIn();
                    }
                    else
                    {
                        FormProvider.orderForm.Show();
                        this.Hide();
                        lblPassword.ResetText();
                        return;
                    }

                }
            }
        }

        
        public void logInTime(int id)
        {
            DateTime dt = DateTime.Now;
            OleDbConnection cs = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\sonof\OneDrive\Desktop\EAPOS-Newest 3-21-18 @ 1055PM\EAPOS-Project\CoffeeShopEmployees.accdb");
                cs.Open();
            OleDbCommand cmd = new OleDbCommand("SELECT* FROM Hours WHERE empID='" + this.lblPassword.Text + "' INSERT INTO Table(ClockIn) values('" + dt+"')", cs);
            cmd.ExecuteNonQuery();
            cs.Close();
        }

        public void logOutTime(int id)
        {
            DateTime dt = DateTime.Now;
            OleDbConnection cs = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\sonof\OneDrive\Desktop\EAPOS-Newest 3-21-18 @ 1055PM\EAPOS-Project\CoffeeShopEmployees.accdb");
            cs.Open();
            OleDbCommand cmd = new OleDbCommand("SELECT* FROM Hours WHERE empID='" + this.lblPassword.Text + "' INSERT INTO Table(ClockIn) values('" + dt + "')", cs);
            cmd.ExecuteNonQuery();
            cs.Close();
        }
        private void btnNum1_Click(object sender, EventArgs e)
        {
            updatelblPassword("1");
        }

        private void btnNum2_Click(object sender, EventArgs e)
        {
            updatelblPassword("2");
        }

        private void btnNum3_Click(object sender, EventArgs e)
        {
            updatelblPassword("3");
        }

        private void btnNum4_Click(object sender, EventArgs e)
        {
            updatelblPassword("4");
        }

        private void btnNum5_Click(object sender, EventArgs e)
        {
            updatelblPassword("5");
        }

        private void btnNum6_Click(object sender, EventArgs e)
        {
            updatelblPassword("6");
        }

        private void btnNum7_Click(object sender, EventArgs e)
        {
            updatelblPassword("7");
        }

        private void btnNum8_Click(object sender, EventArgs e)
        {
            updatelblPassword("8");
        }

        private void btnNum9_Click(object sender, EventArgs e)
        {
            updatelblPassword("9");
        }

        private void btnNum0_Click(object sender, EventArgs e)
        {
            updatelblPassword("0");
        }

        private void btnBackspace_Click(object sender, EventArgs e)
        {
            if (lblPassword.Text.Length == 0)
            {
                return;
            }
            else
            {
                lblPassword.Text = lblPassword.Text.Remove(lblPassword.Text.Length - 1);
            }
        }

        public void frmSignIn_Load(object sender, EventArgs e)
        {
            
            int inputID;
            string inputFname;
            string inputLname;
            string inputStatus;
            double inputWage;
            bool inputLeftHanded;
            bool inputColorblind;
            double inputHours;


            timerTime.Enabled = true;
            this.Location = new Point(0, 0);
            lblPassword.ResetText();
            pnlChooseScreen.Visible = false;
            using (OleDbConnection conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\sonof\OneDrive\Desktop\EAPOS-Newest 3-21-18 @ 1055PM\EAPOS-Project\CoffeeShopEmployees.accdb"))
            using (OleDbCommand cmd = new OleDbCommand("select* from Employees", conn))
            {
                conn.Open();
                OleDbDataReader reader = null;
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    inputID = Int32.Parse(reader["ID"].ToString());
                    inputFname = reader["Fname"].ToString();
                    inputLname = reader["Lname"].ToString();
                    inputStatus = reader["Status"].ToString();
                    inputWage = Convert.ToDouble(reader["Wage"].ToString());
                    inputLeftHanded = false;    //FIX THIS!!!
                    inputColorblind = false;    //FIX THIS!!!
                    inputHours = 0.00;         //FIX THIS!!!

                    POSEmployees.Add(new Employee(inputID, inputFname, inputLname, inputStatus, inputWage, inputLeftHanded, inputColorblind, inputHours));


                    /*
                    POSEmployee.id.Add(reader["ID"].ToString());
                    POSEmployee.fName.Add(reader["Fname"].ToString());
                    POSEmployee.lName.Add(reader["Lname"].ToString());
                    POSEmployee.userStatus.Add(reader["Status"].ToString());
                    POSEmployee.wage.Add(reader["Wage"].ToString());
                    POSEmployee.leftHanded.Add(reader["LeftHanded"].ToString());
                    POSEmployee.colorBlind.Add(reader["ColorBlind"].ToString());
                    */
                }
                conn.Close();
            }

        }

        private void btnBackToSignIn_Click(object sender, EventArgs e)
        {
            pnlChooseScreen.Visible = false;
            pnlSignInScreen.Visible = true;
        }

        private void btnOrderScreen_Click(object sender, EventArgs e)
        {
            /* go to the order menu (Ray's screen) */
            FormProvider.orderForm.Show();
            this.Hide();
        }

        private void btnAdminScreen_Click(object sender, EventArgs e)
        {
            /* go to the admin screen (JR's screen) */
            FormProvider.managerForm.Show();
            this.Hide();
        }

        private void pnlChooseScreen_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnExitApplication_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void timerTime_Tick(object sender, EventArgs e)
        {
            lblCurrentDate.Text = DateTime.Now.ToString();
        }

        
    }

    /*
    We do not want to create new instances of the forms. In order to
    show and hide one instance of the forms, we need to hold a reference to
    them. This static class below uses the singleton pattern to ensure only
    one instance of the form runs at runtime.
    */
    public class FormProvider
    {
        //These are the forms...
        private static frmMain _orderingForm;
        private static frmManagerMode _managerForm;
        private static frmSignIn _signInForm;
        private static frmQandA _FAQForm;

        //Returns a reference to the form
        public static frmMain orderForm
        {
            get
            {
                if (_orderingForm == null)
                {
                    _orderingForm = new frmMain();
                }
                return _orderingForm;
            }
        }

        //Returns a reference to the form
        public static frmManagerMode managerForm
        {
            get
            {
                if (_managerForm == null)
                {
                    _managerForm = new frmManagerMode();
                }
                return _managerForm;
            }
        }

        //Returns a reference to the form
        public static frmSignIn signInForm
        {
            get
            {
                if (_signInForm == null)
                {
                    _signInForm = new frmSignIn();
                }
                return _signInForm;
            }
        }

        //Returns a reference to the form
        public static frmQandA FAQForm
        {
            get
            {
                if (_FAQForm == null)
                {
                    _FAQForm = new frmQandA();
                }
                return _FAQForm;
            }
        }
    }
}
