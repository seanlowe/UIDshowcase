﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using SignIn;
using WindowsFormsApplication1;
using EAPOS_Project;

namespace Ordering
{
    public partial class frmMain : Form
    {

        //Class for the order Items
        public class orderItem
        {
            public int quantity;
            public frmSignIn.FoodItem foodItem;
            public string[] strmessage = new string[5];
            public int nummessages;
            public bool message;

            //Constructor
            public orderItem(frmSignIn.FoodItem inputFoodItem)
            {
                foodItem = inputFoodItem;
                quantity = 1;
                message = false;
                for (int i=0; i < 5; i++)
                {
                    strmessage[i] = "";
                }
            }

            //Increments the quantity of oderItem
            public void incrementQuantity()
            {
                quantity++;
            }
            
            //Food Item accessor
            public string getFoodItemName()
            {
                return foodItem.name;
            }

            //Quantity accessor
            public int getQunatity()
            {
                return quantity;
            }

        }

        //Dynamic linked list of orderItems
        List<orderItem> Orders = new List<orderItem>();

        

        public frmMain()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormProvider.signInForm.Show();
            btnGoToManagerMode.Visible = false;
            this.Hide();
            FormProvider.signInForm.logOutTime(FormProvider.signInForm.activeUserID);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string width;
            string height;

            width = this.Width.ToString();
            height = this.Height.ToString();

            lblResolution.Text = "Height: " + height + " Width: " + width;

        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            //lstbOrders.Font = new Font(FontFamily.GenericMonospace, lstbOrders.Font.Size);
            calculateOrderTotal();
            OrderingTimer.Enabled = true;
            this.Location = new Point(0, 0);
            this.Size = Screen.PrimaryScreen.WorkingArea.Size;
            lstbOrders.Text = "";
            lblLabelReceipt.Text = "Qty".PadRight(5) + "Description".PadRight(21) + "Amount($)";
        }

        private void OrderingTimer_Tick(object sender, EventArgs e)
        {
            lblCurrentDate.Text = DateTime.Now.ToString();
        }

        //This function adds items to the current order
        private void addToOder(string buttonName)
        {
            bool found = false;
            int i = 0;
            frmSignIn.FoodItem foodItem;
            Debug.Print("You clicked on:" + buttonName);
            
            
            //Finds the associated food item
            while (found == false && i < FormProvider.signInForm.pushedInItems.Count)
            {
                if (FormProvider.signInForm.pushedInItems[i].btnName.Name == buttonName)
                {
                    found = true;
                    Debug.Print("Found the assigned button!");
                    bool doesItExistAlready = false;
                    foodItem = FormProvider.signInForm.pushedInItems[i];
                    Debug.Print("It is: " + FormProvider.signInForm.pushedInItems[i].name.ToString());

                    //Need to check if the item already exists in the Orders list, if so then increment the quntity of item..
                    for (int j = 0; j < Orders.Count; j++)
                    {
                        if (Orders[j].foodItem.name == foodItem.name)
                        {
                            Debug.Print("The item is already in the order! Incrementing the quntity");
                            doesItExistAlready = true;
                            Orders[j].incrementQuantity();
                        }

                    }

                    //Add the orderItem only if it does not exist!
                    if (!doesItExistAlready)
                    {
                        //Add the oderItem to the Orders list
                        Debug.Print("Item did not exist in order so I added it!");
                        Orders.Add(new orderItem(foodItem));
                    }
                    //Prints
                    PrintOrders();
                }
                i++;
                calculateOrderTotal();
            }
            if (found == false)
                Debug.Print("Could not find associated object!");
            
                 
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string objname = ((Button)sender).Name;
            addToOder(objname);
            


            
        }

        private void btnWholePizza_Click(object sender, EventArgs e)
        {
            string objname = ((Button)sender).Name;
            addToOder(objname);
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            /*
            if(lstbOrders.SelectedIndex != -1)
            {
                //Removes the order item from the linked list
                int indexOfItemInList = 0;
                indexOfItemInList = lstbOrders.SelectedIndex;
                string itemRemoved = Orders[indexOfItemInList].type;
                Orders.RemoveAt(indexOfItemInList);

                //Resets the counter to add item again
                if (itemRemoved == "Burger")
                    numBurgers = 0;
                else if (itemRemoved == "HotDog")
                    numHotDogs = 0;
                else if (itemRemoved == "Pizza")
                    numPizzas = 0;
                else if (itemRemoved == "Pizza Slice")
                    numPizzaSlices = 0;
                else if (itemRemoved == "Chicken")
                    numChicken = 0;
                else if (itemRemoved == "Coffee")
                    numCoffee = 0;
                else if (itemRemoved == "Soda")
                    numSoda = 0;
                else if (itemRemoved == "Bagel")
                    numBagel = 0;
                else if (itemRemoved == "IceCream")
                    numBagel = 0;


                //The cosmetic aspect
                calculateOrderTotal();
                lstbOrders.Items.Remove(lstbOrders.SelectedItem);
                lstbOrders.Refresh();

            }  
            */
        }

        

        private void btnHotDog_Click(object sender, EventArgs e)
        {          
            string objname = ((Button)sender).Name;
            addToOder(objname);



            
        }

        private void btnPizzaSlice_Click(object sender, EventArgs e)
        {
            string objname = ((Button)sender).Name;
            addToOder(objname);
           
        }

        private void btnChicken_Click(object sender, EventArgs e)
        {
            string objname = ((Button)sender).Name;
            addToOder(objname);
            
        }

        private void btnCoffee_Click(object sender, EventArgs e)
        {
            string objname = ((Button)sender).Name;
            addToOder(objname);
            
        }

        private void btnSode_Click(object sender, EventArgs e)
        {
            string objname = ((Button)sender).Name;
            addToOder(objname);
            
        }

        private void btnBagel_Click(object sender, EventArgs e)
        {
            string objname = ((Button)sender).Name;
            addToOder(objname);
            
        }

        private void btnIceCream_Click(object sender, EventArgs e)
        {
            string objname = ((Button)sender).Name;
            addToOder(objname);
            

        }

        void PrintOrders()
        {
            //Clears the listbox in the ordering form
            lstbOrders.Items.Clear();

            for(int i = 0; i < Orders.Count; i++)
            {
                string type = Orders[i].getFoodItemName();
                int quantity = Orders[i].getQunatity();
                double price = Orders[i].foodItem.price;      
                string strPrice = string.Format("{0:C}", price);

                string orderline = quantity.ToString().PadRight(5) + type.PadRight(21) + strPrice;
               
               
                lstbOrders.Items.Add(orderline);
                
            }
        }

        void AddItemToOrder(ref int quantity, string name, double price)
        {
            
        }

        void calculateOrderTotal()
        {
            //Calculates the total price
            double totalPrice = 0;
            for (int i = 0; i < Orders.Count; i++)
            {
                totalPrice = totalPrice + (Orders[i].foodItem.price * Orders[i].getQunatity());
            }

            rtxtbOrderFinal.Clear();
            rtxtbOrderFinal.AppendText(" Subtotal: ".PadRight(28) + "$" + totalPrice.ToString());
            rtxtbOrderFinal.AppendText(Environment.NewLine);
            rtxtbOrderFinal.AppendText(" Discount: ".PadRight(28) + "$0.00");
            rtxtbOrderFinal.AppendText(Environment.NewLine);
            rtxtbOrderFinal.AppendText(" Tax: ".PadRight(28) + "$0.00");

            rtxtbOrderFinal.AppendText(Environment.NewLine);         
            rtxtbOrderFinal.AppendText(Environment.NewLine);
            rtxtbOrderFinal.AppendText(Environment.NewLine);
            rtxtbOrderFinal.AppendText("------------------------------------");
            rtxtbOrderFinal.AppendText(Environment.NewLine);

            rtxtbOrderFinal.AppendText(" Total: ".PadRight(28) + "$" + totalPrice.ToString());
            rtxtbOrderFinal.AppendText(Environment.NewLine);
        }


        //Prints the list of items in this order!
        void debugTest()
        {
            for (int i = 0; i < Orders.Count; i++)
            {
                Debug.Print(Orders[i].foodItem.name);
            }
        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            
        }

        private void btnFAQ_Click(object sender, EventArgs e)
        {
            FormProvider.FAQForm.Show();
        }

        private void btnPage2_Click(object sender, EventArgs e)
        {
            this.pnlMenuPage1.Visible = false;
            this.pnlMenuPage2.Visible = true;
        }

        private void btnPage1_Click(object sender, EventArgs e)
        {
            this.pnlMenuPage1.Visible = true;
            this.pnlMenuPage2.Visible = false;
        }

        public void btn10_Click(object sender, EventArgs e)
        {
            string objname = ((Button)sender).Name;
            addToOder(objname);
        }

        private void pnlOrdering_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {

        }

        private void btnGoToManagerMode_Click(object sender, EventArgs e)
        {
            FormProvider.managerForm.Show();
            this.Hide();
        }

        private void lblEmployeeName_Click(object sender, EventArgs e)
        {

        }

        private void btnCancelOrder_Click(object sender, EventArgs e)
        {
            lstbOrders.Text = "";
            pnlMenuPage1.Visible = true;
            pnlMenuPage2.Visible = false;
            pnlMenuNavigation.Visible = false;
        }


        //--------------------------------------------------------- Nueric Keypad ----------------------------------------------//

        public void updateKeypadDisplay(string num)
        {
            txtbKeypad.Text = txtbKeypad.Text + num;
        }

        private void btn1Keypad_Click(object sender, EventArgs e)
        {
            updateKeypadDisplay("1");
        }
        private void btn2Keypad_Click(object sender, EventArgs e)
        {
            updateKeypadDisplay("2");
        }

        private void btn3Keypad_Click(object sender, EventArgs e)
        {
            updateKeypadDisplay("3");
        }

        private void btn4Keypad_Click(object sender, EventArgs e)
        {
            updateKeypadDisplay("4");
        }

        private void btn5Kepad_Click(object sender, EventArgs e)
        {
            updateKeypadDisplay("5");
        }

        private void btn6Keypad_Click(object sender, EventArgs e)
        {
            updateKeypadDisplay("6");
        }

        private void btn7Keypad_Click(object sender, EventArgs e)
        {
            updateKeypadDisplay("7");
        }

        private void btn8Keypad_Click(object sender, EventArgs e)
        {
            updateKeypadDisplay("8");
        }

        private void btn9Keypad_Click(object sender, EventArgs e)
        {
            updateKeypadDisplay("9");
        }

        private void btn0Keypad_Click(object sender, EventArgs e)
        {
            updateKeypadDisplay("0");
        }
        
        private void btnClearKeypad_Click(object sender, EventArgs e)
        {
            txtbKeypad.ResetText();
        }

        private void btnKeypadEnter_Click(object sender, EventArgs e)
        {
            pnlOrdering.BringToFront();
            pnlOrdering.Enabled = true;
        }

        private void btnQuantity_Click(object sender, EventArgs e)
        {
            pnlKeypad.Visible = true;
            pnlKeypad.BringToFront();
            pnlOrdering.Enabled = false;
        }

        private void btnMessage_Click(object sender, EventArgs e)
        {
            int index = lstbOrders.SelectedIndex;
            if (lstbOrders.SelectedIndex > -1)
            {
                Orders[index].message = true;
                Orders[index].strmessage = "extra cheese";
            }
        }


        //Partial Class frmMain
    }   

    //Namespace Ordering
}
