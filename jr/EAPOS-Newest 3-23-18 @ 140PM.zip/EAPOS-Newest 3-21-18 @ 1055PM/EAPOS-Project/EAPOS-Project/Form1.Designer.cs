﻿namespace EAPOS_Project
{
    partial class frmManagerMode
    {

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        public void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label lblEmployeeId;
            System.Windows.Forms.Label lblFirstName;
            System.Windows.Forms.Label lblLastName;
            System.Windows.Forms.Label lblStatus;
            System.Windows.Forms.Label lblWage;
            System.Windows.Forms.Label colorblindLabel;
            System.Windows.Forms.Label leftHandedLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmManagerMode));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlManagerMode = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnSignOutManagerMode = new System.Windows.Forms.Button();
            this.lblManagerMode = new System.Windows.Forms.Label();
            this.btnOrderMode = new System.Windows.Forms.Button();
            this.btnSalesReport = new System.Windows.Forms.Button();
            this.btnCreateTrainingTests = new System.Windows.Forms.Button();
            this.btnProductManagement = new System.Windows.Forms.Button();
            this.btnEmployees = new System.Windows.Forms.Button();
            this.pnlEmployees = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.employeesDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.employeesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.coffeeShopEmployeesDataSet = new EAPOS_Project.CoffeeShopEmployeesDataSet();
            this.gpbEmployee = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.leftHandedCheckBox = new System.Windows.Forms.CheckBox();
            this.colorblindCheckBox = new System.Windows.Forms.CheckBox();
            this.btnAddEmployee = new System.Windows.Forms.Button();
            this.btnUpdateEmployee = new System.Windows.Forms.Button();
            this.btnDeleteEmployee = new System.Windows.Forms.Button();
            this.txtbWage = new System.Windows.Forms.TextBox();
            this.txtbStatus = new System.Windows.Forms.TextBox();
            this.txtbLastName = new System.Windows.Forms.TextBox();
            this.txtbFirstName = new System.Windows.Forms.TextBox();
            this.txtbID = new System.Windows.Forms.TextBox();
            this.btnQuitEmployees = new System.Windows.Forms.Button();
            this.lblEmployees = new System.Windows.Forms.Label();
            this.pnlProductMgmt = new System.Windows.Forms.Panel();
            this.buttonMainPanelBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.grpbRemoveItem = new System.Windows.Forms.GroupBox();
            this.btnDeleteItem = new System.Windows.Forms.Button();
            this.txtbItemToDelete = new System.Windows.Forms.TextBox();
            this.lblItemToRemove = new System.Windows.Forms.Label();
            this.grpbAddItem = new System.Windows.Forms.GroupBox();
            this.btnAddItem = new System.Windows.Forms.Button();
            this.txtbAddSubmenu = new System.Windows.Forms.TextBox();
            this.lblAddSubmenu = new System.Windows.Forms.Label();
            this.lstbSubmenues = new System.Windows.Forms.ListBox();
            this.lblItemSubMenus = new System.Windows.Forms.Label();
            this.lblItemPrice = new System.Windows.Forms.Label();
            this.txtbItemPrice = new System.Windows.Forms.TextBox();
            this.lblItemName = new System.Windows.Forms.Label();
            this.txtbItemName = new System.Windows.Forms.TextBox();
            this.btnQuitProductMgmt = new System.Windows.Forms.Button();
            this.lblProductManagement = new System.Windows.Forms.Label();
            this.pnlConfirmDeletion = new System.Windows.Forms.Panel();
            this.lblDeleteWarning = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.lblConfirmDeletion = new System.Windows.Forms.Label();
            this.pnlCreateTest = new System.Windows.Forms.Panel();
            this.btnCreateNewTest = new System.Windows.Forms.Button();
            this.txtbNewTestName = new System.Windows.Forms.TextBox();
            this.lblNewTestName = new System.Windows.Forms.Label();
            this.btnQuitCreateTest = new System.Windows.Forms.Button();
            this.lblCreatePracticeTest = new System.Windows.Forms.Label();
            this.pnlSalesReport = new System.Windows.Forms.Panel();
            this.rtxtbSalesReport = new System.Windows.Forms.RichTextBox();
            this.lblSalesReport = new System.Windows.Forms.Label();
            this.btnQuitSalesReport = new System.Windows.Forms.Button();
            this.employeesBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.employeesBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.employeesTableAdapter = new EAPOS_Project.CoffeeShopEmployeesDataSetTableAdapters.EmployeesTableAdapter();
            this.tableAdapterManager = new EAPOS_Project.CoffeeShopEmployeesDataSetTableAdapters.TableAdapterManager();
            this.buttonMainPanelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            lblEmployeeId = new System.Windows.Forms.Label();
            lblFirstName = new System.Windows.Forms.Label();
            lblLastName = new System.Windows.Forms.Label();
            lblStatus = new System.Windows.Forms.Label();
            lblWage = new System.Windows.Forms.Label();
            colorblindLabel = new System.Windows.Forms.Label();
            leftHandedLabel = new System.Windows.Forms.Label();
            this.pnlManagerMode.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlEmployees.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeesDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coffeeShopEmployeesDataSet)).BeginInit();
            this.gpbEmployee.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.pnlProductMgmt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.buttonMainPanelBindingSource1)).BeginInit();
            this.grpbRemoveItem.SuspendLayout();
            this.grpbAddItem.SuspendLayout();
            this.pnlConfirmDeletion.SuspendLayout();
            this.pnlCreateTest.SuspendLayout();
            this.pnlSalesReport.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingNavigator)).BeginInit();
            this.employeesBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.buttonMainPanelBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // lblEmployeeId
            // 
            lblEmployeeId.AutoSize = true;
            lblEmployeeId.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lblEmployeeId.Location = new System.Drawing.Point(30, 49);
            lblEmployeeId.Name = "lblEmployeeId";
            lblEmployeeId.Size = new System.Drawing.Size(37, 31);
            lblEmployeeId.TabIndex = 13;
            lblEmployeeId.Text = "Id";
            // 
            // lblFirstName
            // 
            lblFirstName.AutoSize = true;
            lblFirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lblFirstName.Location = new System.Drawing.Point(26, 116);
            lblFirstName.Name = "lblFirstName";
            lblFirstName.Size = new System.Drawing.Size(147, 31);
            lblFirstName.TabIndex = 15;
            lblFirstName.Text = "First Name";
            // 
            // lblLastName
            // 
            lblLastName.AutoSize = true;
            lblLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lblLastName.Location = new System.Drawing.Point(26, 182);
            lblLastName.Name = "lblLastName";
            lblLastName.Size = new System.Drawing.Size(145, 31);
            lblLastName.TabIndex = 17;
            lblLastName.Text = "Last Name";
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lblStatus.Location = new System.Drawing.Point(26, 253);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new System.Drawing.Size(92, 31);
            lblStatus.TabIndex = 19;
            lblStatus.Text = "Status";
            // 
            // lblWage
            // 
            lblWage.AutoSize = true;
            lblWage.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lblWage.Location = new System.Drawing.Point(30, 323);
            lblWage.Name = "lblWage";
            lblWage.Size = new System.Drawing.Size(84, 31);
            lblWage.TabIndex = 21;
            lblWage.Text = "Wage";
            // 
            // colorblindLabel
            // 
            colorblindLabel.AutoSize = true;
            colorblindLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            colorblindLabel.Location = new System.Drawing.Point(55, 147);
            colorblindLabel.Name = "colorblindLabel";
            colorblindLabel.Size = new System.Drawing.Size(144, 31);
            colorblindLabel.TabIndex = 25;
            colorblindLabel.Text = "Colorblind:";
            colorblindLabel.Click += new System.EventHandler(this.colorblindLabel_Click);
            // 
            // leftHandedLabel
            // 
            leftHandedLabel.AutoSize = true;
            leftHandedLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            leftHandedLabel.Location = new System.Drawing.Point(42, 44);
            leftHandedLabel.Name = "leftHandedLabel";
            leftHandedLabel.Size = new System.Drawing.Size(170, 31);
            leftHandedLabel.TabIndex = 23;
            leftHandedLabel.Text = "Left Handed:";
            leftHandedLabel.Click += new System.EventHandler(this.leftHandedLabel_Click);
            // 
            // pnlManagerMode
            // 
            this.pnlManagerMode.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlManagerMode.Controls.Add(this.pictureBox1);
            this.pnlManagerMode.Controls.Add(this.btnSignOutManagerMode);
            this.pnlManagerMode.Controls.Add(this.lblManagerMode);
            this.pnlManagerMode.Controls.Add(this.btnOrderMode);
            this.pnlManagerMode.Controls.Add(this.btnSalesReport);
            this.pnlManagerMode.Controls.Add(this.btnCreateTrainingTests);
            this.pnlManagerMode.Controls.Add(this.btnProductManagement);
            this.pnlManagerMode.Controls.Add(this.btnEmployees);
            this.pnlManagerMode.Location = new System.Drawing.Point(0, 0);
            this.pnlManagerMode.Name = "pnlManagerMode";
            this.pnlManagerMode.Size = new System.Drawing.Size(1545, 960);
            this.pnlManagerMode.TabIndex = 0;
            this.pnlManagerMode.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlManagerMode_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(14, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(214, 155);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // btnSignOutManagerMode
            // 
            this.btnSignOutManagerMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSignOutManagerMode.Location = new System.Drawing.Point(1338, 873);
            this.btnSignOutManagerMode.Name = "btnSignOutManagerMode";
            this.btnSignOutManagerMode.Size = new System.Drawing.Size(182, 60);
            this.btnSignOutManagerMode.TabIndex = 5;
            this.btnSignOutManagerMode.Text = "Sign Out";
            this.btnSignOutManagerMode.UseVisualStyleBackColor = true;
            this.btnSignOutManagerMode.Click += new System.EventHandler(this.btnSignOutManagerMode_Click);
            // 
            // lblManagerMode
            // 
            this.lblManagerMode.AutoSize = true;
            this.lblManagerMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblManagerMode.Location = new System.Drawing.Point(558, 23);
            this.lblManagerMode.Name = "lblManagerMode";
            this.lblManagerMode.Size = new System.Drawing.Size(428, 73);
            this.lblManagerMode.TabIndex = 4;
            this.lblManagerMode.Text = "Manger Mode";
            // 
            // btnOrderMode
            // 
            this.btnOrderMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrderMode.Location = new System.Drawing.Point(649, 769);
            this.btnOrderMode.Name = "btnOrderMode";
            this.btnOrderMode.Size = new System.Drawing.Size(246, 113);
            this.btnOrderMode.TabIndex = 2;
            this.btnOrderMode.Text = "Order Mode";
            this.btnOrderMode.UseVisualStyleBackColor = true;
            this.btnOrderMode.Click += new System.EventHandler(this.btnOrderMode_Click);
            // 
            // btnSalesReport
            // 
            this.btnSalesReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalesReport.Location = new System.Drawing.Point(876, 471);
            this.btnSalesReport.Name = "btnSalesReport";
            this.btnSalesReport.Size = new System.Drawing.Size(400, 231);
            this.btnSalesReport.TabIndex = 3;
            this.btnSalesReport.Text = "Sales Report";
            this.btnSalesReport.UseVisualStyleBackColor = true;
            this.btnSalesReport.Click += new System.EventHandler(this.btnSalesReport_Click);
            // 
            // btnCreateTrainingTests
            // 
            this.btnCreateTrainingTests.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateTrainingTests.Location = new System.Drawing.Point(269, 471);
            this.btnCreateTrainingTests.Name = "btnCreateTrainingTests";
            this.btnCreateTrainingTests.Size = new System.Drawing.Size(400, 231);
            this.btnCreateTrainingTests.TabIndex = 2;
            this.btnCreateTrainingTests.Text = "Create Training Tests";
            this.btnCreateTrainingTests.UseVisualStyleBackColor = true;
            this.btnCreateTrainingTests.Click += new System.EventHandler(this.btnCreateTrainingTests_Click);
            // 
            // btnProductManagement
            // 
            this.btnProductManagement.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProductManagement.Location = new System.Drawing.Point(876, 158);
            this.btnProductManagement.Name = "btnProductManagement";
            this.btnProductManagement.Size = new System.Drawing.Size(400, 231);
            this.btnProductManagement.TabIndex = 1;
            this.btnProductManagement.Text = "Product Management";
            this.btnProductManagement.UseVisualStyleBackColor = true;
            this.btnProductManagement.Click += new System.EventHandler(this.btnProductManagement_Click);
            // 
            // btnEmployees
            // 
            this.btnEmployees.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmployees.Location = new System.Drawing.Point(269, 158);
            this.btnEmployees.Name = "btnEmployees";
            this.btnEmployees.Size = new System.Drawing.Size(400, 231);
            this.btnEmployees.TabIndex = 0;
            this.btnEmployees.Text = "Employees";
            this.btnEmployees.UseVisualStyleBackColor = true;
            this.btnEmployees.Click += new System.EventHandler(this.btnEmployees_Click);
            // 
            // pnlEmployees
            // 
            this.pnlEmployees.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlEmployees.Controls.Add(this.button1);
            this.pnlEmployees.Controls.Add(this.employeesDataGridView);
            this.pnlEmployees.Controls.Add(this.gpbEmployee);
            this.pnlEmployees.Controls.Add(this.btnQuitEmployees);
            this.pnlEmployees.Controls.Add(this.lblEmployees);
            this.pnlEmployees.Location = new System.Drawing.Point(0, 0);
            this.pnlEmployees.Name = "pnlEmployees";
            this.pnlEmployees.Size = new System.Drawing.Size(1545, 960);
            this.pnlEmployees.TabIndex = 4;
            this.pnlEmployees.Visible = false;
            this.pnlEmployees.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlEmployees_Paint);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1303, 516);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(193, 158);
            this.button1.TabIndex = 14;
            this.button1.Text = "GET ALL THE EMPLOYEE NAMES!";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // employeesDataGridView
            // 
            this.employeesDataGridView.AutoGenerateColumns = false;
            this.employeesDataGridView.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.employeesDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.employeesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.employeesDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewCheckBoxColumn1,
            this.dataGridViewCheckBoxColumn2});
            this.employeesDataGridView.DataSource = this.employeesBindingSource;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.employeesDataGridView.DefaultCellStyle = dataGridViewCellStyle27;
            this.employeesDataGridView.Location = new System.Drawing.Point(206, 118);
            this.employeesDataGridView.Name = "employeesDataGridView";
            this.employeesDataGridView.RowTemplate.Height = 32;
            this.employeesDataGridView.Size = new System.Drawing.Size(1133, 244);
            this.employeesDataGridView.TabIndex = 13;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ID";
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle20;
            this.dataGridViewTextBoxColumn1.HeaderText = "ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn1.Width = 80;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Fname";
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle21;
            this.dataGridViewTextBoxColumn2.HeaderText = "First Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn2.Width = 200;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Lname";
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle22;
            this.dataGridViewTextBoxColumn3.HeaderText = "Last Name";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn3.Width = 220;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Status";
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle23;
            this.dataGridViewTextBoxColumn4.HeaderText = "Status";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn4.Width = 180;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Wage";
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle24;
            this.dataGridViewTextBoxColumn5.HeaderText = "Wage";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn5.Width = 130;
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.DataPropertyName = "LeftHanded";
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle25.NullValue = false;
            this.dataGridViewCheckBoxColumn1.DefaultCellStyle = dataGridViewCellStyle25;
            this.dataGridViewCheckBoxColumn1.HeaderText = "Left - Handed";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            this.dataGridViewCheckBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewCheckBoxColumn1.Width = 150;
            // 
            // dataGridViewCheckBoxColumn2
            // 
            this.dataGridViewCheckBoxColumn2.DataPropertyName = "Colorblind";
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle26.NullValue = false;
            this.dataGridViewCheckBoxColumn2.DefaultCellStyle = dataGridViewCellStyle26;
            this.dataGridViewCheckBoxColumn2.HeaderText = "Colorblind";
            this.dataGridViewCheckBoxColumn2.Name = "dataGridViewCheckBoxColumn2";
            this.dataGridViewCheckBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewCheckBoxColumn2.Width = 130;
            // 
            // employeesBindingSource
            // 
            this.employeesBindingSource.DataMember = "Employees";
            this.employeesBindingSource.DataSource = this.coffeeShopEmployeesDataSet;
            // 
            // coffeeShopEmployeesDataSet
            // 
            this.coffeeShopEmployeesDataSet.DataSetName = "CoffeeShopEmployeesDataSet";
            this.coffeeShopEmployeesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gpbEmployee
            // 
            this.gpbEmployee.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.gpbEmployee.Controls.Add(this.groupBox1);
            this.gpbEmployee.Controls.Add(this.btnAddEmployee);
            this.gpbEmployee.Controls.Add(this.btnUpdateEmployee);
            this.gpbEmployee.Controls.Add(this.btnDeleteEmployee);
            this.gpbEmployee.Controls.Add(lblWage);
            this.gpbEmployee.Controls.Add(lblStatus);
            this.gpbEmployee.Controls.Add(this.txtbWage);
            this.gpbEmployee.Controls.Add(lblLastName);
            this.gpbEmployee.Controls.Add(this.txtbStatus);
            this.gpbEmployee.Controls.Add(this.txtbLastName);
            this.gpbEmployee.Controls.Add(lblFirstName);
            this.gpbEmployee.Controls.Add(this.txtbFirstName);
            this.gpbEmployee.Controls.Add(lblEmployeeId);
            this.gpbEmployee.Controls.Add(this.txtbID);
            this.gpbEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpbEmployee.Location = new System.Drawing.Point(357, 405);
            this.gpbEmployee.Name = "gpbEmployee";
            this.gpbEmployee.Size = new System.Drawing.Size(830, 515);
            this.gpbEmployee.TabIndex = 12;
            this.gpbEmployee.TabStop = false;
            this.gpbEmployee.Text = "Employee Info/Update";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.groupBox1.Controls.Add(leftHandedLabel);
            this.groupBox1.Controls.Add(this.leftHandedCheckBox);
            this.groupBox1.Controls.Add(this.colorblindCheckBox);
            this.groupBox1.Controls.Add(colorblindLabel);
            this.groupBox1.Location = new System.Drawing.Point(513, 46);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(254, 258);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Special Needs";
            // 
            // leftHandedCheckBox
            // 
            this.leftHandedCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.employeesBindingSource, "LeftHanded", true));
            this.leftHandedCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.leftHandedCheckBox.Location = new System.Drawing.Point(90, 78);
            this.leftHandedCheckBox.Name = "leftHandedCheckBox";
            this.leftHandedCheckBox.Size = new System.Drawing.Size(79, 38);
            this.leftHandedCheckBox.TabIndex = 24;
            this.leftHandedCheckBox.Text = "Yes";
            this.leftHandedCheckBox.UseVisualStyleBackColor = true;
            this.leftHandedCheckBox.CheckedChanged += new System.EventHandler(this.leftHandedCheckBox_CheckedChanged);
            // 
            // colorblindCheckBox
            // 
            this.colorblindCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.employeesBindingSource, "Colorblind", true));
            this.colorblindCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colorblindCheckBox.Location = new System.Drawing.Point(90, 187);
            this.colorblindCheckBox.Name = "colorblindCheckBox";
            this.colorblindCheckBox.Size = new System.Drawing.Size(79, 36);
            this.colorblindCheckBox.TabIndex = 26;
            this.colorblindCheckBox.Text = "Yes";
            this.colorblindCheckBox.UseVisualStyleBackColor = true;
            this.colorblindCheckBox.CheckedChanged += new System.EventHandler(this.colorblindCheckBox_CheckedChanged);
            // 
            // btnAddEmployee
            // 
            this.btnAddEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddEmployee.Location = new System.Drawing.Point(59, 400);
            this.btnAddEmployee.Name = "btnAddEmployee";
            this.btnAddEmployee.Size = new System.Drawing.Size(181, 83);
            this.btnAddEmployee.TabIndex = 28;
            this.btnAddEmployee.Text = "Add Employee";
            this.btnAddEmployee.UseVisualStyleBackColor = true;
            this.btnAddEmployee.Click += new System.EventHandler(this.btnAddEmployee_Click);
            // 
            // btnUpdateEmployee
            // 
            this.btnUpdateEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateEmployee.Location = new System.Drawing.Point(542, 358);
            this.btnUpdateEmployee.Name = "btnUpdateEmployee";
            this.btnUpdateEmployee.Size = new System.Drawing.Size(209, 125);
            this.btnUpdateEmployee.TabIndex = 13;
            this.btnUpdateEmployee.Text = "Update Employees";
            this.btnUpdateEmployee.UseVisualStyleBackColor = true;
            this.btnUpdateEmployee.Click += new System.EventHandler(this.btnUpdateEmployee_Click);
            // 
            // btnDeleteEmployee
            // 
            this.btnDeleteEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteEmployee.Location = new System.Drawing.Point(278, 400);
            this.btnDeleteEmployee.Name = "btnDeleteEmployee";
            this.btnDeleteEmployee.Size = new System.Drawing.Size(181, 83);
            this.btnDeleteEmployee.TabIndex = 27;
            this.btnDeleteEmployee.Text = "Delete Employee";
            this.btnDeleteEmployee.UseVisualStyleBackColor = true;
            this.btnDeleteEmployee.Click += new System.EventHandler(this.btnDeleteEmployee_Click);
            // 
            // txtbWage
            // 
            this.txtbWage.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "Wage", true));
            this.txtbWage.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbWage.Location = new System.Drawing.Point(218, 323);
            this.txtbWage.Name = "txtbWage";
            this.txtbWage.Size = new System.Drawing.Size(110, 38);
            this.txtbWage.TabIndex = 22;
            // 
            // txtbStatus
            // 
            this.txtbStatus.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "Status", true));
            this.txtbStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbStatus.Location = new System.Drawing.Point(218, 250);
            this.txtbStatus.Name = "txtbStatus";
            this.txtbStatus.Size = new System.Drawing.Size(214, 38);
            this.txtbStatus.TabIndex = 20;
            // 
            // txtbLastName
            // 
            this.txtbLastName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "Lname", true));
            this.txtbLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbLastName.Location = new System.Drawing.Point(218, 182);
            this.txtbLastName.Name = "txtbLastName";
            this.txtbLastName.Size = new System.Drawing.Size(214, 38);
            this.txtbLastName.TabIndex = 18;
            // 
            // txtbFirstName
            // 
            this.txtbFirstName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "Fname", true));
            this.txtbFirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbFirstName.Location = new System.Drawing.Point(218, 113);
            this.txtbFirstName.Name = "txtbFirstName";
            this.txtbFirstName.Size = new System.Drawing.Size(214, 38);
            this.txtbFirstName.TabIndex = 16;
            // 
            // txtbID
            // 
            this.txtbID.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "ID", true));
            this.txtbID.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbID.Location = new System.Drawing.Point(218, 46);
            this.txtbID.Name = "txtbID";
            this.txtbID.Size = new System.Drawing.Size(110, 38);
            this.txtbID.TabIndex = 14;
            this.txtbID.TextChanged += new System.EventHandler(this.txtbID_TextChanged);
            // 
            // btnQuitEmployees
            // 
            this.btnQuitEmployees.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuitEmployees.Location = new System.Drawing.Point(1295, 834);
            this.btnQuitEmployees.Name = "btnQuitEmployees";
            this.btnQuitEmployees.Size = new System.Drawing.Size(201, 87);
            this.btnQuitEmployees.TabIndex = 11;
            this.btnQuitEmployees.Text = "Quit";
            this.btnQuitEmployees.UseVisualStyleBackColor = true;
            this.btnQuitEmployees.Click += new System.EventHandler(this.btnQuitEmployees_Click);
            // 
            // lblEmployees
            // 
            this.lblEmployees.AutoSize = true;
            this.lblEmployees.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployees.Location = new System.Drawing.Point(597, 23);
            this.lblEmployees.Name = "lblEmployees";
            this.lblEmployees.Size = new System.Drawing.Size(350, 73);
            this.lblEmployees.TabIndex = 3;
            this.lblEmployees.Text = "Employees";
            // 
            // pnlProductMgmt
            // 
            this.pnlProductMgmt.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlProductMgmt.Controls.Add(this.grpbRemoveItem);
            this.pnlProductMgmt.Controls.Add(this.grpbAddItem);
            this.pnlProductMgmt.Controls.Add(this.btnQuitProductMgmt);
            this.pnlProductMgmt.Controls.Add(this.lblProductManagement);
            this.pnlProductMgmt.Location = new System.Drawing.Point(0, 0);
            this.pnlProductMgmt.Name = "pnlProductMgmt";
            this.pnlProductMgmt.Size = new System.Drawing.Size(1545, 960);
            this.pnlProductMgmt.TabIndex = 11;
            this.pnlProductMgmt.Visible = false;
            this.pnlProductMgmt.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlProductMgmt_Paint);
            // 
            // grpbRemoveItem
            // 
            this.grpbRemoveItem.Controls.Add(this.btnDeleteItem);
            this.grpbRemoveItem.Controls.Add(this.txtbItemToDelete);
            this.grpbRemoveItem.Controls.Add(this.lblItemToRemove);
            this.grpbRemoveItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbRemoveItem.Location = new System.Drawing.Point(777, 573);
            this.grpbRemoveItem.Name = "grpbRemoveItem";
            this.grpbRemoveItem.Size = new System.Drawing.Size(512, 358);
            this.grpbRemoveItem.TabIndex = 9;
            this.grpbRemoveItem.TabStop = false;
            this.grpbRemoveItem.Text = "Remove Item";
            // 
            // btnDeleteItem
            // 
            this.btnDeleteItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteItem.Location = new System.Drawing.Point(169, 266);
            this.btnDeleteItem.Name = "btnDeleteItem";
            this.btnDeleteItem.Size = new System.Drawing.Size(199, 60);
            this.btnDeleteItem.TabIndex = 2;
            this.btnDeleteItem.Text = "Delete Item";
            this.btnDeleteItem.UseVisualStyleBackColor = true;
            this.btnDeleteItem.Click += new System.EventHandler(this.btnDeleteItem_Click);
            // 
            // txtbItemToDelete
            // 
            this.txtbItemToDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbItemToDelete.Location = new System.Drawing.Point(121, 119);
            this.txtbItemToDelete.Name = "txtbItemToDelete";
            this.txtbItemToDelete.Size = new System.Drawing.Size(289, 38);
            this.txtbItemToDelete.TabIndex = 1;
            // 
            // lblItemToRemove
            // 
            this.lblItemToRemove.AutoSize = true;
            this.lblItemToRemove.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemToRemove.Location = new System.Drawing.Point(163, 56);
            this.lblItemToRemove.Name = "lblItemToRemove";
            this.lblItemToRemove.Size = new System.Drawing.Size(205, 31);
            this.lblItemToRemove.TabIndex = 0;
            this.lblItemToRemove.Text = "Item to Remove";
            // 
            // grpbAddItem
            // 
            this.grpbAddItem.Controls.Add(this.btnAddItem);
            this.grpbAddItem.Controls.Add(this.txtbAddSubmenu);
            this.grpbAddItem.Controls.Add(this.lblAddSubmenu);
            this.grpbAddItem.Controls.Add(this.lstbSubmenues);
            this.grpbAddItem.Controls.Add(this.lblItemSubMenus);
            this.grpbAddItem.Controls.Add(this.lblItemPrice);
            this.grpbAddItem.Controls.Add(this.txtbItemPrice);
            this.grpbAddItem.Controls.Add(this.lblItemName);
            this.grpbAddItem.Controls.Add(this.txtbItemName);
            this.grpbAddItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbAddItem.Location = new System.Drawing.Point(64, 482);
            this.grpbAddItem.Name = "grpbAddItem";
            this.grpbAddItem.Size = new System.Drawing.Size(512, 451);
            this.grpbAddItem.TabIndex = 8;
            this.grpbAddItem.TabStop = false;
            this.grpbAddItem.Text = "Add New Item";
            // 
            // btnAddItem
            // 
            this.btnAddItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddItem.Location = new System.Drawing.Point(150, 357);
            this.btnAddItem.Name = "btnAddItem";
            this.btnAddItem.Size = new System.Drawing.Size(199, 60);
            this.btnAddItem.TabIndex = 14;
            this.btnAddItem.Text = "Add Item";
            this.btnAddItem.UseVisualStyleBackColor = true;
            this.btnAddItem.Click += new System.EventHandler(this.btnAddItem_Click);
            // 
            // txtbAddSubmenu
            // 
            this.txtbAddSubmenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbAddSubmenu.Location = new System.Drawing.Point(252, 116);
            this.txtbAddSubmenu.Name = "txtbAddSubmenu";
            this.txtbAddSubmenu.Size = new System.Drawing.Size(206, 38);
            this.txtbAddSubmenu.TabIndex = 13;
            // 
            // lblAddSubmenu
            // 
            this.lblAddSubmenu.AutoSize = true;
            this.lblAddSubmenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddSubmenu.Location = new System.Drawing.Point(50, 119);
            this.lblAddSubmenu.Name = "lblAddSubmenu";
            this.lblAddSubmenu.Size = new System.Drawing.Size(184, 31);
            this.lblAddSubmenu.TabIndex = 12;
            this.lblAddSubmenu.Text = "Add Submenu";
            // 
            // lstbSubmenues
            // 
            this.lstbSubmenues.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstbSubmenues.FormattingEnabled = true;
            this.lstbSubmenues.ItemHeight = 31;
            this.lstbSubmenues.Items.AddRange(new object[] {
            "",
            "Sizes",
            "Customizations"});
            this.lstbSubmenues.Location = new System.Drawing.Point(252, 180);
            this.lstbSubmenues.Name = "lstbSubmenues";
            this.lstbSubmenues.Size = new System.Drawing.Size(146, 35);
            this.lstbSubmenues.TabIndex = 11;
            // 
            // lblItemSubMenus
            // 
            this.lblItemSubMenus.AutoSize = true;
            this.lblItemSubMenus.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemSubMenus.Location = new System.Drawing.Point(50, 180);
            this.lblItemSubMenus.Name = "lblItemSubMenus";
            this.lblItemSubMenus.Size = new System.Drawing.Size(143, 31);
            this.lblItemSubMenus.TabIndex = 10;
            this.lblItemSubMenus.Text = "Submenus";
            // 
            // lblItemPrice
            // 
            this.lblItemPrice.AutoSize = true;
            this.lblItemPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemPrice.Location = new System.Drawing.Point(50, 281);
            this.lblItemPrice.Name = "lblItemPrice";
            this.lblItemPrice.Size = new System.Drawing.Size(76, 31);
            this.lblItemPrice.TabIndex = 8;
            this.lblItemPrice.Text = "Price";
            // 
            // txtbItemPrice
            // 
            this.txtbItemPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbItemPrice.Location = new System.Drawing.Point(252, 278);
            this.txtbItemPrice.Name = "txtbItemPrice";
            this.txtbItemPrice.Size = new System.Drawing.Size(159, 38);
            this.txtbItemPrice.TabIndex = 9;
            // 
            // lblItemName
            // 
            this.lblItemName.AutoSize = true;
            this.lblItemName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemName.Location = new System.Drawing.Point(50, 59);
            this.lblItemName.Name = "lblItemName";
            this.lblItemName.Size = new System.Drawing.Size(146, 31);
            this.lblItemName.TabIndex = 6;
            this.lblItemName.Text = "Item Name";
            // 
            // txtbItemName
            // 
            this.txtbItemName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbItemName.Location = new System.Drawing.Point(252, 56);
            this.txtbItemName.Name = "txtbItemName";
            this.txtbItemName.Size = new System.Drawing.Size(206, 38);
            this.txtbItemName.TabIndex = 7;
            // 
            // btnQuitProductMgmt
            // 
            this.btnQuitProductMgmt.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuitProductMgmt.Location = new System.Drawing.Point(1295, 825);
            this.btnQuitProductMgmt.Name = "btnQuitProductMgmt";
            this.btnQuitProductMgmt.Size = new System.Drawing.Size(201, 87);
            this.btnQuitProductMgmt.TabIndex = 5;
            this.btnQuitProductMgmt.Text = "Quit";
            this.btnQuitProductMgmt.UseVisualStyleBackColor = true;
            this.btnQuitProductMgmt.Click += new System.EventHandler(this.btnQuitProductMgmt_Click);
            // 
            // lblProductManagement
            // 
            this.lblProductManagement.AutoSize = true;
            this.lblProductManagement.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductManagement.Location = new System.Drawing.Point(449, 23);
            this.lblProductManagement.Name = "lblProductManagement";
            this.lblProductManagement.Size = new System.Drawing.Size(647, 73);
            this.lblProductManagement.TabIndex = 3;
            this.lblProductManagement.Text = "Product Management";
            // 
            // pnlConfirmDeletion
            // 
            this.pnlConfirmDeletion.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pnlConfirmDeletion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlConfirmDeletion.Controls.Add(this.lblDeleteWarning);
            this.pnlConfirmDeletion.Controls.Add(this.btnDelete);
            this.pnlConfirmDeletion.Controls.Add(this.lblConfirmDeletion);
            this.pnlConfirmDeletion.Location = new System.Drawing.Point(0, 0);
            this.pnlConfirmDeletion.Name = "pnlConfirmDeletion";
            this.pnlConfirmDeletion.Size = new System.Drawing.Size(540, 309);
            this.pnlConfirmDeletion.TabIndex = 10;
            this.pnlConfirmDeletion.Visible = false;
            // 
            // lblDeleteWarning
            // 
            this.lblDeleteWarning.AutoSize = true;
            this.lblDeleteWarning.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDeleteWarning.Location = new System.Drawing.Point(58, 88);
            this.lblDeleteWarning.Name = "lblDeleteWarning";
            this.lblDeleteWarning.Size = new System.Drawing.Size(425, 87);
            this.lblDeleteWarning.TabIndex = 2;
            this.lblDeleteWarning.Text = "!!! WARNING !!!\r\n* All data will be permanently erased. *\r\nClick \'Delete\' to cont" +
    "inue :";
            this.lblDeleteWarning.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(203, 205);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(136, 54);
            this.btnDelete.TabIndex = 1;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // lblConfirmDeletion
            // 
            this.lblConfirmDeletion.AutoSize = true;
            this.lblConfirmDeletion.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConfirmDeletion.Location = new System.Drawing.Point(121, 25);
            this.lblConfirmDeletion.Name = "lblConfirmDeletion";
            this.lblConfirmDeletion.Size = new System.Drawing.Size(297, 37);
            this.lblConfirmDeletion.TabIndex = 0;
            this.lblConfirmDeletion.Text = "* Confirm Deletion *";
            // 
            // pnlCreateTest
            // 
            this.pnlCreateTest.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCreateTest.Controls.Add(this.btnCreateNewTest);
            this.pnlCreateTest.Controls.Add(this.txtbNewTestName);
            this.pnlCreateTest.Controls.Add(this.lblNewTestName);
            this.pnlCreateTest.Controls.Add(this.btnQuitCreateTest);
            this.pnlCreateTest.Controls.Add(this.lblCreatePracticeTest);
            this.pnlCreateTest.Location = new System.Drawing.Point(0, 0);
            this.pnlCreateTest.Name = "pnlCreateTest";
            this.pnlCreateTest.Size = new System.Drawing.Size(1545, 960);
            this.pnlCreateTest.TabIndex = 5;
            this.pnlCreateTest.Visible = false;
            // 
            // btnCreateNewTest
            // 
            this.btnCreateNewTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateNewTest.Location = new System.Drawing.Point(655, 429);
            this.btnCreateNewTest.Name = "btnCreateNewTest";
            this.btnCreateNewTest.Size = new System.Drawing.Size(271, 127);
            this.btnCreateNewTest.TabIndex = 4;
            this.btnCreateNewTest.Text = "Create Test";
            this.btnCreateNewTest.UseVisualStyleBackColor = true;
            this.btnCreateNewTest.Click += new System.EventHandler(this.btnCreateNewTest_Click);
            // 
            // txtbNewTestName
            // 
            this.txtbNewTestName.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbNewTestName.Location = new System.Drawing.Point(723, 260);
            this.txtbNewTestName.Name = "txtbNewTestName";
            this.txtbNewTestName.Size = new System.Drawing.Size(367, 40);
            this.txtbNewTestName.TabIndex = 3;
            // 
            // lblNewTestName
            // 
            this.lblNewTestName.AutoSize = true;
            this.lblNewTestName.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewTestName.Location = new System.Drawing.Point(455, 263);
            this.lblNewTestName.Name = "lblNewTestName";
            this.lblNewTestName.Size = new System.Drawing.Size(224, 33);
            this.lblNewTestName.TabIndex = 2;
            this.lblNewTestName.Text = "New Test Name";
            this.lblNewTestName.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnQuitCreateTest
            // 
            this.btnQuitCreateTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuitCreateTest.Location = new System.Drawing.Point(1295, 834);
            this.btnQuitCreateTest.Name = "btnQuitCreateTest";
            this.btnQuitCreateTest.Size = new System.Drawing.Size(201, 87);
            this.btnQuitCreateTest.TabIndex = 1;
            this.btnQuitCreateTest.Text = "Quit";
            this.btnQuitCreateTest.UseVisualStyleBackColor = true;
            this.btnQuitCreateTest.Click += new System.EventHandler(this.btnQuitCreateTest_Click);
            // 
            // lblCreatePracticeTest
            // 
            this.lblCreatePracticeTest.AutoSize = true;
            this.lblCreatePracticeTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCreatePracticeTest.Location = new System.Drawing.Point(448, 42);
            this.lblCreatePracticeTest.Name = "lblCreatePracticeTest";
            this.lblCreatePracticeTest.Size = new System.Drawing.Size(648, 73);
            this.lblCreatePracticeTest.TabIndex = 0;
            this.lblCreatePracticeTest.Text = "Create Practice Tests";
            // 
            // pnlSalesReport
            // 
            this.pnlSalesReport.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlSalesReport.Controls.Add(this.rtxtbSalesReport);
            this.pnlSalesReport.Controls.Add(this.lblSalesReport);
            this.pnlSalesReport.Controls.Add(this.btnQuitSalesReport);
            this.pnlSalesReport.Location = new System.Drawing.Point(0, 0);
            this.pnlSalesReport.Name = "pnlSalesReport";
            this.pnlSalesReport.Size = new System.Drawing.Size(1545, 960);
            this.pnlSalesReport.TabIndex = 5;
            this.pnlSalesReport.Visible = false;
            // 
            // rtxtbSalesReport
            // 
            this.rtxtbSalesReport.Location = new System.Drawing.Point(314, 134);
            this.rtxtbSalesReport.Name = "rtxtbSalesReport";
            this.rtxtbSalesReport.Size = new System.Drawing.Size(916, 688);
            this.rtxtbSalesReport.TabIndex = 2;
            this.rtxtbSalesReport.Text = "";
            // 
            // lblSalesReport
            // 
            this.lblSalesReport.AutoSize = true;
            this.lblSalesReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalesReport.Location = new System.Drawing.Point(532, 23);
            this.lblSalesReport.Name = "lblSalesReport";
            this.lblSalesReport.Size = new System.Drawing.Size(403, 73);
            this.lblSalesReport.TabIndex = 1;
            this.lblSalesReport.Text = "Sales Report";
            // 
            // btnQuitSalesReport
            // 
            this.btnQuitSalesReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuitSalesReport.Location = new System.Drawing.Point(1319, 834);
            this.btnQuitSalesReport.Name = "btnQuitSalesReport";
            this.btnQuitSalesReport.Size = new System.Drawing.Size(201, 87);
            this.btnQuitSalesReport.TabIndex = 0;
            this.btnQuitSalesReport.Text = "Quit";
            this.btnQuitSalesReport.UseVisualStyleBackColor = true;
            this.btnQuitSalesReport.Click += new System.EventHandler(this.btnQuitSalesReport_Click);
            // 
            // employeesBindingNavigator
            // 
            this.employeesBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.employeesBindingNavigator.BindingSource = this.employeesBindingSource;
            this.employeesBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.employeesBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.employeesBindingNavigator.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.employeesBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.employeesBindingNavigatorSaveItem});
            this.employeesBindingNavigator.Location = new System.Drawing.Point(0, 960);
            this.employeesBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.employeesBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.employeesBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.employeesBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.employeesBindingNavigator.Name = "employeesBindingNavigator";
            this.employeesBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.employeesBindingNavigator.Size = new System.Drawing.Size(1547, 25);
            this.employeesBindingNavigator.TabIndex = 12;
            this.employeesBindingNavigator.Text = "bindingNavigator1";
            this.employeesBindingNavigator.Visible = false;
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            this.bindingNavigatorAddNewItem.Click += new System.EventHandler(this.bindingNavigatorAddNewItem_Click);
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            this.bindingNavigatorDeleteItem.Click += new System.EventHandler(this.bindingNavigatorDeleteItem_Click);
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // employeesBindingNavigatorSaveItem
            // 
            this.employeesBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.employeesBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("employeesBindingNavigatorSaveItem.Image")));
            this.employeesBindingNavigatorSaveItem.Name = "employeesBindingNavigatorSaveItem";
            this.employeesBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.employeesBindingNavigatorSaveItem.Text = "Save Data";
            this.employeesBindingNavigatorSaveItem.Click += new System.EventHandler(this.employeesBindingNavigatorSaveItem_Click);
            // 
            // employeesTableAdapter
            // 
            this.employeesTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.EmployeesTableAdapter = this.employeesTableAdapter;
            this.tableAdapterManager.UpdateOrder = EAPOS_Project.CoffeeShopEmployeesDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // frmManagerMode
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1547, 985);
            this.Controls.Add(this.pnlProductMgmt);
            this.Controls.Add(this.pnlConfirmDeletion);
            this.Controls.Add(this.employeesBindingNavigator);
            this.Controls.Add(this.pnlEmployees);
            this.Controls.Add(this.pnlManagerMode);
            this.Controls.Add(this.pnlSalesReport);
            this.Controls.Add(this.pnlCreateTest);
            this.Name = "frmManagerMode";
            this.Text = "Manager Mode";
            this.Load += new System.EventHandler(this.frmManagerMode_Load_1);
            this.pnlManagerMode.ResumeLayout(false);
            this.pnlManagerMode.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlEmployees.ResumeLayout(false);
            this.pnlEmployees.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeesDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coffeeShopEmployeesDataSet)).EndInit();
            this.gpbEmployee.ResumeLayout(false);
            this.gpbEmployee.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.pnlProductMgmt.ResumeLayout(false);
            this.pnlProductMgmt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.buttonMainPanelBindingSource1)).EndInit();
            this.grpbRemoveItem.ResumeLayout(false);
            this.grpbRemoveItem.PerformLayout();
            this.grpbAddItem.ResumeLayout(false);
            this.grpbAddItem.PerformLayout();
            this.pnlConfirmDeletion.ResumeLayout(false);
            this.pnlConfirmDeletion.PerformLayout();
            this.pnlCreateTest.ResumeLayout(false);
            this.pnlCreateTest.PerformLayout();
            this.pnlSalesReport.ResumeLayout(false);
            this.pnlSalesReport.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingNavigator)).EndInit();
            this.employeesBindingNavigator.ResumeLayout(false);
            this.employeesBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.buttonMainPanelBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Panel pnlManagerMode;
        public System.Windows.Forms.Button btnOrderMode;
        public System.Windows.Forms.Button btnSalesReport;
        public System.Windows.Forms.Button btnCreateTrainingTests;
        public System.Windows.Forms.Button btnProductManagement;
        public System.Windows.Forms.Button btnEmployees;
        public System.Windows.Forms.Panel pnlEmployees;
        public System.Windows.Forms.Label lblEmployees;
        public System.Windows.Forms.Label lblManagerMode;
        public System.Windows.Forms.Panel pnlProductMgmt;
        public System.Windows.Forms.Label lblProductManagement;
        public System.Windows.Forms.Button btnQuitProductMgmt;
        public System.Windows.Forms.Button btnQuitEmployees;
        public System.Windows.Forms.Button btnUpdateEmployee;
        public System.Windows.Forms.GroupBox gpbEmployee;
        public System.Windows.Forms.GroupBox grpbAddItem;
        public System.Windows.Forms.TextBox txtbItemName;
        public System.Windows.Forms.Label lblItemName;
        public System.Windows.Forms.Panel pnlConfirmDeletion;
        public System.Windows.Forms.Label lblDeleteWarning;
        public System.Windows.Forms.Button btnDelete;
        public System.Windows.Forms.Label lblConfirmDeletion;
        public System.Windows.Forms.GroupBox grpbRemoveItem;
        public System.Windows.Forms.Button btnDeleteItem;
        public System.Windows.Forms.TextBox txtbItemToDelete;
        public System.Windows.Forms.Label lblItemToRemove;
        public System.Windows.Forms.TextBox txtbAddSubmenu;
        public System.Windows.Forms.Label lblAddSubmenu;
        public System.Windows.Forms.ListBox lstbSubmenues;
        public System.Windows.Forms.Label lblItemSubMenus;
        public System.Windows.Forms.Label lblItemPrice;
        public System.Windows.Forms.TextBox txtbItemPrice;
        public System.Windows.Forms.Panel pnlCreateTest;
        public System.Windows.Forms.Button btnQuitCreateTest;
        public System.Windows.Forms.Label lblCreatePracticeTest;
        public System.Windows.Forms.Panel pnlSalesReport;
        public System.Windows.Forms.Button btnQuitSalesReport;
        public System.Windows.Forms.Label lblSalesReport;
        public System.Windows.Forms.Button btnCreateNewTest;
        public System.Windows.Forms.TextBox txtbNewTestName;
        public System.Windows.Forms.Label lblNewTestName;
        public System.Windows.Forms.Button btnAddItem;
        public System.Windows.Forms.RichTextBox rtxtbSalesReport;
        public CoffeeShopEmployeesDataSet coffeeShopEmployeesDataSet;
        public System.Windows.Forms.BindingSource employeesBindingSource;
        public CoffeeShopEmployeesDataSetTableAdapters.EmployeesTableAdapter employeesTableAdapter;
        public CoffeeShopEmployeesDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        public System.Windows.Forms.BindingNavigator employeesBindingNavigator;
        public System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        public System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        public System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        public System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        public System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        public System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        public System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        public System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        public System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        public System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        public System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        public System.Windows.Forms.ToolStripButton employeesBindingNavigatorSaveItem;
        public System.Windows.Forms.DataGridView employeesDataGridView;
        public System.Windows.Forms.TextBox txtbFirstName;
        public System.Windows.Forms.TextBox txtbLastName;
        public System.Windows.Forms.TextBox txtbStatus;
        public System.Windows.Forms.TextBox txtbWage;
        public System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        public System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        public System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        public System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        public System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        public System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        public System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn2;
        public System.Windows.Forms.Button btnSignOutManagerMode;
        public System.Windows.Forms.CheckBox colorblindCheckBox;
        public System.Windows.Forms.Button btnDeleteEmployee;
        public System.Windows.Forms.CheckBox leftHandedCheckBox;
        public System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.Button btnAddEmployee;
        public System.Windows.Forms.TextBox txtbID;
        public System.Windows.Forms.PictureBox pictureBox1;
        private System.ComponentModel.IContainer components;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.BindingSource buttonMainPanelBindingSource;
        private System.Windows.Forms.BindingSource buttonMainPanelBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn3;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn4;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn5;
    }
}

